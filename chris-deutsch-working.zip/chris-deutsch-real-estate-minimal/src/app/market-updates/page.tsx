import Navigation from "@/components/ui/navigation";
import VoicePlayer from "@/components/ui/voice-player";
import { TrendingUp, MapPin, PlayCircle, Calendar, Users } from "lucide-react";

export default function MarketUpdates() {
  const marketUpdates = [
    {
      title: "Golden Valley Market Update",
      date: "December 2024",
      zipCodes: ["55416", "55426"],
      medianValue: "$485,000",
      avgDaysOnMarket: "18 days",
      saleToListRatio: "98.2%",
      script: "Hi, this is Chris Deutsch with your Golden Valley market update for December 2024. After 25 years serving Twin Cities families, I'm excited to share some remarkable developments in our Golden Valley market. If you're a homeowner in the 55416 or 55426 zip codes, you're sitting on some incredible equity growth. Homes in your area have appreciated significantly, with median values now reaching $485,000 in prime Golden Valley neighborhoods. Here's what this means for you: If you purchased your home 7 to 10 years ago, you likely have substantial equity that opens up exciting possibilities. Many of my Golden Valley clients are discovering they can afford to move up to their dream home, or right-size to something that better fits their current lifestyle.",
      opportunity: "Move-up buyers with 7-10 years equity"
    },
    {
      title: "Edina Luxury Market Outlook",
      date: "December 2024", 
      zipCodes: ["55436", "55439"],
      medianValue: "$625,000",
      avgDaysOnMarket: "22 days",
      saleToListRatio: "97.8%",
      script: "This is Chris Deutsch with your Edina luxury market outlook. The Edina market continues to demonstrate remarkable strength, particularly in the $600,000 to $1.2 million range. With my 25 years of Twin Cities expertise, I'm seeing exceptional opportunities for sellers who've been in their homes for over a decade. Current market conditions in zip codes 55436 and 55439 show median values reaching $625,000, with luxury properties moving efficiently in an average of 22 days.",
      opportunity: "Luxury homeowners ready to upgrade or downsize"
    },
    {
      title: "Plymouth Investment Opportunities",
      date: "December 2024",
      zipCodes: ["55447", "55441"],
      medianValue: "$425,000",
      avgDaysOnMarket: "16 days", 
      saleToListRatio: "99.1%",
      script: "Chris Deutsch here with your Plymouth investment market update. Plymouth continues to be one of the Twin Cities' most attractive markets for both investors and established homeowners looking to transition. With median values at $425,000 and homes selling in just 16 days, we're seeing incredible momentum. For homeowners in zip codes 55447 and 55441 who purchased 8-12 years ago, your equity position is likely substantial enough to explore move-up opportunities or strategic downsizing.",
      opportunity: "Investment properties and equity transitions"
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-b from-white to-[#f8f8f9]">
      <Navigation />
      
      {/* HERO SECTION */}
      <section className="pt-20 pb-16 bg-gradient-to-br from-[#a81933] via-[#504f56] to-[#161019]">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center max-w-4xl mx-auto">
            <div className="inline-flex items-center gap-4 bg-yellow-400/20 backdrop-blur-lg px-6 py-3 border border-yellow-400/30 mb-8">
              <PlayCircle className="w-6 h-6 text-yellow-400" />
              <span className="font-bold text-white tracking-wide">AI-POWERED MARKET INTELLIGENCE</span>
            </div>
            
            <h1 className="text-5xl lg:text-6xl font-serif font-bold text-white mb-6 leading-tight">
              Twin Cities Market Updates
              <span className="block text-4xl lg:text-5xl bg-gradient-to-r from-yellow-400 to-yellow-500 bg-clip-text text-transparent">
                Powered by Chris's Voice Clone
              </span>
            </h1>
            
            <p className="text-xl text-white/80 leading-relaxed max-w-3xl mx-auto">
              Get personalized market insights delivered in Chris Deutsch's voice using cutting-edge AI technology. 
              25 years of expertise, now available instantly for your specific neighborhood.
            </p>
          </div>
        </div>
      </section>

      {/* MARKET UPDATES GRID */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="space-y-8">
            {marketUpdates.map((update, index) => (
              <div key={index} className="bg-white border border-gray-200 shadow-lg hover:shadow-xl transition-all duration-300 overflow-hidden">
                <div className="p-8">
                  <div className="grid lg:grid-cols-12 gap-8 items-center">
                    
                    {/* CONTENT COLUMN */}
                    <div className="lg:col-span-8">
                      <div className="flex items-center gap-4 mb-4">
                        <div className="flex items-center justify-center w-12 h-12 bg-[#a81933] rounded-full">
                          <MapPin className="w-6 h-6 text-white" />
                        </div>
                        <div>
                          <h2 className="text-2xl font-bold text-[#504f56]">{update.title}</h2>
                          <div className="flex items-center gap-4 text-sm text-gray-600">
                            <span className="flex items-center gap-1">
                              <Calendar className="w-4 h-4" />
                              {update.date}
                            </span>
                            <span>Zip Codes: {update.zipCodes.join(", ")}</span>
                          </div>
                        </div>
                      </div>

                      {/* MARKET STATS */}
                      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
                        <div className="bg-gray-50 p-4 border border-gray-100">
                          <div className="text-2xl font-bold text-[#a81933]">{update.medianValue}</div>
                          <div className="text-sm text-gray-600">Median Home Value</div>
                        </div>
                        <div className="bg-gray-50 p-4 border border-gray-100">
                          <div className="text-2xl font-bold text-[#504f56]">{update.avgDaysOnMarket}</div>
                          <div className="text-sm text-gray-600">Average Days on Market</div>
                        </div>
                        <div className="bg-gray-50 p-4 border border-gray-100">
                          <div className="text-2xl font-bold text-[#a81933]">{update.saleToListRatio}</div>
                          <div className="text-sm text-gray-600">Sale-to-List Ratio</div>
                        </div>
                      </div>

                      {/* OPPORTUNITY HIGHLIGHT */}
                      <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 mb-6">
                        <div className="flex items-center gap-2 mb-2">
                          <TrendingUp className="w-5 h-5 text-yellow-600" />
                          <span className="font-semibold text-yellow-800">Key Opportunity</span>
                        </div>
                        <p className="text-yellow-700">{update.opportunity}</p>
                      </div>

                      {/* SCRIPT PREVIEW */}
                      <div className="bg-gray-50 p-4 border border-gray-100 mb-6">
                        <h4 className="font-semibold text-[#504f56] mb-2">Market Update Preview:</h4>
                        <p className="text-gray-700 text-sm leading-relaxed">
                          "{update.script.substring(0, 200)}..."
                        </p>
                      </div>
                    </div>

                    {/* VOICE PLAYER COLUMN */}
                    <div className="lg:col-span-4">
                      <div className="bg-gradient-to-br from-[#a81933] to-[#b8203a] p-6 text-white">
                        <div className="flex items-center gap-3 mb-4">
                          <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                            <PlayCircle className="w-6 h-6" />
                          </div>
                          <div>
                            <h3 className="font-bold">Listen to Chris</h3>
                            <p className="text-white/80 text-sm">AI Voice Clone</p>
                          </div>
                        </div>
                        
                        <VoicePlayer 
                          text={update.script}
                          voiceType="market-update"
                          className="justify-start"
                        />
                        
                        <div className="mt-4 pt-4 border-t border-white/20">
                          <div className="flex items-center gap-2 text-sm text-white/80">
                            <Users className="w-4 h-4" />
                            <span>Perfect for: Email campaigns, social media, client outreach</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA SECTION */}
      <section className="py-16 bg-gradient-to-br from-[#504f56] to-[#161019]">
        <div className="max-w-4xl mx-auto px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-white mb-6">
            Want a Custom Market Update for Your Neighborhood?
          </h2>
          <p className="text-xl text-white/80 mb-8 leading-relaxed">
            Get a personalized market analysis delivered in Chris's voice, tailored to your specific property and goals.
          </p>
          <button className="bg-gradient-to-r from-[#a81933] to-[#b8203a] hover:from-[#b8203a] hover:to-[#c82d41] text-white font-bold text-lg px-12 py-4 shadow-2xl hover:shadow-[#a81933]/50 hover:-translate-y-1 transition-all duration-300">
            Request Your Custom Market Update
          </button>
        </div>
      </section>
    </div>
  );
}