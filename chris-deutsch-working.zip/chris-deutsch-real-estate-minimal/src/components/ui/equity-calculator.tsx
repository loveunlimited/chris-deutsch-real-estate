'use client';

import { useState, useEffect } from 'react';
import { Card } from './card';
import { Button } from './button';
import { TrendingUp, Home, Calculator, DollarSign } from 'lucide-react';

interface EquityCalculation {
  originalValue: number;
  currentValue: number;
  equityGain: number;
  monthlyAppreciation: number;
  upgradeOpportunity: number;
}

export default function EquityCalculator() {
  const [purchaseYear, setPurchaseYear] = useState<string>('2017');
  const [originalPrice, setOriginalPrice] = useState<string>('425000');
  const [zipCode, setZipCode] = useState<string>('55416');
  const [calculation, setCalculation] = useState<EquityCalculation | null>(null);
  const [isCalculating, setIsCalculating] = useState(false);
  const [showResults, setShowResults] = useState(false);

  const goldenValleyZips = ['55416', '55426'];
  const brynMawrZips = ['55405', '55411'];

  const calculateEquity = async () => {
    setIsCalculating(true);
    
    // Simulate API calculation with realistic Twin Cities data
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const yearsOwned = 2024 - parseInt(purchaseYear);
    const original = parseInt(originalPrice);
    
    // Market-specific appreciation rates
    let annualAppreciation = 0.065; // 6.5% average
    if (goldenValleyZips.includes(zipCode)) {
      annualAppreciation = 0.075; // 7.5% for Golden Valley
    } else if (brynMawrZips.includes(zipCode)) {
      annualAppreciation = 0.082; // 8.2% for Bryn Mawr
    }
    
    const currentValue = original * Math.pow(1 + annualAppreciation, yearsOwned);
    const equityGain = currentValue - original;
    const monthlyAppreciation = equityGain / (yearsOwned * 12);
    const upgradeOpportunity = currentValue * 0.8; // 80% loan-to-value
    
    setCalculation({
      originalValue: original,
      currentValue: Math.round(currentValue),
      equityGain: Math.round(equityGain),
      monthlyAppreciation: Math.round(monthlyAppreciation),
      upgradeOpportunity: Math.round(upgradeOpportunity)
    });
    
    setIsCalculating(false);
    setShowResults(true);
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const getNeighborhoodName = (zip: string) => {
    if (goldenValleyZips.includes(zip)) return 'Golden Valley';
    if (brynMawrZips.includes(zip)) return 'Bryn Mawr';
    return 'Twin Cities';
  };

  return (
    <Card className="p-8 bg-gradient-to-br from-[#a81933]/5 via-white to-[#504f56]/5 border-2 border-[#a81933]/20 interactive-card">
      <div className="text-center mb-8">
        <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-[#a81933] to-[#b8203a] rounded-full mb-4 animate-pulse-glow">
          <Calculator className="w-8 h-8 text-white" />
        </div>
        <h3 className="text-2xl font-bold text-[#504f56] mb-2">
          Twin Cities Equity Calculator
        </h3>
        <p className="text-gray-600">
          Discover your home's potential with Chris's 25 years of market expertise
        </p>
      </div>

      {!showResults ? (
        <div className="space-y-6">
          {/* Input Form */}
          <div className="grid md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <label className="block text-sm font-semibold text-[#504f56]">
                Purchase Year
              </label>
              <select
                value={purchaseYear}
                onChange={(e) => setPurchaseYear(e.target.value)}
                className="w-full p-3 border-2 border-gray-200 rounded-lg focus:border-[#a81933] focus:ring-2 focus:ring-[#a81933]/20 transition-all duration-200"
              >
                {Array.from({ length: 15 }, (_, i) => 2024 - i).map(year => (
                  <option key={year} value={year}>{year}</option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-semibold text-[#504f56]">
                Original Purchase Price
              </label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-3.5 w-5 h-5 text-gray-400" />
                <input
                  type="text"
                  value={originalPrice}
                  onChange={(e) => setOriginalPrice(e.target.value.replace(/[^0-9]/g, ''))}
                  placeholder="425,000"
                  className="w-full pl-10 p-3 border-2 border-gray-200 rounded-lg focus:border-[#a81933] focus:ring-2 focus:ring-[#a81933]/20 transition-all duration-200"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="block text-sm font-semibold text-[#504f56]">
                Zip Code
              </label>
              <div className="relative">
                <Home className="absolute left-3 top-3.5 w-5 h-5 text-gray-400" />
                <select
                  value={zipCode}
                  onChange={(e) => setZipCode(e.target.value)}
                  className="w-full pl-10 p-3 border-2 border-gray-200 rounded-lg focus:border-[#a81933] focus:ring-2 focus:ring-[#a81933]/20 transition-all duration-200"
                >
                  <optgroup label="Golden Valley - Chris's Specialty">
                    <option value="55416">55416 - Golden Valley</option>
                    <option value="55426">55426 - Golden Valley</option>
                  </optgroup>
                  <optgroup label="Bryn Mawr - Chris's Specialty">
                    <option value="55405">55405 - Bryn Mawr</option>
                    <option value="55411">55411 - Bryn Mawr</option>
                  </optgroup>
                  <optgroup label="Other Twin Cities">
                    <option value="55436">55436 - Edina</option>
                    <option value="55447">55447 - Plymouth</option>
                    <option value="55391">55391 - Wayzata</option>
                    <option value="55343">55343 - Hopkins</option>
                  </optgroup>
                </select>
              </div>
            </div>
          </div>

          {/* Market Insight */}
          <div className="bg-gradient-to-r from-yellow-50 to-yellow-100 border-l-4 border-yellow-400 p-4 rounded-lg">
            <div className="flex items-center gap-3">
              <TrendingUp className="w-5 h-5 text-yellow-600" />
              <div>
                <h4 className="font-semibold text-yellow-800">
                  {getNeighborhoodName(zipCode)} Market Insight
                </h4>
                <p className="text-yellow-700 text-sm">
                  {goldenValleyZips.includes(zipCode) 
                    ? "Chris's specialty area! Golden Valley has seen exceptional growth with premium school districts and convenient Minneapolis access."
                    : brynMawrZips.includes(zipCode)
                    ? "Chris's expertise area! Bryn Mawr offers unique character with strong appreciation and downtown proximity."
                    : "Strong Twin Cities market with steady appreciation and diverse opportunities."
                  }
                </p>
              </div>
            </div>
          </div>

          {/* Calculate Button */}
          <Button
            onClick={calculateEquity}
            disabled={isCalculating}
            className="w-full bg-gradient-to-r from-[#a81933] to-[#b8203a] hover:from-[#b8203a] hover:to-[#c82d41] text-white font-bold py-4 text-lg animate-pulse-glow"
          >
            {isCalculating ? (
              <div className="flex items-center justify-center gap-3">
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                Calculating Your Equity...
              </div>
            ) : (
              <div className="flex items-center justify-center gap-3">
                <Calculator className="w-5 h-5" />
                Calculate My Home Equity
              </div>
            )}
          </Button>
        </div>
      ) : (
        <div className="space-y-6">
          {/* Results Header */}
          <div className="text-center pb-6 border-b border-gray-200">
            <h4 className="text-xl font-bold text-[#504f56] mb-2">
              Your {getNeighborhoodName(zipCode)} Equity Analysis
            </h4>
            <p className="text-gray-600">
              Based on {2024 - parseInt(purchaseYear)} years of ownership • Chris Deutsch expertise
            </p>
          </div>

          {/* Results Grid */}
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="bg-gradient-to-br from-green-50 to-green-100 p-6 rounded-xl border border-green-200">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-green-700 font-medium">Current Estimated Value</span>
                  <TrendingUp className="w-5 h-5 text-green-600" />
                </div>
                <div className="text-3xl font-bold text-green-800 animate-number-count">
                  {formatCurrency(calculation!.currentValue)}
                </div>
                <div className="text-sm text-green-600 mt-1">
                  Originally: {formatCurrency(calculation!.originalValue)}
                </div>
              </div>

              <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-6 rounded-xl border border-blue-200">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-blue-700 font-medium">Total Equity Gain</span>
                  <DollarSign className="w-5 h-5 text-blue-600" />
                </div>
                <div className="text-3xl font-bold text-blue-800 animate-number-count">
                  {formatCurrency(calculation!.equityGain)}
                </div>
                <div className="text-sm text-blue-600 mt-1">
                  Monthly: +{formatCurrency(calculation!.monthlyAppreciation)}
                </div>
              </div>
            </div>

            <div className="space-y-4">
              <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-6 rounded-xl border border-purple-200">
                <div className="flex items-center justify-between mb-3">
                  <span className="text-purple-700 font-medium">Upgrade Opportunity</span>
                  <Home className="w-5 h-5 text-purple-600" />
                </div>
                <div className="text-3xl font-bold text-purple-800 animate-number-count">
                  {formatCurrency(calculation!.upgradeOpportunity)}
                </div>
                <div className="text-sm text-purple-600 mt-1">
                  Potential loan amount (80% LTV)
                </div>
              </div>

              <div className="bg-gradient-to-br from-[#a81933]/10 to-[#504f56]/10 p-6 rounded-xl border border-[#a81933]/20">
                <div className="text-center">
                  <h5 className="font-bold text-[#504f56] mb-2">Ready to Explore Options?</h5>
                  <p className="text-sm text-gray-600 mb-4">
                    Chris's 25 years of {getNeighborhoodName(zipCode)} expertise can help you maximize this equity.
                  </p>
                  <Button className="w-full bg-gradient-to-r from-[#a81933] to-[#b8203a] hover:from-[#b8203a] hover:to-[#c82d41] text-white">
                    Get Free Market Analysis
                  </Button>
                </div>
              </div>
            </div>
          </div>

          {/* Reset Button */}
          <div className="text-center pt-4 border-t border-gray-200">
            <Button
              onClick={() => {
                setShowResults(false);
                setCalculation(null);
              }}
              variant="outline"
              className="text-[#504f56] border-[#504f56] hover:bg-[#504f56] hover:text-white"
            >
              Calculate Another Property
            </Button>
          </div>
        </div>
      )}

      {/* Disclaimer */}
      <div className="mt-6 pt-4 border-t border-gray-200">
        <p className="text-xs text-gray-500 text-center">
          *Estimates based on Twin Cities market trends and historical data. 
          Contact Chris Deutsch for personalized market analysis.
        </p>
      </div>
    </Card>
  );
}