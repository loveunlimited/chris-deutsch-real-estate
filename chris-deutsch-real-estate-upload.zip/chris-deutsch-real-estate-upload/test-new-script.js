/**
 * TEST NEW SCRIPT - Chris's Updated Conversational Style
 */

require('dotenv').config();

async function testNewScript() {
  console.log('🎤 Testing Chris\'s updated conversational script...');
  
  const newScript = `You know, after 25 years serving Twin Cities families, I'm honestly excited to share some remarkable developments happening right here in our Golden Valley market.

If you're a homeowner in the 55416 or 55426 zip codes, you're actually sitting on some incredible equity growth. Homes in your area have appreciated significantly, and frankly, the numbers are impressive - median values are now reaching around $495,000 in prime Golden Valley neighborhoods.

Here's what this really means for you: If you purchased your home 7 to 10 years ago, you likely have substantial equity that opens up some exciting possibilities. Many of my Golden Valley clients are discovering they can actually afford to move up to their dream home, or honestly, right-size to something that better fits their current lifestyle.`;

  console.log('📝 Script length:', newScript.split(' ').length, 'words');
  console.log('⏱️ Estimated duration: 45-60 seconds');
  
  try {
    console.log('🎤 Generating with your optimized voice settings...');
    
    const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${process.env.ELEVENLABS_VOICE_ID}`, {
      method: 'POST',
      headers: {
        'Accept': 'audio/mpeg',
        'Content-Type': 'application/json',
        'xi-api-key': process.env.ELEVENLABS_API_KEY
      },
      body: JSON.stringify({
        text: newScript,
        model_id: "eleven_monolingual_v1",
        voice_settings: {
          speed: 1.05,       // Perfect pace
          stability: 0.65,   // More pitch variation while staying expressive  
          similarity_boost: 0.7    // Better authenticity balance
        }
      })
    });

    console.log('Response status:', response.status);
    
    if (response.ok) {
      const audioBuffer = await response.arrayBuffer();
      const fs = require('fs');
      fs.writeFileSync('./new-script-test.mp3', Buffer.from(audioBuffer));
      
      console.log('✅ SUCCESS! New script audio created: new-script-test.mp3');
      console.log('🎯 File size:', (audioBuffer.byteLength / 1024).toFixed(1), 'KB');
      console.log('🎙️ Much more conversational and authentic!');
    } else {
      const errorText = await response.text();
      console.log('❌ Error response:', errorText);
    }
    
  } catch (error) {
    console.log('❌ Network error:', error.message);
  }
}

testNewScript();