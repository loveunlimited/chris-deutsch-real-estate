import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        luxury: {
          primary: '#a81933',      // Rich burgundy - premium CTAs and accents
          executive: '#504f56',    // Sophisticated charcoal - authority and gravitas
          content: '#807f86',      // Refined gray - elegant readability
          background: '#b7b7bd',   // Sophisticated light gray - luxury sections
          accent: '#161019',       // Deep navy - navigation and premium elements
        },
        primary: '#a81933',
        secondary: '#504f56',
        muted: '#807f86',
      },
      fontFamily: {
        'luxury': ['Inter', 'system-ui', 'sans-serif'],
        'executive': ['Playfair Display', 'serif'],
      },
      fontSize: {
        'hero': ['4.5rem', { lineHeight: '1.1', letterSpacing: '-0.02em' }],
        'executive': ['3rem', { lineHeight: '1.2', letterSpacing: '-0.01em' }],
        'luxury': ['1.125rem', { lineHeight: '1.7', letterSpacing: '0.01em' }],
      },
      spacing: {
        '18': '4.5rem',
        '22': '5.5rem',
        '26': '6.5rem',
        '30': '7.5rem',
      },
      animation: {
        'luxury-fade': 'luxury-fade 0.8s ease-out',
        'slide-up': 'slide-up 0.6s ease-out',
        'premium-hover': 'premium-hover 0.3s ease-in-out',
      },
      boxShadow: {
        'luxury': '0 25px 50px -12px rgba(168, 25, 51, 0.15)',
        'executive': '0 20px 40px -12px rgba(80, 79, 86, 0.2)',
        'premium': '0 32px 64px -12px rgba(22, 16, 25, 0.3)',
      },
    },
  },
  plugins: [],
};
export default config;