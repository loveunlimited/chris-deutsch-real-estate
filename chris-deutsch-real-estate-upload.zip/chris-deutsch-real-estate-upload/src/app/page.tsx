import Navigation from "@/components/ui/navigation";
import HeyGenAvatar from "@/components/ui/heygen-avatar";
import VoicePlayer from "@/components/ui/voice-player";
import EquityCalculator from "@/components/ui/equity-calculator";
import InteractiveMarketMap from "@/components/ui/interactive-market-map";
import SmartLeadCapture from "@/components/ui/smart-lead-capture";
import ClientSuccessShowcase from "@/components/ui/client-success-showcase";
import { Phone, Mail, MapPin, Award, Users, Clock, Star, TrendingUp, Shield, CheckCircle, ArrowRight, PlayCircle, Calculator, Home, Sparkles } from "lucide-react";

export default function Home() {
  return (
    <div className="min-h-screen">
      <Navigation />
      
      {/* VISUALLY STUNNING LUXURY HERO SECTION */}
      <section className="relative overflow-hidden pt-20 min-h-screen bg-gradient-to-br from-[#a81933] via-[#504f56] to-[#161019]">
        {/* Dramatic Background Elements */}
        <div className="absolute inset-0 bg-gradient-to-br from-[#a81933]/90 via-[#504f56]/80 to-[#161019]/95"></div>
        <div className="absolute top-0 right-0 w-1/2 h-full bg-gradient-to-l from-white/5 to-transparent"></div>
        <div className="absolute bottom-0 left-0 w-1/2 h-full bg-gradient-to-r from-[#a81933]/20 to-transparent"></div>
        
        <div className="relative max-w-7xl mx-auto px-6 lg:px-8 py-20 lg:py-32">
          <div className="grid lg:grid-cols-12 gap-16 items-center">
            {/* DRAMATICALLY STYLED LEFT COLUMN */}
            <div className="lg:col-span-7 space-y-12 animate-luxury-fade relative z-10">
              <div className="space-y-10">
                {/* PREMIUM GOLD BADGE */}
                <div className="inline-flex items-center gap-4 bg-gradient-to-r from-yellow-400/20 to-yellow-500/20 backdrop-blur-lg px-8 py-4 border-2 border-yellow-400/30 shadow-2xl">
                  <Award className="w-8 h-8 text-yellow-400" />
                  <span className="font-sans font-bold text-white tracking-wider text-lg">
                    25 YEARS TWIN CITIES EXCELLENCE
                  </span>
                </div>

                {/* MASSIVE DRAMATIC HEADLINE */}
                <div className="space-y-8">
                  <h1 className="font-serif text-7xl lg:text-8xl font-black text-white leading-none tracking-tight drop-shadow-2xl">
                    Chris Deutsch
                    <span className="block text-6xl lg:text-7xl bg-gradient-to-r from-yellow-400 via-yellow-500 to-yellow-600 bg-clip-text text-transparent">
                      Real Estate
                    </span>
                  </h1>
                  
                  <p className="text-3xl lg:text-4xl font-sans font-light text-white/90 leading-relaxed tracking-wide max-w-2xl drop-shadow-lg">
                    Real achievements. Real results. Real peace of mind.
                  </p>
                  
                  <p className="text-xl font-sans text-white/80 leading-loose max-w-xl">
                    Specializing in Golden Valley &amp; Bryn Mawr with comprehensive Twin Cities expertise. 
                    <span className="font-semibold text-white"> Let a quarter-century of experience deliver exceptional results.</span>
                  </p>
                  
                  {/* AI VOICE MARKET UPDATE */}
                  <div className="bg-white/10 backdrop-blur-lg p-6 border border-white/20 shadow-xl max-w-2xl">
                    <div className="flex items-center gap-4 mb-4">
                      <div className="flex items-center justify-center w-12 h-12 bg-yellow-400/20 rounded-full">
                        <PlayCircle className="w-6 h-6 text-yellow-400" />
                      </div>
                      <div>
                        <h3 className="text-lg font-bold text-white">Latest Golden Valley Market Update</h3>
                        <p className="text-white/70 text-sm">Powered by AI Voice Clone Technology</p>
                      </div>
                    </div>
                    <p className="text-white/80 text-sm mb-4 leading-relaxed">
                      "Hi, this is Chris Deutsch with your Golden Valley market update. After 25 years serving Twin Cities families, 
                      I'm excited to share some remarkable developments in our Golden Valley market..."
                    </p>
                    <VoicePlayer 
                      text="Hi, this is Chris Deutsch with your Golden Valley market update for December 2024. After 25 years serving Twin Cities families, I'm excited to share some remarkable developments in our Golden Valley market. If you're a homeowner in the 55416 or 55426 zip codes, you're sitting on some incredible equity growth. Homes in your area have appreciated significantly, with median values now reaching $485,000 in prime Golden Valley neighborhoods."
                      voiceType="market-update"
                      className="justify-start"
                    />
                  </div>
                </div>

                {/* LUXURY CREDENTIALS WITH BACKGROUNDS */}
                <div className="flex flex-wrap gap-4">
                  {['REALTOR®', 'NAR', 'MNAR', 'Northstar MLS'].map((credential) => (
                    <span key={credential} className="bg-white/15 backdrop-blur-sm text-white px-6 py-3 text-base font-bold tracking-wide border border-white/20 shadow-xl hover:bg-white/25 transition-all duration-300">
                      {credential}
                    </span>
                  ))}
                </div>

                {/* STUNNING CTA BUTTONS */}
                <div className="flex flex-col lg:flex-row gap-6 pt-6">
                  <button className="group bg-gradient-to-r from-[#a81933] to-[#b8203a] hover:from-[#b8203a] hover:to-[#c82d41] text-white font-bold text-lg px-12 py-6 shadow-2xl hover:shadow-[#a81933]/50 hover:-translate-y-1 transition-all duration-300 border-2 border-white/20">
                    <div className="flex items-center justify-center gap-3">
                      Get Your Free Market Analysis
                      <ArrowRight className="w-6 h-6 group-hover:translate-x-2 transition-transform duration-300" />
                    </div>
                  </button>
                  <button className="group bg-white/10 backdrop-blur-sm text-white font-bold text-lg px-12 py-6 border-2 border-white/40 hover:bg-white hover:text-[#504f56] transition-all duration-300 shadow-xl">
                    <div className="flex items-center justify-center gap-3">
                      <Phone className="w-6 h-6 group-hover:rotate-12 transition-transform duration-300" />
                      Schedule Private Consultation
                    </div>
                  </button>
                </div>

                {/* ELEGANT CONTACT CARDS */}
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 pt-8">
                  <div className="bg-white/10 backdrop-blur-lg p-6 border border-white/20 shadow-xl hover:bg-white/15 transition-all duration-300">
                    <div className="flex items-center gap-4">
                      <div className="flex items-center justify-center w-14 h-14 bg-[#a81933] shadow-lg">
                        <Mail className="w-7 h-7 text-white" />
                      </div>
                      <div>
                        <p className="text-base font-semibold text-white/90">Email</p>
                        <p className="font-sans font-bold text-white text-lg">chris@chrisdeutsch.com</p>
                      </div>
                    </div>
                  </div>
                  <div className="bg-white/10 backdrop-blur-lg p-6 border border-white/20 shadow-xl hover:bg-white/15 transition-all duration-300">
                    <div className="flex items-center gap-4">
                      <div className="flex items-center justify-center w-14 h-14 bg-[#504f56] shadow-lg">
                        <MapPin className="w-7 h-7 text-white" />
                      </div>
                      <div>
                        <p className="text-base font-semibold text-white/90">Specializing</p>
                        <p className="font-sans font-bold text-white text-lg">Golden Valley &amp; Twin Cities</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            {/* STUNNING RIGHT COLUMN WITH DRAMATIC VISUALS */}
            <div className="lg:col-span-5 relative animate-slide-up">
              <div className="relative max-w-lg mx-auto">
                {/* DRAMATIC PHOTO CONTAINER WITH RICH BACKGROUNDS */}
                <div className="relative">
                  <div className="aspect-[4/5] bg-gradient-to-br from-white/20 via-yellow-400/10 to-white/5 backdrop-blur-lg border-4 border-white/30 shadow-2xl flex items-center justify-center">
                    <div className="text-center">
                      <div className="w-40 h-40 bg-gradient-to-br from-yellow-400 via-yellow-500 to-yellow-600 rounded-full mx-auto mb-8 flex items-center justify-center shadow-2xl border-4 border-white/40">
                        <Users className="w-20 h-20 text-white drop-shadow-lg" />
                      </div>
                      <p className="text-2xl font-executive font-bold text-white mb-3 drop-shadow-lg">Professional Headshot</p>
                      <p className="text-white/80 font-luxury text-lg">Premium Photography Coming Soon</p>
                    </div>
                  </div>
                  
                  {/* FLOATING STATS WITH RICH BACKGROUNDS */}
                  <div className="absolute -left-8 top-16 bg-gradient-to-r from-[#a81933] to-[#b8203a] p-8 shadow-2xl border-2 border-white/20 animate-luxury-fade" style={{animationDelay: '0.3s'}}>
                    <div className="flex items-center gap-4">
                      <div className="flex items-center justify-center w-16 h-16 bg-white/20 backdrop-blur-sm shadow-lg">
                        <Clock className="w-8 h-8 text-white" />
                      </div>
                      <div>
                        <p className="text-4xl font-executive font-black text-white drop-shadow-lg">25</p>
                        <p className="text-base font-luxury font-bold text-white/90 tracking-wide">Years Excellence</p>
                      </div>
                    </div>
                  </div>
                  
                  <div className="absolute -right-8 bottom-16 bg-gradient-to-r from-[#504f56] to-[#605f66] p-8 shadow-2xl border-2 border-white/20 animate-luxury-fade" style={{animationDelay: '0.6s'}}>
                    <div className="flex items-center gap-4">
                      <div className="flex items-center justify-center w-16 h-16 bg-white/20 backdrop-blur-sm shadow-lg">
                        <TrendingUp className="w-8 h-8 text-white" />
                      </div>
                      <div>
                        <p className="text-4xl font-executive font-black text-white drop-shadow-lg">Expert</p>
                        <p className="text-base font-luxury font-bold text-white/90 tracking-wide">Market Authority</p>
                      </div>
                    </div>
                  </div>

                  {/* PREMIUM VOICE BADGE WITH GOLDEN GLOW */}
                  <div className="absolute top-8 right-8 bg-gradient-to-r from-yellow-400 to-yellow-500 text-[#161019] p-4 shadow-2xl animate-luxury-fade border-2 border-white/30" style={{animationDelay: '0.9s'}}>
                    <PlayCircle className="w-8 h-8 drop-shadow-lg" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* HEYGEN AI AVATAR INTEGRATION */}
      <section className="py-24 bg-gradient-to-b from-white to-[#f8f8f9]">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-5xl font-serif font-bold text-[#504f56] mb-6">
              Meet Chris Deutsch <span className="text-[#a81933]">Virtually</span>
            </h2>
            <p className="text-xl text-[#807f86] max-w-3xl mx-auto leading-relaxed">
              Experience the future of real estate consultation. Chat face-to-face with Chris using our advanced AI avatar technology. 
              Get instant answers about the Twin Cities market, Golden Valley properties, and personalized real estate advice.
            </p>
          </div>
          
          <HeyGenAvatar className="mb-16" />
          
          <div className="grid md:grid-cols-3 gap-8 mt-16">
            <div className="text-center p-6 bg-white border border-[#b7b7bd]/20 shadow-lg hover:shadow-xl transition-all duration-300">
              <div className="w-16 h-16 bg-gradient-to-br from-[#a81933] to-[#b8203a] rounded-full mx-auto mb-4 flex items-center justify-center">
                <Users className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-[#504f56] mb-2">Real-Time Conversation</h3>
              <p className="text-[#807f86]">Chat naturally with Chris's AI avatar for instant responses to your real estate questions.</p>
            </div>
            
            <div className="text-center p-6 bg-white border border-[#b7b7bd]/20 shadow-lg hover:shadow-xl transition-all duration-300">
              <div className="w-16 h-16 bg-gradient-to-br from-[#504f56] to-[#605f66] rounded-full mx-auto mb-4 flex items-center justify-center">
                <TrendingUp className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-[#504f56] mb-2">Market Expertise</h3>
              <p className="text-[#807f86]">Get insights on Twin Cities market conditions, property values, and neighborhood trends.</p>
            </div>
            
            <div className="text-center p-6 bg-white border border-[#b7b7bd]/20 shadow-lg hover:shadow-xl transition-all duration-300">
              <div className="w-16 h-16 bg-gradient-to-br from-[#ffd42f] to-[#ffab00] rounded-full mx-auto mb-4 flex items-center justify-center">
                <Clock className="w-8 h-8 text-[#161019]" />
              </div>
              <h3 className="text-xl font-semibold text-[#504f56] mb-2">Available 24/7</h3>
              <p className="text-[#807f86]">Connect with Chris's expertise anytime, even outside regular business hours.</p>
            </div>
          </div>
        </div>
      </section>

      {/* DRAMATICALLY STYLED TRUST INDICATORS */}
      <section className="py-24 bg-gradient-to-b from-[#b7b7bd] to-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { icon: Award, number: "25+", label: "Years of Excellence", bg: "from-[#a81933] to-[#b8203a]" },
              { icon: Shield, number: "Twin Cities", label: "Market Authority", bg: "from-[#504f56] to-[#605f66]" },
              { icon: CheckCircle, number: "Stress-Free", label: "Premium Experience", bg: "from-[#a81933] to-[#b8203a]" },
              { icon: Star, number: "Elite", label: "Professional Service", bg: "from-[#504f56] to-[#605f66]" }
            ].map((item, index) => (
              <div key={index} className="group cursor-pointer animate-luxury-fade" style={{animationDelay: `${index * 0.2}s`}}>
                <div className={`bg-gradient-to-br ${item.bg} p-8 shadow-2xl hover:shadow-3xl transition-all duration-500 hover:-translate-y-2 border border-white/20`}>
                  <div className="text-center text-white">
                    <div className="flex items-center justify-center mb-6">
                      <div className="w-20 h-20 bg-white/20 backdrop-blur-sm flex items-center justify-center group-hover:bg-white/30 transition-all duration-300 border border-white/30">
                        <item.icon className="w-10 h-10 text-white" />
                      </div>
                    </div>
                    <div className="text-5xl font-serif font-black mb-4 group-hover:scale-110 transition-transform duration-300 drop-shadow-lg">
                      {item.number}
                    </div>
                    <p className="text-white/90 font-sans font-bold tracking-wide text-lg">
                      {item.label}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* INTERACTIVE EQUITY CALCULATOR SECTION */}
      <section className="py-24 bg-gradient-to-b from-white to-[#f8f8f9]">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-3 bg-gradient-to-r from-yellow-400/20 to-yellow-500/20 backdrop-blur-lg px-6 py-3 border border-yellow-400/30 mb-8 animate-floating">
              <Calculator className="w-6 h-6 text-yellow-600" />
              <span className="font-bold text-yellow-800 tracking-wide">DISCOVER YOUR EQUITY POTENTIAL</span>
            </div>
            <h2 className="text-5xl font-serif font-bold text-[#504f56] mb-6">
              What's Your Home <span className="text-[#a81933]">Really Worth?</span>
            </h2>
            <p className="text-xl text-[#807f86] max-w-3xl mx-auto leading-relaxed">
              Use Chris's 25 years of Twin Cities expertise to discover your home's hidden equity. 
              Many Golden Valley and Bryn Mawr homeowners are sitting on significant opportunities.
            </p>
          </div>
          
          <EquityCalculator />
        </div>
      </section>

      {/* INTERACTIVE MARKET MAP SECTION */}
      <section className="py-24 bg-gradient-to-br from-[#504f56]/5 via-white to-[#a81933]/5">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-3 bg-gradient-to-r from-[#a81933]/20 to-[#504f56]/20 backdrop-blur-lg px-6 py-3 border border-[#a81933]/30 mb-8 animate-slide-in-left">
              <MapPin className="w-6 h-6 text-[#a81933]" />
              <span className="font-bold text-[#a81933] tracking-wide">EXPLORE TWIN CITIES MARKETS</span>
            </div>
            <h2 className="text-5xl font-serif font-bold text-[#504f56] mb-6">
              Interactive Market <span className="text-[#a81933]">Intelligence</span>
            </h2>
            <p className="text-xl text-[#807f86] max-w-3xl mx-auto leading-relaxed">
              Navigate Chris's specialty neighborhoods and discover market opportunities with 
              real-time insights from 25 years of local expertise.
            </p>
          </div>
          
          <InteractiveMarketMap />
        </div>
      </section>

      {/* HEYGEN AI AVATAR INTEGRATION - ENHANCED */}
      <section className="py-24 bg-gradient-to-b from-white to-[#f8f8f9] relative overflow-hidden">
        {/* Animated Background Elements */}
        <div className="absolute top-0 right-0 w-96 h-96 bg-gradient-to-br from-[#a81933]/10 to-transparent rounded-full blur-3xl animate-floating"></div>
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-gradient-to-tr from-[#504f56]/10 to-transparent rounded-full blur-3xl animate-floating" style={{animationDelay: '1s'}}></div>
        
        <div className="relative max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-3 bg-gradient-to-r from-blue-400/20 to-blue-500/20 backdrop-blur-lg px-6 py-3 border border-blue-400/30 mb-8 animate-pulse-glow">
              <Sparkles className="w-6 h-6 text-blue-600" />
              <span className="font-bold text-blue-800 tracking-wide">AI-POWERED CONSULTATION</span>
            </div>
            <h2 className="text-5xl font-serif font-bold text-[#504f56] mb-6">
              Meet Chris Deutsch <span className="text-[#a81933]">Virtually</span>
            </h2>
            <p className="text-xl text-[#807f86] max-w-3xl mx-auto leading-relaxed">
              Experience the future of real estate consultation. Chat face-to-face with Chris using our advanced AI avatar technology. 
              Get instant answers about the Twin Cities market, Golden Valley properties, and personalized real estate advice.
            </p>
          </div>
          
          <HeyGenAvatar className="mb-16" />
          
          <div className="grid md:grid-cols-3 gap-8 mt-16">
            <div className="text-center p-6 bg-white border border-[#b7b7bd]/20 shadow-lg hover:shadow-xl transition-all duration-300 interactive-card">
              <div className="w-16 h-16 bg-gradient-to-br from-[#a81933] to-[#b8203a] rounded-full mx-auto mb-4 flex items-center justify-center animate-floating">
                <Users className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-[#504f56] mb-2">Real-Time Conversation</h3>
              <p className="text-[#807f86]">Chat naturally with Chris's AI avatar for instant responses to your real estate questions.</p>
            </div>
            
            <div className="text-center p-6 bg-white border border-[#b7b7bd]/20 shadow-lg hover:shadow-xl transition-all duration-300 interactive-card">
              <div className="w-16 h-16 bg-gradient-to-br from-[#504f56] to-[#605f66] rounded-full mx-auto mb-4 flex items-center justify-center animate-floating" style={{animationDelay: '0.5s'}}>
                <TrendingUp className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-[#504f56] mb-2">Market Expertise</h3>
              <p className="text-[#807f86]">Get insights on Twin Cities market conditions, property values, and neighborhood trends.</p>
            </div>
            
            <div className="text-center p-6 bg-white border border-[#b7b7bd]/20 shadow-lg hover:shadow-xl transition-all duration-300 interactive-card">
              <div className="w-16 h-16 bg-gradient-to-br from-[#ffd42f] to-[#ffab00] rounded-full mx-auto mb-4 flex items-center justify-center animate-floating" style={{animationDelay: '1s'}}>
                <Clock className="w-8 h-8 text-[#161019]" />
              </div>
              <h3 className="text-xl font-semibold text-[#504f56] mb-2">Available 24/7</h3>
              <p className="text-[#807f86]">Connect with Chris's expertise anytime, even outside regular business hours.</p>
            </div>
          </div>
        </div>
      </section>

      {/* CLIENT SUCCESS STORIES SECTION */}
      <section className="py-24 bg-gradient-to-b from-white to-[#f8f8f9]">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <ClientSuccessShowcase />
        </div>
      </section>

      {/* SMART LEAD CAPTURE SECTION */}
      <section className="py-24 bg-gradient-to-br from-[#a81933]/5 via-white to-[#504f56]/5">
        <div className="max-w-4xl mx-auto px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-3 bg-gradient-to-r from-green-400/20 to-green-500/20 backdrop-blur-lg px-6 py-3 border border-green-400/30 mb-8 animate-slide-in-right">
              <Home className="w-6 h-6 text-green-600" />
              <span className="font-bold text-green-800 tracking-wide">START YOUR JOURNEY</span>
            </div>
            <h2 className="text-5xl font-serif font-bold text-[#504f56] mb-6">
              Ready for <span className="text-[#a81933]">Stress-Free</span> Results?
            </h2>
            <p className="text-xl text-[#807f86] max-w-3xl mx-auto leading-relaxed">
              Join James M., Ashley G., Jason R., John & Kathy L., and Mary C. who all experienced Chris's proven expertise. 
              Get personalized insights and discover your opportunities in the Twin Cities market.
            </p>
          </div>
          
          <SmartLeadCapture context="general" />
        </div>
      </section>

      {/* ENHANCED TRUST INDICATORS WITH ANIMATIONS */}
      <section className="py-24 bg-gradient-to-b from-[#b7b7bd] to-white">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            {[
              { icon: Award, number: "25+", label: "Years of Excellence", bg: "from-[#a81933] to-[#b8203a]", delay: "0s" },
              { icon: Shield, number: "Twin Cities", label: "Market Authority", bg: "from-[#504f56] to-[#605f66]", delay: "0.2s" },
              { icon: CheckCircle, number: "Stress-Free", label: "Premium Experience", bg: "from-[#a81933] to-[#b8203a]", delay: "0.4s" },
              { icon: Star, number: "Elite", label: "Professional Service", bg: "from-[#504f56] to-[#605f66]", delay: "0.6s" }
            ].map((item, index) => (
              <div key={index} className="group cursor-pointer animate-slide-in-left" style={{animationDelay: item.delay}}>
                <div className={`bg-gradient-to-br ${item.bg} p-8 shadow-2xl hover:shadow-3xl transition-all duration-500 hover:-translate-y-2 border border-white/20 interactive-card`}>
                  <div className="text-center text-white">
                    <div className="flex items-center justify-center mb-6">
                      <div className="w-20 h-20 bg-white/20 backdrop-blur-sm flex items-center justify-center group-hover:bg-white/30 transition-all duration-300 border border-white/30 animate-floating">
                        <item.icon className="w-10 h-10 text-white" />
                      </div>
                    </div>
                    <div className="text-5xl font-serif font-black mb-4 group-hover:scale-110 transition-transform duration-300 drop-shadow-lg animate-number-count">
                      {item.number}
                    </div>
                    <p className="text-white/90 font-sans font-bold tracking-wide text-lg">
                      {item.label}
                    </p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* LUXURY QUOTE SECTION WITH ENHANCED ANIMATIONS */}
      <section className="py-24 bg-gradient-to-br from-[#161019] via-[#504f56] to-[#a81933] relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-black/20 to-transparent"></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-96 h-96 bg-gradient-to-br from-yellow-400/10 to-transparent rounded-full blur-3xl animate-pulse-glow"></div>
        
        <div className="relative max-w-5xl mx-auto px-6 lg:px-8 text-center">
          <div className="bg-white/10 backdrop-blur-lg p-12 lg:p-16 border border-white/20 shadow-2xl interactive-card">
            <blockquote className="text-3xl lg:text-4xl font-serif font-light text-white leading-relaxed italic mb-10 drop-shadow-lg animate-slide-in-left">
              &ldquo;In real estate, experience isn&rsquo;t just about years&mdash;it&rsquo;s about results, relationships, and delivering peace of mind when it matters most.&rdquo;
            </blockquote>
            <div className="flex items-center justify-center gap-6 animate-slide-in-right">
              <div className="w-24 h-1 bg-gradient-to-r from-transparent via-yellow-400 to-transparent animate-floating"></div>
              <p className="font-sans font-bold text-white tracking-wider text-xl bg-gradient-to-r from-yellow-400 to-yellow-500 bg-clip-text text-transparent">
                CHRIS DEUTSCH, REALTOR®
              </p>
              <div className="w-24 h-1 bg-gradient-to-r from-transparent via-yellow-400 to-transparent animate-floating" style={{animationDelay: '1s'}}></div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
