'use client';

import { useState } from 'react';
import { Card } from './card';
import { Button } from './button';
import { Star, Quote, ArrowLeft, ArrowRight, Home, Users, Heart, Repeat } from 'lucide-react';

interface ClientStory {
  id: string;
  name: string;
  location: string;
  relationship: 'first-time' | 'repeat' | 'referrer';
  transactionType: string;
  yearsSince: number;
  rating: 5;
  headline: string;
  review: string;
  highlight: string;
  avatar: string;
}

const CLIENT_STORIES: ClientStory[] = [
  {
    id: 'james',
    name: 'James M.',
    location: 'Golden Valley',
    relationship: 'repeat',
    transactionType: 'Multiple Transactions',
    yearsSince: 8,
    rating: 5,
    headline: 'Eight Years of Trust - Chris Has Handled Everything',
    review: 'Chris has been our go-to real estate expert for over 8 years now. He helped us buy our first home in Golden Valley, then when we needed to upgrade, he sold that one and found us our dream house. The process was completely stress-free both times. What I appreciate most is how Chris knows the Golden Valley market inside and out - he knew exactly what our homes were worth and got us top dollar. We\'ve referred him to three family members because we trust him completely. When you work with Chris, you\'re not just getting an agent, you\'re getting a trusted advisor for life.',
    highlight: 'Multiple successful transactions over 8 years',
    avatar: 'JM'
  },
  {
    id: 'ashley',
    name: 'Ashley G.',
    location: 'Bryn Mawr',
    relationship: 'first-time',
    transactionType: 'First Home Purchase',
    yearsSince: 2,
    rating: 5,
    headline: 'Made My First Home Purchase Completely Stress-Free',
    review: 'As a first-time homebuyer, I was honestly terrified of the whole process. Chris made everything so easy and explained every step clearly. He found me the perfect Craftsman home in Bryn Mawr that I absolutely love. What impressed me most was how he anticipated problems before they happened and handled everything behind the scenes. I never felt pressured, and he was always available when I had questions. Two years later, I still get compliments on my beautiful home. Chris truly delivered on his promise of a stress-free experience.',
    highlight: 'Perfect first-time home buying experience',
    avatar: 'AG'
  },
  {
    id: 'jason',
    name: 'Jason R.',
    location: 'Plymouth',
    relationship: 'referrer',
    transactionType: 'Sale & Purchase',
    yearsSince: 5,
    rating: 5,
    headline: 'Five Years Later, Still Referring Friends to Chris',
    review: 'Chris helped us sell our Plymouth home and buy our current place in Golden Valley five years ago. The experience was so outstanding that we\'ve referred him to four different friends and family members since then. Every single one has thanked us! Chris has this amazing ability to understand exactly what you need and make it happen. He sold our old house for $15,000 over asking price and negotiated an incredible deal on our new home. His knowledge of the Twin Cities market is unmatched, and his integrity is rock solid. We wouldn\'t use anyone else.',
    highlight: 'Referred Chris to 4+ friends and family',
    avatar: 'JR'
  },
  {
    id: 'johnkathy',
    name: 'John & Kathy L.',
    location: 'Golden Valley',
    relationship: 'repeat',
    transactionType: 'Downsizing',
    yearsSince: 1,
    rating: 5,
    headline: 'Perfect Downsizing Strategy - Exceeded All Expectations',
    review: 'After living in our large Golden Valley home for 22 years, we knew it was time to downsize, but we were overwhelmed by the process. Chris developed a perfect strategy for us. He sold our family home for significantly more than we expected and helped us find a beautiful, maintenance-free townhome that\'s perfect for this stage of our lives. Throughout the entire process, Chris handled every detail with professionalism and care. He understood this was an emotional transition for us and made sure we felt comfortable every step of the way. We couldn\'t be happier with the results.',
    highlight: 'Successful downsizing strategy execution',
    avatar: 'JKL'
  },
  {
    id: 'mary',
    name: 'Mary C.',
    location: 'Edina',
    relationship: 'first-time',
    transactionType: 'Investment Property',
    yearsSince: 3,
    rating: 5,
    headline: 'Investment Property Success - Great Returns Thanks to Chris',
    review: 'Three years ago, I decided to invest in Twin Cities real estate but had no idea where to start. Chris educated me on the market, showed me properties with strong rental potential, and helped me purchase a fantastic duplex in Edina. His market knowledge was incredible - he knew which neighborhoods were appreciating and which properties would attract quality tenants. The investment has performed even better than projected. Chris didn\'t just sell me a property; he set me up for long-term financial success. I trust his expertise completely.',
    highlight: 'Successful investment property guidance',
    avatar: 'MC'
  }
];

export default function ClientSuccessShowcase() {
  const [currentStory, setCurrentStory] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);

  const nextStory = () => {
    if (isAnimating) return;
    setIsAnimating(true);
    setTimeout(() => {
      setCurrentStory((prev) => (prev + 1) % CLIENT_STORIES.length);
      setIsAnimating(false);
    }, 300);
  };

  const prevStory = () => {
    if (isAnimating) return;
    setIsAnimating(true);
    setTimeout(() => {
      setCurrentStory((prev) => (prev - 1 + CLIENT_STORIES.length) % CLIENT_STORIES.length);
      setIsAnimating(false);
    }, 300);
  };

  const goToStory = (index: number) => {
    if (isAnimating || index === currentStory) return;
    setIsAnimating(true);
    setTimeout(() => {
      setCurrentStory(index);
      setIsAnimating(false);
    }, 300);
  };

  const story = CLIENT_STORIES[currentStory];

  const getRelationshipIcon = (relationship: string) => {
    switch (relationship) {
      case 'repeat': return <Repeat className="w-5 h-5 text-blue-600" />;
      case 'referrer': return <Users className="w-5 h-5 text-green-600" />;
      default: return <Heart className="w-5 h-5 text-purple-600" />;
    }
  };

  const getRelationshipBadge = (relationship: string) => {
    switch (relationship) {
      case 'repeat': return { text: 'Repeat Client', color: 'bg-blue-100 text-blue-800' };
      case 'referrer': return { text: 'Active Referrer', color: 'bg-green-100 text-green-800' };
      default: return { text: 'Satisfied Client', color: 'bg-purple-100 text-purple-800' };
    }
  };

  return (
    <div className="max-w-6xl mx-auto space-y-8">
      {/* Header */}
      <div className="text-center">
        <div className="inline-flex items-center gap-3 bg-gradient-to-r from-yellow-400/20 to-yellow-500/20 backdrop-blur-lg px-6 py-3 border border-yellow-400/30 mb-8 animate-floating">
          <Star className="w-6 h-6 text-yellow-600 fill-yellow-600" />
          <span className="font-bold text-yellow-800 tracking-wide">CLIENT SUCCESS STORIES</span>
        </div>
        <h2 className="text-4xl lg:text-5xl font-serif font-bold text-[#504f56] mb-4">
          25 Years of <span className="text-[#a81933]">Stress-Free</span> Results
        </h2>
        <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
          Real clients, real results. See why Twin Cities families trust Chris Deutsch 
          for their most important real estate decisions.
        </p>
      </div>

      {/* Main Story Display */}
      <div className="grid lg:grid-cols-12 gap-8 items-center">
        
        {/* Story Card */}
        <div className="lg:col-span-8">
          <Card className={`p-8 h-full interactive-card relative overflow-hidden transition-all duration-300 ${isAnimating ? 'opacity-0 scale-95' : 'opacity-100 scale-100'}`}>
            {/* Background Pattern */}
            <div className="absolute top-0 right-0 w-32 h-32 opacity-5">
              <Quote className="w-full h-full text-[#a81933]" />
            </div>
            
            <div className="relative space-y-6">
              {/* Client Header */}
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-4">
                  <div className="w-16 h-16 bg-gradient-to-br from-[#a81933] to-[#b8203a] rounded-full flex items-center justify-center text-white font-bold text-lg shadow-lg">
                    {story.avatar}
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-[#504f56]">{story.name}</h3>
                    <div className="flex items-center gap-3 text-sm text-gray-600">
                      <span className="flex items-center gap-1">
                        <Home className="w-4 h-4" />
                        {story.location}
                      </span>
                      <span>•</span>
                      <span>{story.yearsSince} year{story.yearsSince > 1 ? 's' : ''} ago</span>
                    </div>
                  </div>
                </div>
                
                <div className="text-right">
                  <div className="flex items-center gap-1 mb-2">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="w-5 h-5 text-yellow-400 fill-yellow-400" />
                    ))}
                  </div>
                  <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium ${getRelationshipBadge(story.relationship).color}`}>
                    {getRelationshipIcon(story.relationship)}
                    {getRelationshipBadge(story.relationship).text}
                  </div>
                </div>
              </div>

              {/* Story Content */}
              <div className="space-y-4">
                <h4 className="text-lg font-semibold text-[#a81933]">
                  "{story.headline}"
                </h4>
                
                <blockquote className="text-gray-700 leading-relaxed text-lg italic border-l-4 border-[#a81933] pl-6">
                  "{story.review}"
                </blockquote>
                
                <div className="bg-gradient-to-r from-[#a81933]/10 to-[#504f56]/10 p-4 rounded-lg border-l-4 border-[#a81933]">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-[#a81933] rounded-full flex items-center justify-center">
                      <Star className="w-4 h-4 text-white fill-white" />
                    </div>
                    <div>
                      <h5 className="font-semibold text-[#504f56]">Key Success</h5>
                      <p className="text-sm text-gray-600">{story.highlight}</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Transaction Details */}
              <div className="pt-4 border-t border-gray-200">
                <div className="flex items-center justify-between text-sm text-gray-600">
                  <span className="font-medium">{story.transactionType}</span>
                  <span className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                    {story.rating}.0 Rating
                  </span>
                </div>
              </div>
            </div>
          </Card>
        </div>

        {/* Navigation & Stats */}
        <div className="lg:col-span-4 space-y-6">
          
          {/* Quick Stats */}
          <Card className="p-6 bg-gradient-to-br from-[#504f56]/5 to-[#a81933]/5">
            <h4 className="font-bold text-[#504f56] mb-4 text-center">Client Satisfaction</h4>
            <div className="grid grid-cols-2 gap-4">
              <div className="text-center">
                <div className="text-3xl font-bold text-[#a81933] animate-number-count">100%</div>
                <div className="text-sm text-gray-600">5-Star Reviews</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-[#504f56] animate-number-count">40%</div>
                <div className="text-sm text-gray-600">Repeat & Referral</div>
              </div>
            </div>
          </Card>

          {/* Story Navigation */}
          <Card className="p-6">
            <h4 className="font-semibold text-[#504f56] mb-4">More Success Stories</h4>
            
            <div className="space-y-3">
              {CLIENT_STORIES.map((clientStory, index) => (
                <button
                  key={clientStory.id}
                  onClick={() => goToStory(index)}
                  className={`w-full text-left p-3 rounded-lg transition-all duration-200 ${
                    index === currentStory
                      ? 'bg-[#a81933]/10 border border-[#a81933]/30'
                      : 'hover:bg-gray-50 border border-transparent'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold ${
                      index === currentStory 
                        ? 'bg-[#a81933] text-white' 
                        : 'bg-gray-200 text-gray-600'
                    }`}>
                      {clientStory.avatar}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-medium text-sm text-[#504f56] truncate">
                        {clientStory.name}
                      </div>
                      <div className="text-xs text-gray-500">
                        {clientStory.location} • {clientStory.transactionType}
                      </div>
                    </div>
                    {index === currentStory && (
                      <div className="text-[#a81933]">
                        <ArrowRight className="w-4 h-4" />
                      </div>
                    )}
                  </div>
                </button>
              ))}
            </div>
          </Card>

          {/* Navigation Controls */}
          <div className="flex items-center justify-between">
            <Button
              onClick={prevStory}
              variant="outline"
              size="sm"
              disabled={isAnimating}
              className="flex items-center gap-2"
            >
              <ArrowLeft className="w-4 h-4" />
              Previous
            </Button>
            
            <div className="flex items-center gap-2">
              {CLIENT_STORIES.map((_, index) => (
                <button
                  key={index}
                  onClick={() => goToStory(index)}
                  className={`w-2 h-2 rounded-full transition-all duration-200 ${
                    index === currentStory ? 'bg-[#a81933] w-6' : 'bg-gray-300'
                  }`}
                />
              ))}
            </div>
            
            <Button
              onClick={nextStory}
              variant="outline"
              size="sm"
              disabled={isAnimating}
              className="flex items-center gap-2"
            >
              Next
              <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* CTA Section */}
      <Card className="p-8 bg-gradient-to-br from-[#a81933]/10 via-white to-[#504f56]/10 border-2 border-[#a81933]/20 text-center">
        <h3 className="text-2xl font-bold text-[#504f56] mb-4">
          Ready to Join Our Success Stories?
        </h3>
        <p className="text-gray-600 mb-6 max-w-2xl mx-auto">
          Experience the same stress-free, professional service that has made Chris the trusted choice 
          for Twin Cities families for over 25 years.
        </p>
        <Button className="bg-gradient-to-r from-[#a81933] to-[#b8203a] hover:from-[#b8203a] hover:to-[#c82d41] text-white px-8 py-3">
          Start Your Success Story Today
        </Button>
      </Card>
    </div>
  );
}