'use client';

import { useState } from 'react';
import { Card } from './card';
import { Button } from './button';
import { MapPin, TrendingUp, Home, Users, Star, ChevronRight } from 'lucide-react';

interface Neighborhood {
  id: string;
  name: string;
  zipCodes: string[];
  medianPrice: number;
  appreciation: number;
  daysOnMarket: number;
  specialty: boolean;
  description: string;
  highlights: string[];
  coordinates: { x: number; y: number };
}

const NEIGHBORHOODS: Neighborhood[] = [
  {
    id: 'golden-valley',
    name: 'Golden Valley',
    zipCodes: ['55416', '55426'],
    medianPrice: 495000,
    appreciation: 7.5,
    daysOnMarket: 18,
    specialty: true,
    description: "Chris's specialty area with 25 years of expertise. Premium family community with exceptional schools.",
    highlights: ['Top-rated schools', 'Tree-lined streets', 'Easy Minneapolis access'],
    coordinates: { x: 45, y: 35 }
  },
  {
    id: 'bryn-mawr',
    name: 'Bryn Mawr',
    zipCodes: ['55405', '55411'],
    medianPrice: 525000,
    appreciation: 8.2,
    daysOnMarket: 15,
    specialty: true,
    description: "Chris's specialty area! Unique character neighborhood with historic charm and downtown proximity.",
    highlights: ['Historic craftsman homes', 'Bryn Mawr Meadows', 'Downtown proximity'],
    coordinates: { x: 55, y: 45 }
  },
  {
    id: 'edina',
    name: 'Edina',
    zipCodes: ['55436', '55439'],
    medianPrice: 625000,
    appreciation: 6.8,
    daysOnMarket: 22,
    specialty: false,
    description: "Luxury market with exceptional amenities and highly rated schools. Strong investment potential.",
    highlights: ['Southdale area', 'Luxury amenities', 'Premium schools'],
    coordinates: { x: 40, y: 65 }
  },
  {
    id: 'plymouth',
    name: 'Plymouth',
    zipCodes: ['55447', '55441'],
    medianPrice: 425000,
    appreciation: 6.2,
    daysOnMarket: 16,
    specialty: false,
    description: "Strong family community with excellent value and consistent growth. Great for first-time buyers.",
    highlights: ['Family-friendly', 'Great value', 'Growing market'],
    coordinates: { x: 25, y: 25 }
  },
  {
    id: 'wayzata',
    name: 'Wayzata',
    zipCodes: ['55391'],
    medianPrice: 875000,
    appreciation: 5.9,
    daysOnMarket: 28,
    specialty: false,
    description: "Luxury lakefront community with premium properties and exclusive amenities.",
    highlights: ['Lake Minnetonka', 'Luxury properties', 'Exclusive community'],
    coordinates: { x: 15, y: 35 }
  },
  {
    id: 'hopkins',
    name: 'Hopkins',
    zipCodes: ['55343'],
    medianPrice: 385000,
    appreciation: 7.1,
    daysOnMarket: 14,
    specialty: false,
    description: "Vibrant downtown area with excellent walkability and growing arts scene.",
    highlights: ['Walkable downtown', 'Arts district', 'Light rail access'],
    coordinates: { x: 50, y: 55 }
  }
];

export default function InteractiveMarketMap() {
  const [selectedNeighborhood, setSelectedNeighborhood] = useState<Neighborhood | null>(null);
  const [hoveredNeighborhood, setHoveredNeighborhood] = useState<string | null>(null);

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('en-US', {
      style: 'currency',
      currency: 'USD',
      maximumFractionDigits: 0,
    }).format(amount);
  };

  const getNeighborhoodColor = (neighborhood: Neighborhood) => {
    if (neighborhood.specialty) {
      return hoveredNeighborhood === neighborhood.id ? '#b8203a' : '#a81933';
    }
    return hoveredNeighborhood === neighborhood.id ? '#605f66' : '#504f56';
  };

  return (
    <div className="grid lg:grid-cols-12 gap-8">
      {/* Interactive Map */}
      <div className="lg:col-span-7">
        <Card className="p-6 h-full">
          <div className="text-center mb-6">
            <h3 className="text-2xl font-bold text-[#504f56] mb-2">
              Twin Cities Market Map
            </h3>
            <p className="text-gray-600">
              Explore Chris's specialty areas and market insights
            </p>
          </div>

          {/* SVG Map Container */}
          <div className="relative bg-gradient-to-br from-blue-50 to-green-50 rounded-xl p-8 h-96 overflow-hidden">
            {/* Map Background */}
            <div className="absolute inset-0 bg-gradient-to-br from-blue-100/50 to-green-100/50 rounded-xl"></div>
            
            {/* Neighborhood Markers */}
            <svg
              viewBox="0 0 100 100"
              className="w-full h-full relative z-10"
            >
              {/* Grid lines for visual appeal */}
              <defs>
                <pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
                  <path d="M 10 0 L 0 0 0 10" fill="none" stroke="#e5e7eb" strokeWidth="0.5" opacity="0.5"/>
                </pattern>
              </defs>
              <rect width="100" height="100" fill="url(#grid)" />

              {/* Neighborhood Circles */}
              {NEIGHBORHOODS.map((neighborhood) => (
                <g key={neighborhood.id}>
                  {/* Pulse effect for specialty areas */}
                  {neighborhood.specialty && (
                    <circle
                      cx={neighborhood.coordinates.x}
                      cy={neighborhood.coordinates.y}
                      r="8"
                      fill={getNeighborhoodColor(neighborhood)}
                      opacity="0.3"
                      className="animate-pulse-glow"
                    />
                  )}
                  
                  {/* Main marker */}
                  <circle
                    cx={neighborhood.coordinates.x}
                    cy={neighborhood.coordinates.y}
                    r={neighborhood.specialty ? "6" : "4"}
                    fill={getNeighborhoodColor(neighborhood)}
                    stroke="white"
                    strokeWidth="2"
                    className="cursor-pointer transition-all duration-300 hover:scale-125"
                    onMouseEnter={() => setHoveredNeighborhood(neighborhood.id)}
                    onMouseLeave={() => setHoveredNeighborhood(null)}
                    onClick={() => setSelectedNeighborhood(neighborhood)}
                  />
                  
                  {/* Specialty star */}
                  {neighborhood.specialty && (
                    <g transform={`translate(${neighborhood.coordinates.x - 2}, ${neighborhood.coordinates.y - 2})`}>
                      <Star 
                        className="w-4 h-4 fill-yellow-400 text-yellow-400" 
                        style={{ 
                          filter: 'drop-shadow(0 0 2px rgba(0,0,0,0.3))',
                          pointerEvents: 'none'
                        }} 
                      />
                    </g>
                  )}
                  
                  {/* Label */}
                  <text
                    x={neighborhood.coordinates.x}
                    y={neighborhood.coordinates.y + (neighborhood.specialty ? 15 : 12)}
                    textAnchor="middle"
                    className="text-xs font-semibold fill-current text-gray-700 pointer-events-none"
                    style={{ fontSize: '3px' }}
                  >
                    {neighborhood.name}
                  </text>
                </g>
              ))}
            </svg>

            {/* Legend */}
            <div className="absolute bottom-4 left-4 bg-white/90 backdrop-blur-sm rounded-lg p-3 shadow-lg">
              <div className="flex items-center gap-4 text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-[#a81933] rounded-full"></div>
                  <Star className="w-3 h-3 text-yellow-400 fill-yellow-400" />
                  <span className="text-gray-700 font-medium">Chris's Specialties</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 bg-[#504f56] rounded-full"></div>
                  <span className="text-gray-700">Other Markets</span>
                </div>
              </div>
            </div>
          </div>
        </Card>
      </div>

      {/* Neighborhood Details */}
      <div className="lg:col-span-5">
        {selectedNeighborhood ? (
          <Card className="p-6 h-full interactive-card">
            <div className="space-y-6">
              {/* Header */}
              <div className="text-center">
                <div className="flex items-center justify-center gap-2 mb-3">
                  <h3 className="text-2xl font-bold text-[#504f56]">
                    {selectedNeighborhood.name}
                  </h3>
                  {selectedNeighborhood.specialty && (
                    <div className="flex items-center gap-1 bg-gradient-to-r from-yellow-400 to-yellow-500 text-yellow-900 px-3 py-1 rounded-full text-sm font-bold">
                      <Star className="w-4 h-4 fill-current" />
                      Chris's Specialty
                    </div>
                  )}
                </div>
                <p className="text-gray-600 leading-relaxed">
                  {selectedNeighborhood.description}
                </p>
              </div>

              {/* Market Stats */}
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-gradient-to-br from-green-50 to-green-100 p-4 rounded-lg border border-green-200">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-800">
                      {formatCurrency(selectedNeighborhood.medianPrice)}
                    </div>
                    <div className="text-sm text-green-600 font-medium">Median Price</div>
                  </div>
                </div>

                <div className="bg-gradient-to-br from-blue-50 to-blue-100 p-4 rounded-lg border border-blue-200">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-blue-800">
                      +{selectedNeighborhood.appreciation}%
                    </div>
                    <div className="text-sm text-blue-600 font-medium">Annual Growth</div>
                  </div>
                </div>

                <div className="bg-gradient-to-br from-purple-50 to-purple-100 p-4 rounded-lg border border-purple-200">
                  <div className="text-center">
                    <div className="text-2xl font-bold text-purple-800">
                      {selectedNeighborhood.daysOnMarket}
                    </div>
                    <div className="text-sm text-purple-600 font-medium">Days on Market</div>
                  </div>
                </div>

                <div className="bg-gradient-to-br from-orange-50 to-orange-100 p-4 rounded-lg border border-orange-200">
                  <div className="text-center">
                    <div className="text-lg font-bold text-orange-800">
                      {selectedNeighborhood.zipCodes.join(', ')}
                    </div>
                    <div className="text-sm text-orange-600 font-medium">Zip Codes</div>
                  </div>
                </div>
              </div>

              {/* Highlights */}
              <div>
                <h4 className="font-bold text-[#504f56] mb-3 flex items-center gap-2">
                  <Home className="w-5 h-5" />
                  Key Highlights
                </h4>
                <div className="space-y-2">
                  {selectedNeighborhood.highlights.map((highlight, index) => (
                    <div key={index} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                      <ChevronRight className="w-4 h-4 text-[#a81933]" />
                      <span className="text-gray-700 font-medium">{highlight}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* CTA */}
              <div className="pt-4 border-t border-gray-200">
                {selectedNeighborhood.specialty ? (
                  <div className="text-center space-y-3">
                    <div className="bg-gradient-to-r from-[#a81933]/10 to-[#504f56]/10 p-4 rounded-lg">
                      <p className="text-sm text-gray-700 font-medium mb-2">
                        🏆 Chris has 25 years of expertise in {selectedNeighborhood.name}
                      </p>
                      <p className="text-xs text-gray-600">
                        Get insider knowledge and stress-free guidance from a true neighborhood specialist.
                      </p>
                    </div>
                    <Button className="w-full bg-gradient-to-r from-[#a81933] to-[#b8203a] hover:from-[#b8203a] hover:to-[#c82d41] text-white">
                      Get Chris's {selectedNeighborhood.name} Market Analysis
                    </Button>
                  </div>
                ) : (
                  <Button 
                    variant="outline"
                    className="w-full border-[#504f56] text-[#504f56] hover:bg-[#504f56] hover:text-white"
                  >
                    Learn More About {selectedNeighborhood.name}
                  </Button>
                )}
              </div>
            </div>
          </Card>
        ) : (
          <Card className="p-6 h-full flex items-center justify-center">
            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-gradient-to-br from-[#a81933]/20 to-[#504f56]/20 rounded-full flex items-center justify-center mx-auto">
                <MapPin className="w-8 h-8 text-[#a81933]" />
              </div>
              <div>
                <h3 className="text-xl font-bold text-[#504f56] mb-2">
                  Explore Twin Cities Markets
                </h3>
                <p className="text-gray-600 mb-4">
                  Click on any neighborhood marker to see detailed market insights and Chris's expertise.
                </p>
                <div className="text-sm text-gray-500">
                  ⭐ Gold stars indicate Chris's specialty areas with 25 years of experience
                </div>
              </div>
            </div>
          </Card>
        )}
      </div>
    </div>
  );
}