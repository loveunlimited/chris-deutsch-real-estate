/**
 * CHRIS DEUTSCH VIDEO GENERATOR
 * Command-line tool for HeyGen avatar video generation
 * Budget-conscious with comprehensive monitoring
 */

require('dotenv').config();

const HeyGenVideoService = require('./src/lib/heygen-video-service.js');

// Pre-built video scripts optimized for Chris Deutsch
const VIDEO_TEMPLATES = [
  {
    title: "Chris Deutsch - Welcome & Introduction",
    priority: "high",
    background: "real_estate_office",
    script: `Hi, I'm Chris Deutsch, your Twin Cities real estate expert with 25 years of experience. I specialize in Golden Valley and Bryn Mawr, and I'm committed to making your real estate journey completely stress-free. Whether you're buying your first home, upgrading to your dream property, or making a strategic investment, I'm here to guide you every step of the way with the expertise that only comes from a quarter-century of local market knowledge.`,
    voice_settings: { speed: 1.05, emotion: "professional" },
    video_settings: { resolution: "1080p", aspect_ratio: "16:9" }
  },
  
  {
    title: "Golden Valley Market Update - December 2024",
    priority: "high", 
    background: "real_estate_office",
    script: `You know, after 25 years serving Twin Cities families, I'm honestly excited to share some remarkable developments happening right here in our Golden Valley market. If you're a homeowner in the 55416 or 55426 zip codes, you're actually sitting on some incredible equity growth. Homes in your area have appreciated significantly, and frankly, the numbers are impressive - median values are now reaching around $495,000 in prime Golden Valley neighborhoods. Here's what this really means for you: If you purchased your home 7 to 10 years ago, you likely have substantial equity that opens up some exciting possibilities. Many of my Golden Valley clients are discovering they can actually afford to move up to their dream home, or honestly, right-size to something that better fits their current lifestyle.`,
    voice_settings: { speed: 1.05, emotion: "friendly" },
    video_settings: { resolution: "1080p", aspect_ratio: "16:9" }
  },

  {
    title: "Why Choose Chris Deutsch - 25 Years of Excellence",
    priority: "medium",
    background: "real_estate_office", 
    script: `After 25 years in Twin Cities real estate, I've learned that success isn't just about closing deals - it's about building relationships and delivering peace of mind. My approach is different: I believe your real estate experience should be completely stress-free. That's why I handle every detail, coordinate with all the professionals involved, and keep you informed throughout the entire process. When you work with me, you're not just getting an agent - you're getting a trusted advisor who's committed to your success.`,
    voice_settings: { speed: 1.05, emotion: "professional" },
    video_settings: { resolution: "720p", aspect_ratio: "16:9" }
  },

  {
    title: "Schedule Your Free Consultation",
    priority: "medium",
    background: "real_estate_office",
    script: `Ready to take the next step? I'd love to provide you with a complimentary, no-pressure market analysis and consultation. Whether you're curious about your home's current value, exploring upgrade options, or looking for your first home, I'm here to help. You can reach me directly at chris@chrisdeutsch.com or visit my website to schedule a time that works for you. Remember, in real estate, experience isn't just about years - it's about results, relationships, and making your transition completely stress-free.`,
    voice_settings: { speed: 1.05, emotion: "friendly" },
    video_settings: { resolution: "720p", aspect_ratio: "16:9" }
  },

  {
    title: "Social Media Quick Intro - 30 Second",
    priority: "low",
    background: "modern",
    script: `Hi, I'm Chris Deutsch! 25 years helping Twin Cities families find their perfect homes. Specializing in Golden Valley & Bryn Mawr. Let's make your real estate dreams a reality - completely stress-free! Contact me at chris@chrisdeutsch.com`,
    voice_settings: { speed: 1.1, emotion: "excited" },
    video_settings: { resolution: "720p", aspect_ratio: "1:1" }
  }
];

class ChrisVideoGenerator {
  constructor() {
    this.config = {
      apiKey: process.env.HEYGEN_API_KEY,
      monthlyBudget: parseInt(process.env.HEYGEN_MONTHLY_BUDGET || '40'),
      videoLimit: parseInt(process.env.HEYGEN_VIDEO_LIMIT || '10'),
      avatarId: process.env.HEYGEN_AVATAR_ID || undefined
    };

    if (!this.config.apiKey) {
      throw new Error('❌ HEYGEN_API_KEY is required in .env file');
    }

    this.service = new HeyGenVideoService(this.config);
  }

  async showUsageStats() {
    console.log('\n📊 CURRENT USAGE STATISTICS');
    console.log('=' .repeat(50));
    
    const usage = await this.service.getUsageStats();
    
    console.log(`💰 Budget: $${usage.totalCost.toFixed(2)} / $${this.config.monthlyBudget}`);
    console.log(`📹 Videos: ${usage.videosGenerated} / ${this.config.videoLimit}`);
    console.log(`💵 Remaining: $${usage.remainingBudget.toFixed(2)}`);
    console.log(`📅 Reset Date: ${new Date(usage.monthlyReset).toLocaleDateString()}`);
    
    if (usage.lastGenerated) {
      console.log(`🕐 Last Video: ${new Date(usage.lastGenerated).toLocaleString()}`);
    }
    
    return usage;
  }

  async generateSingleVideo(templateIndex) {
    const template = VIDEO_TEMPLATES[templateIndex];
    if (!template) {
      console.log('❌ Invalid template index');
      return;
    }

    console.log(`\n🎬 GENERATING: ${template.title}`);
    console.log('=' .repeat(60));
    
    const result = await this.service.generateVideo(template);
    
    if (result.status === 'error') {
      console.log(`❌ Generation failed: ${result.error}`);
      return null;
    }

    console.log(`✅ Video generation started successfully!`);
    console.log(`🆔 Video ID: ${result.videoId}`);
    console.log(`💲 Estimated Cost: $${result.estimatedCost?.toFixed(2)}`);
    
    return result;
  }

  async generateVideoSet(indices = [0, 1]) {
    console.log('\n🎬 GENERATING VIDEO SET');
    console.log('=' .repeat(50));
    
    const selectedTemplates = indices.map(i => VIDEO_TEMPLATES[i]).filter(Boolean);
    
    if (selectedTemplates.length === 0) {
      console.log('❌ No valid templates selected');
      return;
    }

    console.log(`📹 Selected ${selectedTemplates.length} videos:`);
    selectedTemplates.forEach((template, i) => {
      console.log(`   ${i + 1}. ${template.title}`);
    });

    const results = await this.service.generateVideoBatch(selectedTemplates);
    
    console.log('\n📋 GENERATION SUMMARY:');
    results.forEach((result, i) => {
      const status = result.status === 'error' ? '❌' : '✅';
      console.log(`   ${status} ${selectedTemplates[i].title}`);
      if (result.videoId) {
        console.log(`      ID: ${result.videoId}`);
      }
      if (result.error) {
        console.log(`      Error: ${result.error}`);
      }
    });

    return results;
  }

  async checkVideoStatus(videoId) {
    console.log(`\n🔍 CHECKING VIDEO STATUS: ${videoId}`);
    console.log('=' .repeat(50));
    
    const status = await this.service.checkVideoStatus(videoId);
    
    console.log(`Status: ${status.status}`);
    if (status.downloadUrl) {
      console.log(`Download: ${status.downloadUrl}`);
    }
    if (status.duration) {
      console.log(`Duration: ${status.duration} seconds`);
    }
    if (status.error) {
      console.log(`Error: ${status.error}`);
    }
    
    return status;
  }

  async waitAndDownload(videoId, filename) {
    console.log(`\n⏳ WAITING FOR COMPLETION: ${videoId}`);
    console.log('=' .repeat(50));
    
    const result = await this.service.waitForVideoCompletion(videoId, 10);
    
    if (result.status === 'completed' && result.downloadUrl) {
      console.log('🎉 Video completed! Attempting download...');
      const downloaded = await this.service.downloadVideo(videoId, filename);
      
      if (downloaded) {
        console.log(`✅ Downloaded: ${downloaded}`);
      } else {
        console.log('❌ Download failed');
      }
    } else {
      console.log(`❌ Video not ready: ${result.status}`);
      if (result.error) {
        console.log(`Error: ${result.error}`);
      }
    }
    
    return result;
  }

  async listAvatars() {
    console.log('\n👤 AVAILABLE AVATARS');
    console.log('=' .repeat(40));
    
    const avatars = await this.service.listAvatars();
    
    if (avatars.length === 0) {
      console.log('No avatars found. You may need to record your avatar first.');
    } else {
      avatars.forEach((avatar, i) => {
        console.log(`${i + 1}. ${avatar.name} (ID: ${avatar.avatar_id})`);
      });
    }
    
    return avatars;
  }

  showMenu() {
    console.log('\n🎬 CHRIS DEUTSCH VIDEO GENERATOR');
    console.log('=' .repeat(50));
    console.log('Available video templates:');
    VIDEO_TEMPLATES.forEach((template, i) => {
      const priority = template.priority === 'high' ? '🔥' : template.priority === 'medium' ? '📍' : '📋';
      console.log(`   ${i}. ${priority} ${template.title}`);
    });
    console.log('\nCommands:');
    console.log('  node chris-deutsch-video-generator.js usage');
    console.log('  node chris-deutsch-video-generator.js generate <template_index>');
    console.log('  node chris-deutsch-video-generator.js batch <index1,index2>');
    console.log('  node chris-deutsch-video-generator.js status <video_id>');
    console.log('  node chris-deutsch-video-generator.js wait <video_id>');
    console.log('  node chris-deutsch-video-generator.js avatars');
    console.log('  node chris-deutsch-video-generator.js starter-set');
  }

  async runStarterSet() {
    console.log('\n🚀 CHRIS DEUTSCH STARTER VIDEO SET');
    console.log('=' .repeat(60));
    console.log('Generating the 2 most important videos for immediate use:\n');
    
    // Generate Welcome + Golden Valley Market Update
    const results = await this.generateVideoSet([0, 1]);
    
    console.log('\n📋 STARTER SET COMPLETE!');
    console.log('Next steps:');
    console.log('1. Check video status in 5-10 minutes');
    console.log('2. Download completed videos');
    console.log('3. Use for website, social media, and email campaigns');
    
    if (results && results.length > 0) {
      console.log('\n🔗 Video IDs for tracking:');
      results.forEach((result, i) => {
        if (result.videoId) {
          console.log(`   ${['Welcome', 'Golden Valley Update'][i]}: ${result.videoId}`);
        }
      });
    }
    
    return results;
  }
}

// Command line interface
async function main() {
  const args = process.argv.slice(2);
  const command = args[0] || 'menu';
  
  try {
    const generator = new ChrisVideoGenerator();
    
    switch (command) {
      case 'usage':
        await generator.showUsageStats();
        break;
        
      case 'generate':
        const index = parseInt(args[1]);
        if (isNaN(index)) {
          console.log('❌ Please provide a template index');
          generator.showMenu();
          return;
        }
        await generator.generateSingleVideo(index);
        break;
        
      case 'batch':
        const indices = args[1] ? args[1].split(',').map(i => parseInt(i.trim())) : [0, 1];
        await generator.generateVideoSet(indices);
        break;
        
      case 'status':
        const videoId = args[1];
        if (!videoId) {
          console.log('❌ Please provide a video ID');
          return;
        }
        await generator.checkVideoStatus(videoId);
        break;
        
      case 'wait':
        const waitVideoId = args[1];
        const filename = args[2];
        if (!waitVideoId) {
          console.log('❌ Please provide a video ID');
          return;
        }
        await generator.waitAndDownload(waitVideoId, filename);
        break;
        
      case 'avatars':
        await generator.listAvatars();
        break;
        
      case 'starter-set':
        await generator.runStarterSet();
        break;
        
      default:
        generator.showMenu();
    }
    
  } catch (error) {
    console.error('❌ Error:', error.message);
    
    if (error.message.includes('HEYGEN_API_KEY')) {
      console.log('\n💡 Make sure your .env file contains:');
      console.log('   HEYGEN_API_KEY=your_api_key_here');
    }
  }
}

// Run if called directly
if (require.main === module) {
  main();
}

module.exports = { ChrisVideoGenerator, VIDEO_TEMPLATES };