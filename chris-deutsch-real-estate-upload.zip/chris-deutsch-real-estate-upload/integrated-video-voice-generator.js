/**
 * INTEGRATED VIDEO + VOICE GENERATOR
 * Combines ElevenLabs voice clone + HeyGen avatar videos
 * Cost-efficient production workflow for Chris Deutsch
 */

require('dotenv').config();

class IntegratedVideoVoiceGenerator {
  constructor() {
    this.config = {
      elevenlabs: {
        apiKey: process.env.ELEVENLABS_API_KEY,
        voiceId: process.env.ELEVENLABS_VOICE_ID,
        settings: {
          speed: 1.05,       // Chris's optimized settings
          stability: 0.65,   
          similarity_boost: 0.7
        }
      },
      heygen: {
        apiKey: process.env.HEYGEN_API_KEY,
        monthlyBudget: parseInt(process.env.HEYGEN_MONTHLY_BUDGET || '40'),
        videoLimit: parseInt(process.env.HEYGEN_VIDEO_LIMIT || '10'),
        avatarId: process.env.HEYGEN_AVATAR_ID
      }
    };

    this.validateConfig();
  }

  validateConfig() {
    if (!this.config.elevenlabs.apiKey) {
      throw new Error('❌ ELEVENLABS_API_KEY required');
    }
    if (!this.config.elevenlabs.voiceId) {
      throw new Error('❌ ELEVENLABS_VOICE_ID required');
    }
    if (!this.config.heygen.apiKey) {
      throw new Error('❌ HEYGEN_API_KEY required');
    }
  }

  /**
   * Generate voice-first, then create avatar video
   * This ensures perfect voice quality before video production
   */
  async generateVoiceFirstWorkflow(script, title, options = {}) {
    console.log('\n🎬 INTEGRATED VOICE + VIDEO GENERATION');
    console.log('=' .repeat(60));
    console.log(`📝 Title: ${title}`);
    console.log(`📏 Script: ${script.length} characters`);
    console.log('🔄 Workflow: Voice → Video');

    const results = {
      voice: null,
      video: null,
      timeline: [],
      totalCost: 0
    };

    try {
      // Step 1: Generate optimized voice clone
      console.log('\n🎤 STEP 1: Generating ElevenLabs voice...');
      results.timeline.push({ step: 'voice_start', time: new Date() });
      
      const voiceResult = await this.generateOptimizedVoice(script, title);
      results.voice = voiceResult;
      
      if (voiceResult.success) {
        console.log(`✅ Voice generated: ${voiceResult.filename}`);
        console.log(`🎯 Quality: Optimized for Chris's voice`);
        results.timeline.push({ step: 'voice_complete', time: new Date() });
      } else {
        throw new Error(`Voice generation failed: ${voiceResult.error}`);
      }

      // Step 2: Generate HeyGen avatar video
      console.log('\n🎬 STEP 2: Generating HeyGen avatar video...');
      results.timeline.push({ step: 'video_start', time: new Date() });
      
      const videoResult = await this.generateHeyGenVideo(script, title, options);
      results.video = videoResult;
      
      if (videoResult.success) {
        console.log(`✅ Video initiated: ${videoResult.videoId}`);
        console.log(`💰 Estimated cost: $${videoResult.estimatedCost}`);
        results.totalCost = videoResult.estimatedCost;
        results.timeline.push({ step: 'video_initiated', time: new Date() });
      } else {
        throw new Error(`Video generation failed: ${videoResult.error}`);
      }

      // Step 3: Provide next steps
      console.log('\n📋 NEXT STEPS:');
      console.log('1. 🎵 Voice file ready for immediate use');
      console.log('2. ⏳ Video processing (5-10 minutes)');
      console.log('3. 📹 Check video status with provided ID');
      console.log('4. ⬇️ Download when complete');

      results.success = true;
      return results;

    } catch (error) {
      console.error(`❌ Workflow failed: ${error.message}`);
      results.error = error.message;
      results.success = false;
      return results;
    }
  }

  /**
   * Generate optimized ElevenLabs voice
   */
  async generateOptimizedVoice(script, title) {
    try {
      const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${this.config.elevenlabs.voiceId}`, {
        method: 'POST',
        headers: {
          'Accept': 'audio/mpeg',
          'Content-Type': 'application/json',
          'xi-api-key': this.config.elevenlabs.apiKey
        },
        body: JSON.stringify({
          text: script,
          model_id: "eleven_monolingual_v1",
          voice_settings: this.config.elevenlabs.settings
        })
      });

      if (!response.ok) {
        const errorText = await response.text();
        return { success: false, error: `ElevenLabs API: ${errorText}` };
      }

      const audioBuffer = await response.arrayBuffer();
      const fs = require('fs');
      
      // Create safe filename
      const safeTitle = title.replace(/[^a-zA-Z0-9-_]/g, '-').toLowerCase();
      const filename = `chris-voice-${safeTitle}-${Date.now()}.mp3`;
      
      fs.writeFileSync(filename, Buffer.from(audioBuffer));
      
      return {
        success: true,
        filename: filename,
        size: (audioBuffer.byteLength / 1024).toFixed(1) + ' KB',
        duration: this.estimateAudioDuration(script)
      };

    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Generate HeyGen avatar video
   */
  async generateHeyGenVideo(script, title, options = {}) {
    try {
      const payload = {
        video_inputs: [{
          character: {
            type: "avatar",
            avatar_id: this.config.heygen.avatarId || "default",
            avatar_style: "normal"
          },
          voice: {
            type: "text",
            input_text: script,
            voice_id: "default", // Will use your recorded voice
            speed: 1.05,
            emotion: options.emotion || "professional"
          },
          background: {
            type: options.background || "real_estate_office",
            background_id: "default"
          }
        }],
        test: false,
        caption: false,
        title: title,
        callback_id: `chris-integrated-${Date.now()}`,
        aspect_ratio: options.aspect_ratio || "16:9",
        resolution: options.resolution || "720p"
      };

      const response = await fetch('https://api.heygen.com/v2/video/generate', {
        method: 'POST',
        headers: {
          'X-API-KEY': this.config.heygen.apiKey,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        const errorText = await response.text();
        return { success: false, error: `HeyGen API: ${errorText}` };
      }

      const result = await response.json();
      const estimatedCost = this.estimateVideoCost(script.length);
      
      // Update usage tracking
      await this.updateUsage(result.video_id, estimatedCost);
      
      return {
        success: true,
        videoId: result.video_id,
        estimatedCost: estimatedCost,
        status: 'pending'
      };

    } catch (error) {
      return { success: false, error: error.message };
    }
  }

  /**
   * Check HeyGen video status
   */
  async checkVideoStatus(videoId) {
    try {
      const response = await fetch(`https://api.heygen.com/v2/video/${videoId}`, {
        headers: {
          'X-API-KEY': this.config.heygen.apiKey
        }
      });

      if (!response.ok) {
        throw new Error(`Status check failed: ${response.statusText}`);
      }

      const result = await response.json();
      
      return {
        videoId: videoId,
        status: result.status,
        downloadUrl: result.video_url,
        duration: result.duration,
        createdAt: result.created_at
      };

    } catch (error) {
      return { error: error.message };
    }
  }

  /**
   * Wait for video completion and provide both files
   */
  async completeWorkflow(workflowResult, waitMinutes = 10) {
    if (!workflowResult.success || !workflowResult.video?.videoId) {
      console.log('❌ Cannot complete workflow - video generation failed');
      return workflowResult;
    }

    console.log('\n⏳ WAITING FOR VIDEO COMPLETION...');
    console.log(`🆔 Video ID: ${workflowResult.video.videoId}`);
    console.log(`⏰ Timeout: ${waitMinutes} minutes`);

    const maxAttempts = waitMinutes * 6; // Check every 10 seconds
    let attempts = 0;

    while (attempts < maxAttempts) {
      const status = await this.checkVideoStatus(workflowResult.video.videoId);
      
      if (status.status === 'completed') {
        console.log('\n🎉 WORKFLOW COMPLETE!');
        console.log('📁 Available files:');
        console.log(`   🎵 Voice: ${workflowResult.voice.filename}`);
        console.log(`   📹 Video: ${status.downloadUrl}`);
        
        workflowResult.video.downloadUrl = status.downloadUrl;
        workflowResult.video.duration = status.duration;
        workflowResult.video.status = 'completed';
        workflowResult.timeline.push({ step: 'complete', time: new Date() });
        
        return workflowResult;
      }
      
      if (status.status === 'failed' || status.error) {
        console.log('❌ Video generation failed');
        workflowResult.video.error = status.error;
        return workflowResult;
      }
      
      // Wait 10 seconds
      await new Promise(resolve => setTimeout(resolve, 10000));
      attempts++;
      
      if (attempts % 6 === 0) { // Every minute
        console.log(`⏳ Still processing... (${Math.floor(attempts / 6)}/${waitMinutes} minutes)`);
      }
    }

    console.log('⏰ Video generation timed out');
    workflowResult.video.error = 'Generation timed out';
    return workflowResult;
  }

  /**
   * Estimate audio duration from script
   */
  estimateAudioDuration(script) {
    const wordsPerMinute = 150; // Average speaking rate
    const words = script.split(' ').length;
    const minutes = words / wordsPerMinute;
    return Math.round(minutes * 60) + ' seconds';
  }

  /**
   * Estimate video cost
   */
  estimateVideoCost(scriptLength) {
    const estimatedMinutes = scriptLength / (150 * 5); // 150 words/min, 5 chars/word
    const baseCost = Math.max(3.5, estimatedMinutes * 4);
    return Math.round(baseCost * 100) / 100;
  }

  /**
   * Update usage tracking
   */
  async updateUsage(videoId, cost) {
    try {
      const fs = require('fs').promises;
      const usageFile = './heygen-usage.json';
      
      let usage = { videosGenerated: 0, totalCost: 0, monthlyReset: '' };
      
      try {
        const data = await fs.readFile(usageFile, 'utf8');
        usage = JSON.parse(data);
      } catch {
        // File doesn't exist
      }

      // Check monthly reset
      const now = new Date();
      const resetDate = new Date(usage.monthlyReset || now);
      
      if (now.getMonth() !== resetDate.getMonth() || now.getFullYear() !== resetDate.getFullYear()) {
        usage = {
          videosGenerated: 0,
          totalCost: 0,
          monthlyReset: new Date(now.getFullYear(), now.getMonth(), 1).toISOString()
        };
      }

      // Update usage
      const updated = {
        ...usage,
        videosGenerated: usage.videosGenerated + 1,
        totalCost: usage.totalCost + cost,
        lastVideoId: videoId,
        lastGenerated: new Date().toISOString()
      };

      await fs.writeFile(usageFile, JSON.stringify(updated, null, 2));
      
    } catch (error) {
      console.error('❌ Usage tracking failed:', error);
    }
  }

  /**
   * Generate the Chris Deutsch starter set
   */
  async generateStarterSet() {
    console.log('\n🚀 CHRIS DEUTSCH INTEGRATED STARTER SET');
    console.log('=' .repeat(70));
    console.log('Generating voice + video for your 2 most important pieces:\n');

    const templates = [
      {
        title: "Chris Deutsch - Welcome & Introduction", 
        script: `Hi, I'm Chris Deutsch, your Twin Cities real estate expert with 25 years of experience. I specialize in Golden Valley and Bryn Mawr, and I'm committed to making your real estate journey completely stress-free. Whether you're buying your first home, upgrading to your dream property, or making a strategic investment, I'm here to guide you every step of the way with the expertise that only comes from a quarter-century of local market knowledge.`,
        options: { background: "real_estate_office", emotion: "professional", resolution: "1080p" }
      },
      {
        title: "Golden Valley Market Update - December 2024",
        script: `You know, after 25 years serving Twin Cities families, I'm honestly excited to share some remarkable developments happening right here in our Golden Valley market. If you're a homeowner in the 55416 or 55426 zip codes, you're actually sitting on some incredible equity growth. Homes in your area have appreciated significantly, and frankly, the numbers are impressive - median values are now reaching around $495,000 in prime Golden Valley neighborhoods. Here's what this really means for you: If you purchased your home 7 to 10 years ago, you likely have substantial equity that opens up some exciting possibilities.`,
        options: { background: "real_estate_office", emotion: "friendly", resolution: "1080p" }
      }
    ];

    const results = [];

    for (let i = 0; i < templates.length; i++) {
      const template = templates[i];
      
      console.log(`\n📹 GENERATING ${i + 1}/2: ${template.title}`);
      console.log('-' .repeat(50));
      
      const result = await this.generateVoiceFirstWorkflow(
        template.script, 
        template.title, 
        template.options
      );
      
      results.push(result);
      
      // Small delay between generations
      if (i < templates.length - 1) {
        console.log('\n⏱️ Waiting 5 seconds before next generation...');
        await new Promise(resolve => setTimeout(resolve, 5000));
      }
    }

    console.log('\n🎉 STARTER SET GENERATION COMPLETE!');
    console.log('=' .repeat(50));
    
    const successful = results.filter(r => r.success).length;
    console.log(`✅ Generated: ${successful}/${templates.length}`);
    
    let totalCost = 0;
    results.forEach((result, i) => {
      const template = templates[i];
      if (result.success) {
        console.log(`\n📹 ${template.title}:`);
        console.log(`   🎵 Voice: ${result.voice.filename}`);
        console.log(`   🆔 Video ID: ${result.video.videoId}`);
        console.log(`   💰 Cost: $${result.totalCost}`);
        totalCost += result.totalCost;
      } else {
        console.log(`\n❌ ${template.title}: ${result.error}`);
      }
    });

    console.log(`\n💰 Total estimated cost: $${totalCost.toFixed(2)}`);
    console.log('\n📋 NEXT STEPS:');
    console.log('1. Voice files are ready for immediate use');
    console.log('2. Videos will complete in 5-10 minutes'); 
    console.log('3. Check status and download when ready');
    console.log('4. Use for website, email campaigns, social media');

    return results;
  }
}

// Command line interface
async function main() {
  const args = process.argv.slice(2);
  const command = args[0] || 'menu';
  
  try {
    const generator = new IntegratedVideoVoiceGenerator();
    
    switch (command) {
      case 'starter-set':
        await generator.generateStarterSet();
        break;
        
      case 'single':
        const script = args[1];
        const title = args[2];
        if (!script || !title) {
          console.log('❌ Usage: node integrated-video-voice-generator.js single "script" "title"');
          return;
        }
        const result = await generator.generateVoiceFirstWorkflow(script, title);
        console.log('\n📋 Result:', JSON.stringify(result, null, 2));
        break;
        
      case 'status':
        const videoId = args[1];
        if (!videoId) {
          console.log('❌ Usage: node integrated-video-voice-generator.js status <video_id>');
          return;
        }
        const status = await generator.checkVideoStatus(videoId);
        console.log('\n📊 Status:', JSON.stringify(status, null, 2));
        break;
        
      case 'complete':
        const workflowFile = args[1];
        if (!workflowFile) {
          console.log('❌ Usage: node integrated-video-voice-generator.js complete <workflow_result.json>');
          return;
        }
        const fs = require('fs');
        const workflowData = JSON.parse(fs.readFileSync(workflowFile, 'utf8'));
        const completed = await generator.completeWorkflow(workflowData);
        console.log('\n📋 Final Result:', JSON.stringify(completed, null, 2));
        break;
        
      default:
        console.log('\n🎬 INTEGRATED VIDEO + VOICE GENERATOR');
        console.log('=' .repeat(50));
        console.log('Commands:');
        console.log('  starter-set    Generate Chris Deutsch starter videos');
        console.log('  single "script" "title"    Generate single video');
        console.log('  status <video_id>    Check video status');
        console.log('  complete <file.json>    Wait for completion');
        console.log('\nOptimized workflow: Voice → Video for best quality');
    }
    
  } catch (error) {
    console.error('❌ Error:', error.message);
    
    if (error.message.includes('API_KEY')) {
      console.log('\n💡 Required environment variables:');
      console.log('   ELEVENLABS_API_KEY, ELEVENLABS_VOICE_ID');
      console.log('   HEYGEN_API_KEY, HEYGEN_MONTHLY_BUDGET, HEYGEN_VIDEO_LIMIT');
    }
  }
}

// Run if called directly
if (require.main === module) {
  main();
}

module.exports = { IntegratedVideoVoiceGenerator };