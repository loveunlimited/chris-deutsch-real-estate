# HeyGen AI Avatar Integration Guide

## Overview

This integration adds a sophisticated AI video avatar powered by HeyGen to the Chris Deutsch Real Estate website. The avatar provides real-time, face-to-face conversations with potential clients, offering personalized real estate expertise and lead generation capabilities.

## Features

### 🎯 **Core Functionality**
- **Real-time Video Streaming**: WebRTC-powered avatar conversations
- **Professional Voice Synthesis**: Custom voice model for Chris Deutsch
- **Real Estate Intelligence**: Context-aware responses about Twin Cities market
- **Lead Capture Integration**: Automatic lead generation and CRM integration
- **Mobile Responsive**: Optimized for all devices with fallback support

### 🏠 **Real Estate Specific Features**
- **Neighborhood Expertise**: Specialized knowledge of Golden Valley & Bryn Mawr
- **Market Insights**: Current Twin Cities market data and trends
- **Property Introductions**: Personalized property presentations
- **Stress-Free Process**: Emphasis on Chris's 25-year experience and approach
- **Lead Qualification**: Intelligent conversation flow for lead scoring

### 🎨 **Luxury Design Integration**
- **Consistent Branding**: Matches existing burgundy/charcoal color scheme
- **Premium UI Elements**: Sophisticated controls and indicators
- **Professional Layout**: Enterprise-level presentation
- **Smooth Animations**: Polished interaction feedback

## Technical Architecture

### **Frontend Components**
```
src/components/ui/heygen-avatar.tsx    # Main avatar component
├── Video streaming container
├── Chat interface
├── Control panel
├── Quick action buttons
└── Lead capture integration
```

### **Backend Services**
```
src/lib/heygen-service.ts              # HeyGen SDK integration
├── WebRTC session management
├── Real estate conversation flows
├── Context-aware responses
└── Lead processing

src/app/api/heygen/route.ts            # API endpoints
├── Session creation/management
├── Message handling
├── Property introductions
└── Analytics tracking

src/app/api/leads/route.ts             # Lead capture system
├── CRM integration
├── Email notifications
├── Lead scoring
└── Analytics
```

## Setup Instructions

### 1. HeyGen Account Setup

1. **Create HeyGen Account**
   - Visit [HeyGen.com](https://heygen.com)
   - Sign up for a professional account
   - Navigate to the API section

2. **Create Your Avatar**
   - Upload high-quality video footage of Chris Deutsch
   - Follow HeyGen's avatar creation guidelines
   - Train the voice model with speech samples
   - Note the Avatar ID and Voice ID

3. **Get API Credentials**
   - Generate API key from HeyGen dashboard
   - Save Avatar ID and Voice ID
   - Configure streaming permissions

### 2. Environment Configuration

1. **Copy Environment File**
   ```bash
   cp .env.local.example .env.local
   ```

2. **Configure HeyGen Settings**
   ```env
   HEYGEN_API_KEY=your_heygen_api_key_here
   HEYGEN_AVATAR_ID=your_avatar_id_here
   HEYGEN_VOICE_ID=your_voice_id_here
   ```

3. **Optional Integrations**
   ```env
   # CRM Integration
   CRM_API_KEY=your_crm_api_key_here
   CRM_BASE_URL=https://api.your-crm.com
   
   # Email Notifications
   EMAIL_SERVICE_API_KEY=your_email_service_key_here
   EMAIL_FROM=chris@chrisdeutsch.com
   ```

### 3. Installation

1. **Install Dependencies**
   ```bash
   npm install
   # or
   yarn install
   ```

2. **Development Server**
   ```bash
   npm run dev
   # or
   yarn dev
   ```

3. **Access the Avatar**
   - Open http://localhost:3000
   - Navigate to the "Meet Chris Deutsch Virtually" section
   - Click "Start Conversation" to begin

## Usage Guide

### **For Visitors**

1. **Starting a Conversation**
   - Click the "Start Conversation" button
   - Allow microphone access when prompted
   - Wait for the avatar to connect and greet you

2. **Interacting with Chris**
   - Speak naturally or use the chat interface
   - Ask about properties, neighborhoods, or market conditions
   - Use quick action buttons for common topics

3. **Getting Property Information**
   - Ask about specific neighborhoods like Golden Valley or Bryn Mawr
   - Inquire about current market conditions
   - Request property recommendations

### **For Administrators**

1. **Monitoring Conversations**
   - Check `/api/leads` for lead analytics
   - Review conversation logs and topics
   - Track conversion metrics

2. **Updating Responses**
   - Modify conversation flows in `heygen-service.ts`
   - Update market data and property information
   - Customize avatar responses for new scenarios

## Conversation Flow Examples

### **Property Inquiry**
```
User: "Tell me about homes in Golden Valley"
Avatar: "Excellent choice! Golden Valley is one of my specialty 
         neighborhoods. With my 25 years of expertise in this area,
         I can tell you it offers exceptional suburban living with
         top-rated schools and beautiful tree-lined streets..."
```

### **Market Discussion**
```
User: "What's the current market like?"
Avatar: "The Twin Cities market is performing very well right now!
         We're seeing a median home price around $425,000, with
         homes selling in about 18 days on average..."
```

### **Lead Qualification**
```
User: "I'm looking to buy soon"
Avatar: "That's exciting! I'd love to help you find your perfect
         home. Are you interested in a specific neighborhood,
         price range, or type of home?"
```

## Customization Options

### **Avatar Personality**
- Update conversation templates in `REAL_ESTATE_PROMPTS`
- Modify response tone and style
- Add new topic expertise areas

### **Lead Scoring**
- Adjust urgency scoring algorithm
- Customize follow-up priorities
- Add new qualification criteria

### **Visual Design**
- Update color scheme in component styles
- Modify layout and positioning
- Add custom animations and effects

## API Reference

### **HeyGen Service Methods**

```typescript
// Create new streaming session
await heygenService.createSession()

// Send message with context
await heygenService.sendMessage(message, context)

// Generate property introduction
await heygenService.generatePropertyIntroduction(propertyData)

// Capture lead from conversation
await heygenService.captureLeadFromConversation(leadData)

// End session
await heygenService.endSession()
```

### **API Endpoints**

```
POST /api/heygen
├── create_session    # Initialize avatar session
├── send_message      # Send message to avatar
├── property_intro    # Generate property introduction
└── end_session       # Close avatar session

POST /api/leads       # Capture lead information
GET  /api/leads       # Get lead analytics
```

## Performance Considerations

### **Optimization**
- WebRTC connections are optimized for low latency
- Avatar responses are cached for common queries
- Mobile users get optimized streaming quality
- Fallback options for unsupported browsers

### **Monitoring**
- Track session duration and engagement
- Monitor conversion rates by topic
- Analyze most common conversation paths
- Measure lead quality from avatar interactions

## Troubleshooting

### **Common Issues**

1. **Avatar Won't Load**
   - Check API credentials in .env.local
   - Verify HeyGen account permissions
   - Ensure network connectivity

2. **No Audio/Video**
   - Check browser permissions for microphone
   - Verify WebRTC compatibility
   - Test with different browsers

3. **Slow Response Times**
   - Check internet connection speed
   - Verify HeyGen service status
   - Monitor API rate limits

### **Browser Compatibility**
- **Recommended**: Chrome 88+, Firefox 85+, Safari 14+
- **Fallback**: Text-only chat for unsupported browsers
- **Mobile**: Optimized for iOS Safari and Android Chrome

## Support & Maintenance

### **Updates**
- Regular avatar model improvements
- New conversation scenarios
- Enhanced lead qualification
- Performance optimizations

### **Analytics**
- Conversation success rates
- Lead conversion tracking
- Popular discussion topics
- User engagement metrics

## Security & Privacy

### **Data Protection**
- All conversations are encrypted
- Lead data follows GDPR compliance
- API keys are securely stored
- User permissions are respected

### **Privacy Features**
- Optional conversation recording
- User consent for data collection
- Secure lead information handling
- Regular security audits

---

## Next Steps

1. **Test the Integration**: Start conversations and verify functionality
2. **Customize Responses**: Tailor avatar responses to your specific needs
3. **Monitor Performance**: Track engagement and conversion metrics
4. **Scale Usage**: Increase avatar availability and features
5. **Gather Feedback**: Collect user feedback for improvements

For technical support or customization requests, contact the development team or refer to the HeyGen documentation.