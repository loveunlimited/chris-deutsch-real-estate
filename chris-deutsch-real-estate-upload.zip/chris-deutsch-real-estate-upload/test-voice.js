/**
 * Simple ElevenLabs Voice Test
 */

require('dotenv').config();

async function testVoice() {
  console.log('🎤 Testing ElevenLabs voice clone...');
  console.log('API Key:', process.env.ELEVENLABS_API_KEY ? 'Present' : 'Missing');
  console.log('Voice ID:', process.env.ELEVENLABS_VOICE_ID ? 'Present' : 'Missing');
  
  const testText = "Hello, this is Chris Deutsch testing my AI voice clone. This is working perfectly!";
  
  try {
    const response = await fetch(`https://api.elevenlabs.io/v1/text-to-speech/${process.env.ELEVENLABS_VOICE_ID}`, {
      method: 'POST',
      headers: {
        'Accept': 'audio/mpeg',
        'Content-Type': 'application/json',
        'xi-api-key': process.env.ELEVENLABS_API_KEY
      },
      body: JSON.stringify({
        text: testText,
        model_id: "eleven_monolingual_v1",
        voice_settings: {
          speed: 1.05,       // Perfect pace
          stability: 0.65,   // Great pitch variation + expression
          similarity_boost: 0.7    // Authentic balance
        }
      })
    });

    console.log('Response status:', response.status);
    console.log('Response headers:', Object.fromEntries(response.headers.entries()));
    
    if (response.ok) {
      const audioBuffer = await response.arrayBuffer();
      const fs = require('fs');
      fs.writeFileSync('./test-voice.mp3', Buffer.from(audioBuffer));
      console.log('✅ SUCCESS! Test audio created: test-voice.mp3');
      console.log('File size:', (audioBuffer.byteLength / 1024).toFixed(1), 'KB');
    } else {
      const errorText = await response.text();
      console.log('❌ Error response:', errorText);
    }
    
  } catch (error) {
    console.log('❌ Network error:', error.message);
  }
}

testVoice();