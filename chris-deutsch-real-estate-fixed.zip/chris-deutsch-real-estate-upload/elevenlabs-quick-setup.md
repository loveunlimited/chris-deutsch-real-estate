# ELEVENLABS VOICE CLONE - 5 MINUTE SETUP
## Get Chris Deutsch's AI Voice Working Today

### STEP 1: CREATE ELEVENLABS ACCOUNT (2 minutes)
1. Go to https://elevenlabs.io
2. Sign up with email
3. Choose **Creator Plan** ($22/month) for commercial use
4. Verify your email

### STEP 2: CLONE YOUR VOICE (3 minutes)
1. Click **"Voices"** in the left sidebar
2. Click **"Add Voice"** → **"Instant Voice Cloning"**
3. **Record 1-2 minutes** of clear speech:

```
Sample Script for Chris Deutsch:
"Hi, I'm Chris Deutsch, your Twin Cities real estate expert with 25 years of experience. I specialize in helping families in Golden Valley, Bryn Mawr, and throughout the Minneapolis metro area. Whether you're looking to buy your first home, sell your current property, or invest in real estate, I'm here to provide the personalized service and market expertise you deserve. Let me help make your real estate dreams a reality."
```

4. **Name your voice:** "Chris Deutsch Professional"
5. Click **"Add Voice"**
6. **Copy the Voice ID** (you'll need this)

### STEP 3: GET API KEY (30 seconds)
1. Click your profile → **"Profile"**
2. Copy your **API Key**
3. Keep it secure!

### STEP 4: TEST YOUR VOICE (1 minute)
Add to your `.env` file:
```
ELEVENLABS_API_KEY=your_api_key_here
ELEVENLABS_VOICE_ID=your_voice_id_here
```

Test with this script:
```javascript
const response = await fetch('https://api.elevenlabs.io/v1/text-to-speech/YOUR_VOICE_ID', {
  method: 'POST',
  headers: {
    'Accept': 'audio/mpeg',
    'Content-Type': 'application/json',
    'xi-api-key': 'YOUR_API_KEY'
  },
  body: JSON.stringify({
    text: "This is a test of my AI voice clone. It sounds just like me!",
    model_id: "eleven_monolingual_v1"
  })
});
```

### IMMEDIATE USE CASES:
- **Property introductions** for listings
- **Market update voiceovers** 
- **Personalized client messages**
- **Social media content**
- **Email video messages**

**Total Setup Time: 5 minutes**
**Monthly Cost: $22**
**Immediate Value: Unlimited personalized voice content**