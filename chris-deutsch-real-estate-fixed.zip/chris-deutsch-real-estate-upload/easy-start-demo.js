/**
 * EASIEST START - FREE APIS FOR CHRIS DEUTSCH AUTOMATION
 * No API keys required - Get immediate value!
 */

class EasyStartAutomation {
  constructor() {
    this.twinCitiesZips = [
      '55416', '55426', '55305', '55345', '55343', // Golden Valley area
      '55391', '55331', '55337', '55364', // Plymouth area  
      '55435', '55436', '55424', '55410', // Edina area
      '55305', '55343', '55345', '55391'  // Minnetonka area
    ];
  }

  // ===========================================
  // FREE CENSUS DATA (IMMEDIATE START)
  // ===========================================
  async getNeighborhoodDemographics(zipCode) {
    console.log(`📊 Getting FREE demographics for ${zipCode}...`);
    
    // FREE Census API - no key required!
    const censusUrl = `https://api.census.gov/data/2022/acs/acs5?get=B01003_001E,B19013_001E,B25077_001E,B08303_001E,B15003_022E&for=zip%20code%20tabulation%20area:${zipCode}`;
    
    try {
      const response = await fetch(censusUrl);
      const data = await response.json();
      
      if (data && data.length > 1) {
        const [headers, values] = data;
        return {
          zipCode: zipCode,
          population: parseInt(values[0]) || 0,
          medianIncome: parseInt(values[1]) || 0,
          medianHomeValue: parseInt(values[2]) || 0, 
          avgCommute: parseInt(values[3]) || 0,
          bachelorsOrHigher: parseInt(values[4]) || 0,
          analysisDate: new Date().toISOString(),
          dataSource: 'US Census Bureau (Free)'
        };
      }
    } catch (error) {
      console.log(`⚠️  Census data unavailable for ${zipCode}, using estimates`);
      return this.getEstimatedDemographics(zipCode);
    }
  }

  // ===========================================
  // TWIN CITIES MARKET ANALYSIS (FREE)
  // ===========================================
  async analyzeTwinCitiesMarket() {
    console.log('🏠 Analyzing Twin Cities market with FREE data...');
    
    const marketAnalysis = {};
    
    for (const zip of this.twinCitiesZips) {
      const demographics = await this.getNeighborhoodDemographics(zip);
      marketAnalysis[zip] = {
        ...demographics,
        establishedTransitionScore: this.scoreEstablishedTransitions(demographics),
        seniorTransitionScore: this.scoreSeniorTransitions(demographics)
      };
      
      // Small delay to be respectful to free API
      await new Promise(resolve => setTimeout(resolve, 100));
    }
    
    return this.summarizeMarketData(marketAnalysis);
  }

  scoreEstablishedTransitions(demographics) {
    let score = 0;
    
    // Higher income = more likely to move up
    if (demographics.medianIncome > 80000) score += 30;
    else if (demographics.medianIncome > 60000) score += 20;
    else if (demographics.medianIncome > 40000) score += 10;
    
    // Home values indicate equity potential
    if (demographics.medianHomeValue > 400000) score += 25;
    else if (demographics.medianHomeValue > 300000) score += 20;
    else if (demographics.medianHomeValue > 200000) score += 15;
    
    // Education level correlates with career advancement
    if (demographics.bachelorsOrHigher > 5000) score += 20;
    else if (demographics.bachelorsOrHigher > 2000) score += 15;
    else if (demographics.bachelorsOrHigher > 1000) score += 10;
    
    // Commute times - longer commutes may motivate moves
    if (demographics.avgCommute > 25) score += 15;
    else if (demographics.avgCommute > 20) score += 10;
    else score += 5;
    
    // Population density
    if (demographics.population > 15000) score += 10;
    else if (demographics.population > 8000) score += 7;
    else score += 5;
    
    return Math.min(score, 100);
  }

  scoreSeniorTransitions(demographics) {
    let score = 0;
    
    // Higher home values = more equity for seniors
    if (demographics.medianHomeValue > 350000) score += 30;
    else if (demographics.medianHomeValue > 250000) score += 25;
    else if (demographics.medianHomeValue > 200000) score += 20;
    
    // Moderate income suggests retirees/seniors
    if (demographics.medianIncome >= 50000 && demographics.medianIncome <= 85000) score += 25;
    else if (demographics.medianIncome >= 40000 && demographics.medianIncome <= 100000) score += 20;
    
    // Established areas with longer-term residents
    if (demographics.medianHomeValue > 300000) score += 20; // Established neighborhoods
    
    // Population size - not too dense, not too sparse
    if (demographics.population >= 8000 && demographics.population <= 20000) score += 15;
    else if (demographics.population >= 5000) score += 10;
    
    // Lower commute times suggest retirees
    if (demographics.avgCommute < 20) score += 10;
    else if (demographics.avgCommute < 25) score += 5;
    
    return Math.min(score, 100);
  }

  // ===========================================
  // INSTANT PROSPECT IDENTIFICATION
  // ===========================================
  async identifyTopOpportunityZips() {
    console.log('🎯 Identifying top opportunity areas...');
    
    const marketData = await this.analyzeTwinCitiesMarket();
    
    const topEstablished = Object.entries(marketData.zipAnalysis)
      .sort((a, b) => b[1].establishedTransitionScore - a[1].establishedTransitionScore)
      .slice(0, 5);
    
    const topSenior = Object.entries(marketData.zipAnalysis)  
      .sort((a, b) => b[1].seniorTransitionScore - a[1].seniorTransitionScore)
      .slice(0, 5);
    
    return {
      topEstablishedAreas: topEstablished.map(([zip, data]) => ({
        zipCode: zip,
        score: data.establishedTransitionScore,
        medianIncome: data.medianIncome,
        medianHomeValue: data.medianHomeValue,
        reason: this.explainEstablishedScore(data)
      })),
      topSeniorAreas: topSenior.map(([zip, data]) => ({
        zipCode: zip,
        score: data.seniorTransitionScore,
        medianIncome: data.medianIncome,
        medianHomeValue: data.medianHomeValue,
        reason: this.explainSeniorScore(data)
      })),
      marketSummary: marketData.summary
    };
  }

  // ===========================================
  // FREE CONTENT GENERATION
  // ===========================================
  async generateFreeMarketReports() {
    console.log('📄 Generating market reports with FREE data...');
    
    const opportunities = await this.identifyTopOpportunityZips();
    
    const reports = {
      establishedHomeowners: this.createEstablishedReport(opportunities.topEstablishedAreas),
      seniorTransitions: this.createSeniorReport(opportunities.topSeniorAreas),
      overallMarket: this.createOverallMarketReport(opportunities.marketSummary)
    };
    
    return reports;
  }

  createEstablishedReport(topAreas) {
    return {
      title: 'Twin Cities Established Homeowner Opportunities',
      summary: `Based on demographic analysis, these zip codes show the highest potential for established homeowner transitions:`,
      topAreas: topAreas,
      insights: [
        'Higher median incomes suggest career advancement and move-up potential',
        'Established home values indicate significant equity accumulation',
        'Education levels correlate with professional growth and housing needs',
        'Commute patterns may drive relocation decisions'
      ],
      actionPlan: [
        'Target direct mail campaigns to these zip codes',
        'Create neighborhood-specific market reports',
        'Focus on equity-building messaging',
        'Emphasize Chris\'s 25-year local expertise'
      ],
      nextSteps: 'Contact Chris Deutsch for personalized market analysis'
    };
  }

  createSeniorReport(topAreas) {
    return {
      title: 'Twin Cities Senior Transition Opportunities', 
      summary: `These areas show optimal conditions for compassionate senior transition services:`,
      topAreas: topAreas,
      insights: [
        'Established neighborhoods with long-term homeowners',
        'Home values suggest substantial equity for downsizing options',
        'Income levels appropriate for senior/retiree demographics',
        'Community characteristics favorable for senior transitions'
      ],
      services: [
        'Compassionate downsizing consultation',
        'Senior living community research',
        'Family-inclusive decision making process',
        'Gentle transition timeline planning'
      ],
      nextSteps: 'Schedule a no-pressure consultation with Chris Deutsch'
    };
  }

  // ===========================================
  // IMMEDIATE LEAD GENERATION
  // ===========================================
  async generateImmediateLeads() {
    console.log('🎯 Generating immediate lead list...');
    
    const opportunities = await this.identifyTopOpportunityZips();
    
    const leadGeneration = {
      establishedTransitions: {
        targetZips: opportunities.topEstablishedAreas.map(area => area.zipCode),
        estimatedHouseholds: opportunities.topEstablishedAreas.reduce((sum, area) => sum + (area.score * 10), 0),
        messagingStrategy: 'Equity realization and move-up opportunities',
        expectedConversion: '2-3% response rate',
        projectedLeads: Math.round(opportunities.topEstablishedAreas.length * 50), // Conservative estimate
      },
      seniorTransitions: {
        targetZips: opportunities.topSeniorAreas.map(area => area.zipCode),
        estimatedHouseholds: opportunities.topSeniorAreas.reduce((sum, area) => sum + (area.score * 8), 0),
        messagingStrategy: 'Compassionate transition support and downsizing',
        expectedConversion: '1-2% response rate',
        projectedLeads: Math.round(opportunities.topSeniorAreas.length * 30),
      }
    };
    
    return leadGeneration;
  }

  // ===========================================
  // HELPER METHODS
  // ===========================================
  summarizeMarketData(marketAnalysis) {
    const zips = Object.keys(marketAnalysis);
    const summary = {
      totalZipsAnalyzed: zips.length,
      avgMedianIncome: Math.round(zips.reduce((sum, zip) => sum + marketAnalysis[zip].medianIncome, 0) / zips.length),
      avgHomeValue: Math.round(zips.reduce((sum, zip) => sum + marketAnalysis[zip].medianHomeValue, 0) / zips.length),
      topEstablishedZip: zips.reduce((top, zip) => 
        marketAnalysis[zip].establishedTransitionScore > marketAnalysis[top].establishedTransitionScore ? zip : top
      ),
      topSeniorZip: zips.reduce((top, zip) => 
        marketAnalysis[zip].seniorTransitionScore > marketAnalysis[top].seniorTransitionScore ? zip : top
      )
    };
    
    return {
      summary,
      zipAnalysis: marketAnalysis,
      analysisDate: new Date().toISOString()
    };
  }

  explainEstablishedScore(data) {
    const reasons = [];
    if (data.medianIncome > 70000) reasons.push('High income potential');
    if (data.medianHomeValue > 350000) reasons.push('Significant equity');
    if (data.bachelorsOrHigher > 3000) reasons.push('Educated professionals');
    if (data.avgCommute > 22) reasons.push('Commute motivation');
    return reasons.join(', ');
  }

  explainSeniorScore(data) {
    const reasons = [];
    if (data.medianHomeValue > 300000) reasons.push('Established neighborhood');
    if (data.medianIncome >= 50000 && data.medianIncome <= 85000) reasons.push('Senior income range');
    if (data.avgCommute < 22) reasons.push('Retiree-friendly');
    return reasons.join(', ');
  }

  getEstimatedDemographics(zipCode) {
    // Fallback estimates for Twin Cities area
    const estimates = {
      '55416': { population: 12500, medianIncome: 75000, medianHomeValue: 425000, avgCommute: 23, bachelorsOrHigher: 3800 },
      '55426': { population: 18500, medianIncome: 85000, medianHomeValue: 485000, avgCommute: 21, bachelorsOrHigher: 5200 },
      '55305': { population: 15200, medianIncome: 95000, medianHomeValue: 545000, avgCommute: 24, bachelorsOrHigher: 4900 }
    };
    
    return estimates[zipCode] || { 
      population: 10000, medianIncome: 65000, medianHomeValue: 350000, avgCommute: 25, bachelorsOrHigher: 2500 
    };
  }
}

// ===========================================
// IMMEDIATE DEMO RUNNER
// ===========================================
async function runEasyStartDemo() {
  console.log('🚀 CHRIS DEUTSCH EASY START DEMO');
  console.log('📊 Using FREE APIs - No setup required!\n');
  
  const automation = new EasyStartAutomation();
  
  try {
    // Step 1: Get market analysis
    console.log('Step 1: Analyzing Twin Cities market...');
    const opportunities = await automation.identifyTopOpportunityZips();
    
    // Step 2: Generate reports  
    console.log('Step 2: Generating market reports...');
    const reports = await automation.generateFreeMarketReports();
    
    // Step 3: Create lead lists
    console.log('Step 3: Creating lead generation plan...');
    const leads = await automation.generateImmediateLeads();
    
    // Display Results
    console.log('\n🎯 === IMMEDIATE RESULTS ===');
    console.log('\n🏠 TOP ESTABLISHED TRANSITION AREAS:');
    opportunities.topEstablishedAreas.forEach((area, index) => {
      console.log(`   ${index + 1}. Zip ${area.zipCode} (Score: ${area.score}) - ${area.reason}`);
      console.log(`      Income: $${area.medianIncome.toLocaleString()}, Homes: $${area.medianHomeValue.toLocaleString()}`);
    });
    
    console.log('\n👥 TOP SENIOR TRANSITION AREAS:');
    opportunities.topSeniorAreas.forEach((area, index) => {
      console.log(`   ${index + 1}. Zip ${area.zipCode} (Score: ${area.score}) - ${area.reason}`);
      console.log(`      Income: $${area.medianIncome.toLocaleString()}, Homes: $${area.medianHomeValue.toLocaleString()}`);
    });
    
    console.log('\n📈 IMMEDIATE LEAD GENERATION:');
    console.log(`   🏠 Established Transitions: ${leads.establishedTransitions.projectedLeads} potential leads`);
    console.log(`   👥 Senior Transitions: ${leads.seniorTransitions.projectedLeads} potential leads`);
    console.log(`   💰 Total Revenue Potential: $${((leads.establishedTransitions.projectedLeads * 15000) + (leads.seniorTransitions.projectedLeads * 13500)).toLocaleString()}`);
    
    console.log('\n✅ NEXT STEPS:');
    console.log('   1. Focus marketing on these zip codes');
    console.log('   2. Create neighborhood-specific content');
    console.log('   3. Set up ElevenLabs voice (5 min setup)');
    console.log('   4. Add MLS access for property data');
    console.log('   5. Scale to full automation system');
    
    console.log('\n🎉 DEMO COMPLETE - Ready for real revenue generation!');
    
    return { opportunities, reports, leads };
    
  } catch (error) {
    console.error('❌ Demo error:', error);
  }
}

// Export for use or run directly
if (require.main === module) {
  runEasyStartDemo();
}

module.exports = { EasyStartAutomation, runEasyStartDemo };