/**
 * STARTUP SCRIPT FOR CHRIS DEUTSCH REAL ESTATE AUTOMATION
 * Priority: Established Transitions → Senior Transitions → All Others
 */

const { EstablishedTransitionsAutomation } = require('./established-transitions-automation');
const { SeniorTransitionsAutomation } = require('./senior-transitions-automation');
const { RealEstateDataAnalyzer } = require('./real-estate-apis');

class ChrisDeutschAutomationLauncher {
  constructor() {
    this.dataAnalyzer = new RealEstateDataAnalyzer();
    this.establishedTransitions = new EstablishedTransitionsAutomation(this.dataAnalyzer);
    this.seniorTransitions = new SeniorTransitionsAutomation(this.dataAnalyzer);
    this.isRunning = false;
  }

  async startPriorityNiches() {
    console.log('🚀 CHRIS DEUTSCH REAL ESTATE AI AUTOMATION STARTING...');
    console.log('📊 Priority Order: Established Transitions → Senior Transitions');
    
    this.isRunning = true;
    
    try {
      // PHASE 1: ESTABLISHED HOMEOWNER TRANSITIONS (Primary Focus)
      console.log('\n🏠 === PHASE 1: ESTABLISHED HOMEOWNER TRANSITIONS ===');
      const establishedResults = await this.establishedTransitions.runEstablishedTransitionsAutomation();
      
      // Display Results
      this.displayEstablishedResults(establishedResults);
      
      // PHASE 2: SENIOR TRANSITIONS (Secondary Focus)
      console.log('\n👥 === PHASE 2: SENIOR LIVING TRANSITIONS ===');
      const seniorResults = await this.seniorTransitions.runSeniorTransitionsAutomation();
      
      // Display Results
      this.displaySeniorResults(seniorResults);
      
      // COMBINED SUMMARY
      const combinedSummary = this.createCombinedSummary(establishedResults, seniorResults);
      this.displayCombinedSummary(combinedSummary);
      
      // Save results for Claude Code integration
      await this.saveResultsForClaudeCode(combinedSummary);
      
      console.log('\n✅ AUTOMATION COMPLETE - READY FOR REVENUE GENERATION!');
      
      return combinedSummary;
      
    } catch (error) {
      console.error('❌ Automation error:', error);
      this.isRunning = false;
      throw error;
    }
  }

  displayEstablishedResults(results) {
    console.log('\n📈 ESTABLISHED TRANSITIONS RESULTS:');
    console.log(`   💼 Total Prospects: ${results.totalProspects}`);
    console.log(`   🎯 High Priority: ${results.highPriorityProspects}`);
    console.log(`   💰 Revenue Potential: $${results.revenueProjection.totalRevenue.toLocaleString()}`);
    console.log(`   🏡 Projected Deals: ${results.revenueProjection.projectedDeals}`);
    console.log(`   💸 Avg Deal Value: $${results.revenueProjection.avgDealValue.toLocaleString()}`);
    console.log(`   📹 Video Messages: ${results.videoMessages} created`);
    console.log(`   📊 Market Reports: ${results.marketReports} personalized`);
  }

  displaySeniorResults(results) {
    console.log('\n📈 SENIOR TRANSITIONS RESULTS:');
    console.log(`   👥 Total Prospects: ${results.totalProspects}`);
    console.log(`   🎯 Priority Prospects: ${results.priorityProspects}`);
    console.log(`   💰 Revenue Potential: $${results.revenueProjection.totalRevenue.toLocaleString()}`);
    console.log(`   🏡 Projected Deals: ${results.revenueProjection.projectedDeals}`);
    console.log(`   🏘️ Senior Communities: ${results.seniorCommunityOptions} researched`);
    console.log(`   📚 Educational Content: ${results.educationalContent} packages`);
    console.log(`   ⏰ Timeline: ${results.revenueProjection.timelineMonths} months (patient approach)`);
  }

  createCombinedSummary(establishedResults, seniorResults) {
    const totalRevenue = establishedResults.revenueProjection.totalRevenue + 
                        seniorResults.revenueProjection.totalRevenue;
    const totalDeals = establishedResults.revenueProjection.projectedDeals + 
                      seniorResults.revenueProjection.projectedDeals;
    const totalProspects = establishedResults.totalProspects + seniorResults.totalProspects;

    return {
      timestamp: new Date().toISOString(),
      automationStatus: 'ACTIVE',
      primaryNiches: ['established_transitions', 'senior_transitions'],
      combinedMetrics: {
        totalProspects: totalProspects,
        totalRevenuePotential: totalRevenue,
        totalProjectedDeals: totalDeals,
        avgDealValue: totalRevenue / totalDeals,
        roi: this.calculateROI(totalRevenue),
        timeToFirstDeal: '30-45 days (established), 60-90 days (senior)'
      },
      establishedNiche: {
        prospects: establishedResults.totalProspects,
        priority: establishedResults.highPriorityProspects,
        revenue: establishedResults.revenueProjection.totalRevenue,
        deals: establishedResults.revenueProjection.projectedDeals,
        conversionRate: '30%',
        timeline: '90 days average'
      },
      seniorNiche: {
        prospects: seniorResults.totalProspects,
        priority: seniorResults.priorityProspects,
        revenue: seniorResults.revenueProjection.totalRevenue,
        deals: seniorResults.revenueProjection.projectedDeals,
        conversionRate: '25%',
        timeline: '12 months average',
        lifetimeValue: seniorResults.revenueProjection.lifetimeValue
      },
      nextActions: [
        'Review and approve top prospects in both niches',
        'Launch personalized video messages for established transitions',
        'Begin gentle outreach sequences for senior prospects',
        'Monitor engagement metrics and adjust messaging',
        'Schedule personal follow-ups with highest-scored prospects',
        'Prepare for scaling to remaining 5 niches'
      ],
      claudeCodeIntegration: {
        status: 'ready',
        commands: [
          'claude-code established-followup --priority=high',
          'claude-code senior-outreach --gentle=true',
          'claude-code revenue-tracking --niches=established,senior',
          'claude-code content-generation --personalized=true'
        ]
      }
    };
  }

  displayCombinedSummary(summary) {
    console.log('\n🎯 === COMBINED AUTOMATION SUMMARY ===');
    console.log(`⏰ Status: ${summary.automationStatus}`);
    console.log(`📊 Total Prospects: ${summary.combinedMetrics.totalProspects}`);
    console.log(`💰 Combined Revenue Potential: $${summary.combinedMetrics.totalRevenuePotential.toLocaleString()}`);
    console.log(`🏡 Total Projected Deals: ${summary.combinedMetrics.totalProjectedDeals}`);
    console.log(`💸 Average Deal Value: $${summary.combinedMetrics.avgDealValue.toLocaleString()}`);
    console.log(`📈 ROI: ${summary.combinedMetrics.roi}%`);
    
    console.log('\n🎯 NICHE BREAKDOWN:');
    console.log(`   🏠 Established Transitions: ${summary.establishedNiche.prospects} prospects → $${summary.establishedNiche.revenue.toLocaleString()}`);
    console.log(`   👥 Senior Transitions: ${summary.seniorNiche.prospects} prospects → $${summary.seniorNiche.revenue.toLocaleString()}`);
    
    console.log('\n📋 IMMEDIATE NEXT ACTIONS:');
    summary.nextActions.forEach((action, index) => {
      console.log(`   ${index + 1}. ${action}`);
    });
    
    console.log('\n🤖 CLAUDE CODE READY:');
    summary.claudeCodeIntegration.commands.forEach(command => {
      console.log(`   → ${command}`);
    });
  }

  calculateROI(totalRevenue) {
    const estimatedCosts = 15000; // API costs, tools, time investment
    return Math.round(((totalRevenue - estimatedCosts) / estimatedCosts) * 100);
  }

  async saveResultsForClaudeCode(summary) {
    const fs = require('fs').promises;
    
    // Save for Claude Code MCP integration
    await fs.writeFile(
      './automation-results.json', 
      JSON.stringify(summary, null, 2)
    );
    
    // Create Claude Code command file
    const claudeCommands = `# CHRIS DEUTSCH AUTOMATION - CLAUDE CODE COMMANDS

## Daily Commands
claude-code run-automation --niches="established,senior"
claude-code check-prospects --priority="high"
claude-code generate-content --personalized=true

## Established Transitions
claude-code established-prospects --min-score=70
claude-code create-videos --niche="established" --count=20
claude-code market-reports --niche="established" --personalized=true

## Senior Transitions  
claude-code senior-prospects --min-score=65 --gentle=true
claude-code create-content --niche="senior" --educational=true
claude-code family-materials --niche="senior" --compassionate=true

## Revenue Tracking
claude-code revenue-dashboard --niches="established,senior"
claude-code conversion-tracking --daily=true
claude-code roi-analysis --timeframe="monthly"

## Content Generation
claude-code video-scripts --niche="established" --personalized=true
claude-code voice-narration --voice="chris_deutsch"
claude-code social-content --niches="established,senior"

## Lead Management
claude-code prospect-scoring --update=true
claude-code follow-up-sequences --automated=true
claude-code crm-integration --sync=true
`;
    
    await fs.writeFile('./claude-code-commands.md', claudeCommands);
    
    console.log('\n💾 Results saved for Claude Code integration');
    console.log('   📄 automation-results.json');
    console.log('   📄 claude-code-commands.md');
  }

  // Method to check system status
  getSystemStatus() {
    return {
      isRunning: this.isRunning,
      activeNiches: ['established_transitions', 'senior_transitions'],
      nextScheduledRun: new Date(Date.now() + 24 * 60 * 60 * 1000), // Tomorrow
      systemHealth: 'OPTIMAL'
    };
  }

  // Method to manually trigger specific niche
  async runSpecificNiche(nicheName) {
    switch(nicheName) {
      case 'established':
        return await this.establishedTransitions.runEstablishedTransitionsAutomation();
      case 'senior':
        return await this.seniorTransitions.runSeniorTransitionsAutomation();
      default:
        throw new Error(`Unknown niche: ${nicheName}`);
    }
  }
}

// CLI Interface for direct execution
async function main() {
  const launcher = new ChrisDeutschAutomationLauncher();
  
  try {
    const results = await launcher.startPriorityNiches();
    
    console.log('\n🎉 AUTOMATION LAUNCHED SUCCESSFULLY!');
    console.log('💡 Chris, your AI system is now working 24/7 to:');
    console.log('   • Identify high-probability prospects');
    console.log('   • Create personalized content');
    console.log('   • Generate market reports');
    console.log('   • Schedule automated outreach');
    console.log('   • Track revenue opportunities');
    
    console.log('\n📞 NEXT: Review your prospect lists and approve the first batch of outreach!');
    
  } catch (error) {
    console.error('❌ Startup failed:', error.message);
    process.exit(1);
  }
}

// Export for use as module or run directly
if (require.main === module) {
  main();
}

module.exports = { ChrisDeutschAutomationLauncher };