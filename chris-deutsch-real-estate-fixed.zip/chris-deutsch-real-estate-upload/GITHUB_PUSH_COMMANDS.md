# 🚀 GITHUB DEPLOYMENT COMMANDS

## After creating your GitHub repository, run these commands:

```bash
# Add your GitHub repository as remote (replace with YOUR GitHub username)
git remote add origin https://github.com/YOURUSERNAME/chris-deutsch-real-estate.git

# Push to GitHub
git push -u origin main
```

## Example (replace 'cjdeutsch' with your GitHub username):
```bash
git remote add origin https://github.com/cjdeutsch/chris-deutsch-real-estate.git
git push -u origin main
```

## ✅ After GitHub push is complete:

1. Go to [vercel.com](https://vercel.com)
2. Sign in with your GitHub account
3. Click "New Project"
4. Find "chris-deutsch-real-estate" in your repositories
5. Click "Import"
6. Vercel will auto-detect Next.js settings
7. Click "Deploy"

## 🔐 Add Environment Variables in Vercel:

**Settings → Environment Variables → Add:**

```
ELEVENLABS_API_KEY = sk_d4dfd70aa1ae7d8c0358f62d1d9875cea8f0dd91f9799927
ELEVENLABS_VOICE_ID = dAZqM8Pl37bzdPFxvgXm
HEYGEN_API_KEY = sk_00692be258d6b0cd5c0da0644a34cbc62fde92bbd09a34c0
HEYGEN_MONTHLY_BUDGET = 40
HEYGEN_VIDEO_LIMIT = 10
NODE_ENV = production
```

## 🎉 Result:
You'll get a live URL like: `https://chris-deutsch-real-estate-abc123.vercel.app`

**Your AI-powered real estate platform will be live for the world to see!**