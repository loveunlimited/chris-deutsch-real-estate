'use client';

import { useState, useEffect } from 'react';
import { Card } from './card';
import { Button } from './button';
import { User, Mail, Phone, Home, MessageSquare, ArrowRight, Shield, Clock, CheckCircle } from 'lucide-react';

interface LeadData {
  name: string;
  email: string;
  phone: string;
  interest: string;
  timeline: string;
  source: string;
}

interface SmartLeadCaptureProps {
  context?: 'equity-calculator' | 'market-map' | 'general' | 'avatar-chat';
  contextData?: any;
  onSubmit?: (data: LeadData) => void;
}

export default function SmartLeadCapture({ 
  context = 'general', 
  contextData, 
  onSubmit 
}: SmartLeadCaptureProps) {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState<Partial<LeadData>>({
    source: context
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isComplete, setIsComplete] = useState(false);

  const totalSteps = 4;

  const getContextualHeading = () => {
    switch (context) {
      case 'equity-calculator':
        return 'Get Your Personalized Market Analysis';
      case 'market-map':
        return 'Explore Your Neighborhood Opportunities';
      case 'avatar-chat':
        return 'Continue the Conversation';
      default:
        return 'Let\'s Find Your Perfect Home';
    }
  };

  const getContextualSubheading = () => {
    switch (context) {
      case 'equity-calculator':
        return 'Chris will provide a detailed analysis of your property\'s potential with 25 years of market expertise.';
      case 'market-map':
        return 'Get insider insights about your preferred neighborhoods from Chris\'s specialty areas.';
      case 'avatar-chat':
        return 'Chris will personally follow up on your questions with detailed market insights.';
      default:
        return 'Chris\'s 25 years of Twin Cities expertise will guide you to the perfect stress-free transaction.';
    }
  };

  const handleInputChange = (field: keyof LeadData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleNext = () => {
    if (currentStep < totalSteps) {
      setCurrentStep(prev => prev + 1);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(prev => prev - 1);
    }
  };

  const handleSubmit = async () => {
    setIsSubmitting(true);
    
    // Simulate API submission
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    const leadData: LeadData = {
      name: formData.name || '',
      email: formData.email || '',
      phone: formData.phone || '',
      interest: formData.interest || '',
      timeline: formData.timeline || '',
      source: context
    };

    // Add context data if available
    if (contextData) {
      // Here you would include contextData in the submission
      console.log('Context data:', contextData);
    }

    if (onSubmit) {
      onSubmit(leadData);
    }

    setIsSubmitting(false);
    setIsComplete(true);
  };

  const isStepValid = (step: number) => {
    switch (step) {
      case 1: return formData.name && formData.name.length >= 2;
      case 2: return formData.email && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email);
      case 3: return formData.interest;
      case 4: return formData.timeline;
      default: return false;
    }
  };

  if (isComplete) {
    return (
      <Card className="p-8 text-center space-y-6 bg-gradient-to-br from-green-50 to-green-100 border-2 border-green-200">
        <div className="w-16 h-16 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center mx-auto animate-number-count">
          <CheckCircle className="w-8 h-8 text-white" />
        </div>
        
        <div>
          <h3 className="text-2xl font-bold text-green-800 mb-2">
            Thank you, {formData.name}!
          </h3>
          <p className="text-green-700 leading-relaxed">
            Chris will personally reach out within 24 hours with your 
            {context === 'equity-calculator' ? ' detailed equity analysis' : 
             context === 'market-map' ? ' neighborhood insights' :
             ' personalized market consultation'}.
          </p>
        </div>

        <div className="bg-white/60 backdrop-blur-sm p-4 rounded-lg border border-green-200">
          <div className="flex items-center justify-center gap-3 text-green-700">
            <Shield className="w-5 h-5" />
            <span className="text-sm font-medium">
              Your information is secure and will never be shared
            </span>
          </div>
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-8 max-w-lg mx-auto interactive-card">
      {/* Header */}
      <div className="text-center mb-8">
        <h3 className="text-2xl font-bold text-[#504f56] mb-3">
          {getContextualHeading()}
        </h3>
        <p className="text-gray-600 leading-relaxed">
          {getContextualSubheading()}
        </p>
      </div>

      {/* Progress Bar */}
      <div className="mb-8">
        <div className="flex items-center justify-between mb-3">
          <span className="text-sm font-medium text-[#504f56]">
            Step {currentStep} of {totalSteps}
          </span>
          <span className="text-sm text-gray-500">
            {Math.round((currentStep / totalSteps) * 100)}% Complete
          </span>
        </div>
        <div className="w-full bg-gray-200 rounded-full h-2">
          <div 
            className="bg-gradient-to-r from-[#a81933] to-[#b8203a] h-2 rounded-full transition-all duration-500 ease-out"
            style={{ width: `${(currentStep / totalSteps) * 100}%` }}
          ></div>
        </div>
      </div>

      {/* Form Steps */}
      <div className="space-y-6">
        {currentStep === 1 && (
          <div className="space-y-4 animate-slide-in-right">
            <div className="text-center mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-[#a81933] to-[#b8203a] rounded-full flex items-center justify-center mx-auto mb-3">
                <User className="w-6 h-6 text-white" />
              </div>
              <h4 className="font-bold text-[#504f56] text-lg">What's your name?</h4>
              <p className="text-gray-600 text-sm">Chris likes to personalize every interaction</p>
            </div>
            
            <div className="space-y-2">
              <label className="block text-sm font-medium text-[#504f56]">
                Full Name *
              </label>
              <input
                type="text"
                value={formData.name || ''}
                onChange={(e) => handleInputChange('name', e.target.value)}
                placeholder="Enter your full name"
                className="w-full p-4 border-2 border-gray-200 rounded-lg focus:border-[#a81933] focus:ring-2 focus:ring-[#a81933]/20 transition-all duration-200 text-lg"
                autoFocus
              />
            </div>
          </div>
        )}

        {currentStep === 2 && (
          <div className="space-y-4 animate-slide-in-right">
            <div className="text-center mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-[#a81933] to-[#b8203a] rounded-full flex items-center justify-center mx-auto mb-3">
                <Mail className="w-6 h-6 text-white" />
              </div>
              <h4 className="font-bold text-[#504f56] text-lg">How can Chris reach you?</h4>
              <p className="text-gray-600 text-sm">For your personalized market insights</p>
            </div>
            
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="block text-sm font-medium text-[#504f56]">
                  Email Address *
                </label>
                <input
                  type="email"
                  value={formData.email || ''}
                  onChange={(e) => handleInputChange('email', e.target.value)}
                  placeholder="your@email.com"
                  className="w-full p-4 border-2 border-gray-200 rounded-lg focus:border-[#a81933] focus:ring-2 focus:ring-[#a81933]/20 transition-all duration-200 text-lg"
                  autoFocus
                />
              </div>
              
              <div className="space-y-2">
                <label className="block text-sm font-medium text-[#504f56]">
                  Phone Number (Optional)
                </label>
                <input
                  type="tel"
                  value={formData.phone || ''}
                  onChange={(e) => handleInputChange('phone', e.target.value)}
                  placeholder="(555) 123-4567"
                  className="w-full p-4 border-2 border-gray-200 rounded-lg focus:border-[#a81933] focus:ring-2 focus:ring-[#a81933]/20 transition-all duration-200 text-lg"
                />
              </div>
            </div>
          </div>
        )}

        {currentStep === 3 && (
          <div className="space-y-4 animate-slide-in-right">
            <div className="text-center mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-[#a81933] to-[#b8203a] rounded-full flex items-center justify-center mx-auto mb-3">
                <Home className="w-6 h-6 text-white" />
              </div>
              <h4 className="font-bold text-[#504f56] text-lg">What interests you most?</h4>
              <p className="text-gray-600 text-sm">This helps Chris prepare the best insights for you</p>
            </div>
            
            <div className="grid gap-3">
              {[
                { value: 'buying-first-home', label: 'Buying my first home', icon: '🏠' },
                { value: 'upgrading', label: 'Upgrading to a larger home', icon: '⬆️' },
                { value: 'downsizing', label: 'Downsizing/Right-sizing', icon: '⬇️' },
                { value: 'selling', label: 'Selling my current home', icon: '💰' },
                { value: 'investment', label: 'Investment property', icon: '📈' },
                { value: 'market-info', label: 'Just learning about the market', icon: '📊' }
              ].map((option) => (
                <button
                  key={option.value}
                  onClick={() => handleInputChange('interest', option.value)}
                  className={`p-4 text-left border-2 rounded-lg transition-all duration-200 ${
                    formData.interest === option.value
                      ? 'border-[#a81933] bg-[#a81933]/5 text-[#a81933]'
                      : 'border-gray-200 hover:border-gray-300 text-gray-700'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-xl">{option.icon}</span>
                    <span className="font-medium">{option.label}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {currentStep === 4 && (
          <div className="space-y-4 animate-slide-in-right">
            <div className="text-center mb-6">
              <div className="w-12 h-12 bg-gradient-to-br from-[#a81933] to-[#b8203a] rounded-full flex items-center justify-center mx-auto mb-3">
                <Clock className="w-6 h-6 text-white" />
              </div>
              <h4 className="font-bold text-[#504f56] text-lg">What's your timeline?</h4>
              <p className="text-gray-600 text-sm">Chris can prioritize the most relevant information</p>
            </div>
            
            <div className="grid gap-3">
              {[
                { value: 'asap', label: 'As soon as possible', icon: '🚀' },
                { value: '1-3-months', label: 'Within 1-3 months', icon: '📅' },
                { value: '3-6-months', label: 'Within 3-6 months', icon: '🗓️' },
                { value: '6-12-months', label: 'Within 6-12 months', icon: '📆' },
                { value: 'exploring', label: 'Just exploring options', icon: '🔍' },
                { value: 'future', label: 'Planning for the future', icon: '🎯' }
              ].map((option) => (
                <button
                  key={option.value}
                  onClick={() => handleInputChange('timeline', option.value)}
                  className={`p-4 text-left border-2 rounded-lg transition-all duration-200 ${
                    formData.timeline === option.value
                      ? 'border-[#a81933] bg-[#a81933]/5 text-[#a81933]'
                      : 'border-gray-200 hover:border-gray-300 text-gray-700'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className="text-xl">{option.icon}</span>
                    <span className="font-medium">{option.label}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Navigation */}
      <div className="flex items-center justify-between mt-8 pt-6 border-t border-gray-200">
        <Button
          onClick={handleBack}
          variant="outline"
          disabled={currentStep === 1}
          className={currentStep === 1 ? 'invisible' : ''}
        >
          Back
        </Button>

        {currentStep < totalSteps ? (
          <Button
            onClick={handleNext}
            disabled={!isStepValid(currentStep)}
            className="bg-gradient-to-r from-[#a81933] to-[#b8203a] hover:from-[#b8203a] hover:to-[#c82d41] text-white"
          >
            <div className="flex items-center gap-2">
              Continue
              <ArrowRight className="w-4 h-4" />
            </div>
          </Button>
        ) : (
          <Button
            onClick={handleSubmit}
            disabled={!isStepValid(currentStep) || isSubmitting}
            className="bg-gradient-to-r from-[#a81933] to-[#b8203a] hover:from-[#b8203a] hover:to-[#c82d41] text-white"
          >
            {isSubmitting ? (
              <div className="flex items-center gap-3">
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                Sending...
              </div>
            ) : (
              'Get My Analysis'
            )}
          </Button>
        )}
      </div>

      {/* Trust Indicators */}
      <div className="mt-6 pt-4 border-t border-gray-200">
        <div className="flex items-center justify-center gap-6 text-sm text-gray-500">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4" />
            <span>Secure & Private</span>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4" />
            <span>24hr Response</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4" />
            <span>No Obligation</span>
          </div>
        </div>
      </div>
    </Card>
  );
}