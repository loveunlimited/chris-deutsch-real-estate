"use client"

import React, { useState, useRef, useEffect } from 'react'
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Play, Pause, MessageCircle, Video, VideoOff, Mic, MicOff, Send, X } from 'lucide-react'
import { cn } from "@/lib/utils"

interface HeyGenAvatarProps {
  className?: string
}

interface ConversationMessage {
  id: string
  type: 'user' | 'avatar'
  content: string
  timestamp: Date
}

const HeyGenAvatar: React.FC<HeyGenAvatarProps> = ({ className }) => {
  const [isConnected, setIsConnected] = useState(false)
  const [isStreaming, setIsStreaming] = useState(false)
  const [isMuted, setIsMuted] = useState(false)
  const [isVideoEnabled, setIsVideoEnabled] = useState(true)
  const [isLoading, setIsLoading] = useState(false)
  const [conversation, setConversation] = useState<ConversationMessage[]>([])
  const [inputMessage, setInputMessage] = useState('')
  const [showChat, setShowChat] = useState(false)
  const [avatarStatus, setAvatarStatus] = useState<'idle' | 'listening' | 'speaking' | 'thinking'>('idle')
  
  const videoRef = useRef<HTMLVideoElement>(null)
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const peerConnectionRef = useRef<RTCPeerConnection | null>(null)

  // HeyGen Avatar Integration
  useEffect(() => {
    initializeHeyGenSDK()
    return () => {
      cleanup()
    }
  }, [])

  const initializeHeyGenSDK = async () => {
    try {
      // Initialize HeyGen Streaming SDK
      // This would connect to your HeyGen API
      console.log('Initializing HeyGen Avatar...')
      
      // Simulated initialization - replace with actual HeyGen SDK
      setTimeout(() => {
        setIsConnected(true)
        addSystemMessage("Hi! I'm Chris Deutsch, your Twin Cities real estate expert with 25 years of experience. How can I help you find your dream home today?")
      }, 2000)
      
    } catch (error) {
      console.error('Failed to initialize HeyGen:', error)
    }
  }

  const startAvatarStream = async () => {
    setIsLoading(true)
    try {
      // Start HeyGen streaming session
      await initializeWebRTC()
      setIsStreaming(true)
      setAvatarStatus('listening')
    } catch (error) {
      console.error('Failed to start avatar stream:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const stopAvatarStream = () => {
    setIsStreaming(false)
    setAvatarStatus('idle')
    cleanup()
  }

  const initializeWebRTC = async () => {
    try {
      // Setup WebRTC connection for HeyGen streaming
      const peerConnection = new RTCPeerConnection({
        iceServers: [{ urls: 'stun:stun.l.google.com:19302' }]
      })
      
      peerConnectionRef.current = peerConnection
      
      // Add event listeners
      peerConnection.onicecandidate = (event) => {
        if (event.candidate) {
          // Send ICE candidate to HeyGen
          console.log('ICE candidate:', event.candidate)
        }
      }
      
      peerConnection.ontrack = (event) => {
        if (videoRef.current && event.streams[0]) {
          videoRef.current.srcObject = event.streams[0]
        }
      }
      
      // Get user media for microphone
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      streamRef.current = stream
      
      stream.getTracks().forEach(track => {
        peerConnection.addTrack(track, stream)
      })
      
    } catch (error) {
      console.error('WebRTC initialization failed:', error)
      throw error
    }
  }

  const sendMessage = async (message: string) => {
    if (!message.trim() || !isConnected) return

    // Add user message to conversation
    const userMessage: ConversationMessage = {
      id: Date.now().toString(),
      type: 'user',
      content: message,
      timestamp: new Date()
    }
    
    setConversation(prev => [...prev, userMessage])
    setInputMessage('')
    setAvatarStatus('thinking')

    try {
      // Send message to HeyGen avatar
      const response = await processUserMessage(message)
      
      // Add avatar response
      const avatarMessage: ConversationMessage = {
        id: (Date.now() + 1).toString(),
        type: 'avatar',
        content: response,
        timestamp: new Date()
      }
      
      setConversation(prev => [...prev, avatarMessage])
      setAvatarStatus('speaking')
      
      // Simulate avatar speaking
      setTimeout(() => {
        setAvatarStatus('listening')
      }, response.length * 50) // Approximate speaking time
      
    } catch (error) {
      console.error('Failed to send message:', error)
      setAvatarStatus('listening')
    }
  }

  const processUserMessage = async (message: string): Promise<string> => {
    // Real estate conversation flow logic
    const lowerMessage = message.toLowerCase()
    
    if (lowerMessage.includes('golden valley') || lowerMessage.includes('bryn mawr')) {
      return "Excellent choice! Golden Valley and Bryn Mawr are two of my specialty neighborhoods. Golden Valley offers exceptional suburban living with top-rated schools and beautiful tree-lined streets, while Bryn Mawr provides that charming, tight-knit community feel right in Minneapolis. Both areas have seen strong appreciation in recent years. What type of home are you looking for in these areas?"
    }
    
    if (lowerMessage.includes('market') || lowerMessage.includes('price')) {
      return "The Twin Cities market is performing very well right now! We're seeing a median home price around $425,000, with homes selling in about 18 days on average. There's still strong buyer demand, and we're seeing a healthy 98.2% sale-to-list ratio. It's actually a great time for both buyers and sellers. Are you looking to buy, sell, or both?"
    }
    
    if (lowerMessage.includes('stress') || lowerMessage.includes('process')) {
      return "That's exactly why I've focused on creating a stress-free experience for my clients over the past 25 years. I handle all the details, coordinate with inspectors, lenders, and attorneys, and keep you informed every step of the way. My goal is to make your real estate transaction as smooth as possible. What concerns do you have about the process?"
    }
    
    if (lowerMessage.includes('home') || lowerMessage.includes('house') || lowerMessage.includes('property')) {
      return "I'd love to help you find your perfect home! With 25 years in the Twin Cities market, I've helped hundreds of families find exactly what they're looking for. Are you interested in a specific neighborhood, price range, or type of home? I can show you some great options that match your needs."
    }
    
    if (lowerMessage.includes('sell') || lowerMessage.includes('selling')) {
      return "Selling your home can be exciting! I provide a comprehensive marketing strategy that includes professional photography, online exposure across all major platforms, and my extensive network of buyers. I'll also provide you with a detailed market analysis to price your home competitively. When are you thinking of putting your home on the market?"
    }
    
    // Default response
    return "Thank you for reaching out! As your Twin Cities real estate expert with 25 years of experience, I'm here to help with all your real estate needs. Whether you're buying, selling, or just have questions about the market, I'm committed to providing you with exceptional, stress-free service. What specific questions can I answer for you today?"
  }

  const addSystemMessage = (content: string) => {
    const systemMessage: ConversationMessage = {
      id: Date.now().toString(),
      type: 'avatar',
      content,
      timestamp: new Date()
    }
    setConversation(prev => [...prev, systemMessage])
  }

  const cleanup = () => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop())
      streamRef.current = null
    }
    
    if (peerConnectionRef.current) {
      peerConnectionRef.current.close()
      peerConnectionRef.current = null
    }
  }

  const getStatusColor = () => {
    switch (avatarStatus) {
      case 'listening': return 'bg-green-500'
      case 'speaking': return 'bg-blue-500'
      case 'thinking': return 'bg-yellow-500'
      default: return 'bg-gray-400'
    }
  }

  const getStatusText = () => {
    switch (avatarStatus) {
      case 'listening': return 'Listening'
      case 'speaking': return 'Speaking'
      case 'thinking': return 'Thinking'
      default: return 'Ready'
    }
  }

  return (
    <div className={cn("w-full max-w-6xl mx-auto", className)}>
      <Card className="bg-gradient-to-br from-white via-[#f8f8f9] to-[#f0f0f2] border-2 border-[#b7b7bd]/30 shadow-2xl">
        <CardContent className="p-0">
          {/* Header */}
          <div className="bg-gradient-to-r from-[#a81933] to-[#b8203a] p-6 text-white">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="relative">
                  <div className={cn("w-4 h-4 rounded-full animate-pulse", getStatusColor())}></div>
                </div>
                <div>
                  <h2 className="text-2xl font-serif font-bold">Chat with Chris Deutsch</h2>
                  <p className="text-white/90 font-medium">Your 25-Year Twin Cities Expert</p>
                  <Badge variant="secondary" className="mt-2 bg-white/20 text-white border-white/30">
                    {getStatusText()}
                  </Badge>
                </div>
              </div>
              
              <div className="flex items-center space-x-2">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => setShowChat(!showChat)}
                  className="text-white hover:bg-white/20"
                >
                  <MessageCircle className="w-5 h-5" />
                </Button>
                
                {isStreaming && (
                  <>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setIsMuted(!isMuted)}
                      className="text-white hover:bg-white/20"
                    >
                      {isMuted ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
                    </Button>
                    
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setIsVideoEnabled(!isVideoEnabled)}
                      className="text-white hover:bg-white/20"
                    >
                      {isVideoEnabled ? <Video className="w-5 h-5" /> : <VideoOff className="w-5 h-5" />}
                    </Button>
                  </>
                )}
              </div>
            </div>
          </div>

          <div className="grid lg:grid-cols-3 gap-6 p-6">
            {/* Video Avatar */}
            <div className="lg:col-span-2">
              <div className="relative aspect-video bg-gradient-to-br from-[#161019] to-[#504f56] rounded-xl overflow-hidden shadow-2xl">
                {isStreaming ? (
                  <video
                    ref={videoRef}
                    autoPlay
                    muted={isMuted}
                    className="w-full h-full object-cover"
                    style={{ display: isVideoEnabled ? 'block' : 'none' }}
                  />
                ) : (
                  <div className="flex items-center justify-center h-full text-white">
                    <div className="text-center space-y-4">
                      <div className="w-24 h-24 bg-gradient-to-br from-[#ffd42f] to-[#ffab00] rounded-full mx-auto flex items-center justify-center shadow-lg">
                        <div className="text-[#161019] text-4xl font-bold">CD</div>
                      </div>
                      <div>
                        <h3 className="text-xl font-serif font-bold mb-2">Chris Deutsch</h3>
                        <p className="text-white/80 mb-4">Ready to help with your real estate needs</p>
                        
                        {!isConnected ? (
                          <div className="text-white/60">Connecting...</div>
                        ) : (
                          <Button
                            onClick={startAvatarStream}
                            disabled={isLoading}
                            className="bg-gradient-to-r from-[#ffd42f] to-[#ffab00] text-[#161019] font-bold hover:shadow-lg"
                          >
                            {isLoading ? (
                              <div className="animate-spin w-5 h-5 border-2 border-[#161019] border-t-transparent rounded-full" />
                            ) : (
                              <>
                                <Play className="w-5 h-5 mr-2" />
                                Start Conversation
                              </>
                            )}
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                )}
                
                {/* Canvas for effects */}
                <canvas
                  ref={canvasRef}
                  className="absolute inset-0 pointer-events-none"
                  style={{ display: isStreaming ? 'block' : 'none' }}
                />
                
                {/* Controls Overlay */}
                {isStreaming && (
                  <div className="absolute bottom-4 left-4 right-4 flex justify-center space-x-4">
                    <Button
                      onClick={stopAvatarStream}
                      variant="destructive"
                      size="sm"
                      className="bg-red-600 hover:bg-red-700"
                    >
                      <X className="w-4 h-4 mr-2" />
                      End Session
                    </Button>
                  </div>
                )}
              </div>

              {/* Quick Actions */}
              <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 mt-4">
                <Button
                  variant="outline"
                  onClick={() => sendMessage("Tell me about Golden Valley homes")}
                  className="text-sm h-auto py-3 px-4 border-[#a81933]/20 hover:bg-[#a81933]/5"
                  disabled={!isConnected}
                >
                  Golden Valley Homes
                </Button>
                <Button
                  variant="outline"
                  onClick={() => sendMessage("What's the current market like?")}
                  className="text-sm h-auto py-3 px-4 border-[#a81933]/20 hover:bg-[#a81933]/5"
                  disabled={!isConnected}
                >
                  Market Update
                </Button>
                <Button
                  variant="outline"
                  onClick={() => sendMessage("How do you make selling stress-free?")}
                  className="text-sm h-auto py-3 px-4 border-[#a81933]/20 hover:bg-[#a81933]/5"
                  disabled={!isConnected}
                >
                  Stress-Free Process
                </Button>
                <Button
                  variant="outline"
                  onClick={() => sendMessage("I want to schedule a consultation")}
                  className="text-sm h-auto py-3 px-4 border-[#a81933]/20 hover:bg-[#a81933]/5"
                  disabled={!isConnected}
                >
                  Get Started
                </Button>
              </div>
            </div>

            {/* Chat Panel */}
            <div className={cn("lg:col-span-1", !showChat && "lg:hidden")}>
              <div className="bg-white border border-[#b7b7bd]/30 rounded-xl shadow-lg h-[500px] flex flex-col">
                <div className="p-4 border-b border-[#b7b7bd]/30">
                  <h3 className="font-semibold text-[#504f56]">Conversation</h3>
                </div>
                
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                  {conversation.map((message) => (
                    <div
                      key={message.id}
                      className={cn(
                        "max-w-[80%] p-3 rounded-lg",
                        message.type === 'user'
                          ? "ml-auto bg-[#a81933] text-white"
                          : "bg-[#f8f8f9] text-[#504f56]"
                      )}
                    >
                      <p className="text-sm">{message.content}</p>
                      <div className="text-xs opacity-70 mt-1">
                        {message.timestamp.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>
                  ))}
                </div>
                
                <div className="p-4 border-t border-[#b7b7bd]/30">
                  <div className="flex space-x-2">
                    <input
                      type="text"
                      value={inputMessage}
                      onChange={(e) => setInputMessage(e.target.value)}
                      onKeyPress={(e) => e.key === 'Enter' && sendMessage(inputMessage)}
                      placeholder="Type your message..."
                      className="flex-1 px-3 py-2 border border-[#b7b7bd]/30 rounded-lg focus:outline-none focus:ring-2 focus:ring-[#a81933]/20"
                      disabled={!isConnected}
                    />
                    <Button
                      onClick={() => sendMessage(inputMessage)}
                      disabled={!inputMessage.trim() || !isConnected}
                      size="sm"
                      className="bg-[#a81933] hover:bg-[#b8203a]"
                    >
                      <Send className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

export default HeyGenAvatar