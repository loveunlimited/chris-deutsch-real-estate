'use client';

import { useState } from 'react';
import { Button } from './button';

interface VoicePlayerProps {
  text: string;
  voiceType?: 'market-update' | 'property-description' | 'personal-message';
  className?: string;
}

export default function VoicePlayer({ text, voiceType = 'market-update', className }: VoicePlayerProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  const generateVoice = async () => {
    setIsLoading(true);
    try {
      const response = await fetch('/api/voice', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ text, voiceType }),
      });

      if (response.ok) {
        const audioBlob = await response.blob();
        const url = URL.createObjectURL(audioBlob);
        setAudioUrl(url);
      } else {
        console.error('Voice generation failed');
      }
    } catch (error) {
      console.error('Error generating voice:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const playAudio = () => {
    if (audioUrl) {
      const audio = new Audio(audioUrl);
      audio.play();
      setIsPlaying(true);
      audio.onended = () => setIsPlaying(false);
    }
  };

  return (
    <div className={`flex gap-2 items-center ${className}`}>
      {!audioUrl ? (
        <Button 
          onClick={generateVoice} 
          disabled={isLoading}
          variant="outline"
          size="sm"
        >
          {isLoading ? '🎤 Generating...' : '🎤 Generate Voice'}
        </Button>
      ) : (
        <Button 
          onClick={playAudio} 
          disabled={isPlaying}
          variant="default"
          size="sm"
        >
          {isPlaying ? '⏸️ Playing...' : '▶️ Play Voice'}
        </Button>
      )}
      
      {audioUrl && (
        <Button 
          onClick={() => {
            URL.revokeObjectURL(audioUrl);
            setAudioUrl(null);
            setIsPlaying(false);
          }}
          variant="ghost"
          size="sm"
        >
          🔄 Regenerate
        </Button>
      )}
    </div>
  );
}