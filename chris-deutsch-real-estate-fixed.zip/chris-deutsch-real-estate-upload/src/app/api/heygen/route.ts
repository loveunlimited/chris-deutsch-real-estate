/**
 * HEYGEN VIDEO GENERATION API ENDPOINT
 * Budget-conscious avatar video creation
 */

import { NextRequest, NextResponse } from 'next/server';
import { createHeyGenVideoService } from '@/lib/heygen-video-service';

export async function POST(request: NextRequest) {
  try {
    const { script, title, background, priority, voice_settings, video_settings } = await request.json();
    
    if (!script || !title) {
      return NextResponse.json(
        { error: 'Script and title are required' }, 
        { status: 400 }
      );
    }

    if (script.length > 2000) {
      return NextResponse.json(
        { error: 'Script too long. Maximum 2000 characters for cost efficiency.' }, 
        { status: 400 }
      );
    }

    console.log('🎬 API: Starting video generation...');
    console.log('📝 Title:', title);
    console.log('📏 Script length:', script.length, 'characters');

    const heygenService = createHeyGenVideoService();
    
    // Check current usage before proceeding
    const usage = await heygenService.getUsageStats();
    console.log('💰 Current budget remaining:', `$${usage.remainingBudget.toFixed(2)}`);
    
    const videoRequest = {
      script,
      title,
      background: background || 'real_estate_office',
      priority: priority || 'medium',
      voice_settings: {
        speed: 1.05, // Chris's optimized speed
        emotion: voice_settings?.emotion || 'professional',
        ...voice_settings
      },
      video_settings: {
        resolution: video_settings?.resolution || '720p',
        aspect_ratio: video_settings?.aspect_ratio || '16:9',
        ...video_settings
      }
    };

    const result = await heygenService.generateVideo(videoRequest);
    
    if (result.status === 'error') {
      return NextResponse.json(
        { error: result.error }, 
        { status: 500 }
      );
    }

    // Return success response with tracking info
    return NextResponse.json({
      success: true,
      videoId: result.videoId,
      status: result.status,
      estimatedCost: result.estimatedCost,
      createdAt: result.createdAt,
      usage: {
        videosGenerated: usage.videosGenerated + 1,
        remainingBudget: usage.remainingBudget - (result.estimatedCost || 0),
        videoLimit: parseInt(process.env.HEYGEN_VIDEO_LIMIT || '10')
      },
      message: 'Video generation started successfully'
    });

  } catch (error) {
    console.error('❌ HeyGen API error:', error);
    
    return NextResponse.json(
      { 
        error: 'Video generation failed', 
        details: error.message 
      }, 
      { status: 500 }
    );
  }
}

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const videoId = searchParams.get('videoId');
    const action = searchParams.get('action');

    const heygenService = createHeyGenVideoService();

    if (action === 'usage') {
      // Return current usage statistics
      const usage = await heygenService.getUsageStats();
      return NextResponse.json({
        usage,
        limits: {
          monthlyBudget: parseInt(process.env.HEYGEN_MONTHLY_BUDGET || '40'),
          videoLimit: parseInt(process.env.HEYGEN_VIDEO_LIMIT || '10')
        }
      });
    }

    if (action === 'avatars') {
      // List available avatars
      const avatars = await heygenService.listAvatars();
      return NextResponse.json({ avatars });
    }

    if (videoId) {
      // Check specific video status
      const status = await heygenService.checkVideoStatus(videoId);
      return NextResponse.json({ video: status });
    }

    return NextResponse.json(
      { error: 'Missing required parameters' }, 
      { status: 400 }
    );

  } catch (error) {
    console.error('❌ HeyGen GET API error:', error);
    
    return NextResponse.json(
      { 
        error: 'Request failed', 
        details: error.message 
      }, 
      { status: 500 }
    );
  }
}