/**
 * HEYGEN AVATAR VIDEO GENERATION SERVICE
 * Cost-efficient video generation with budget monitoring
 * Updated for pre-recorded avatar videos, not streaming
 */

export interface HeyGenConfig {
  apiKey: string
  monthlyBudget: number
  videoLimit: number
  avatarId?: string
  baseUrl?: string
}

export interface StreamingSession {
  sessionId: string
  peerConnection: RTCPeerConnection
  localStream?: MediaStream
  remoteStream?: MediaStream
  status: 'connecting' | 'connected' | 'speaking' | 'listening' | 'disconnected'
}

export interface ConversationContext {
  propertySearchData?: any
  userPreferences?: {
    neighborhoods?: string[]
    priceRange?: [number, number]
    propertyType?: string
  }
  leadInfo?: {
    name?: string
    email?: string
    phone?: string
    timeline?: string
  }
}

class HeyGenService {
  private config: HeyGenConfig
  private session: StreamingSession | null = null
  private conversationContext: ConversationContext = {}

  constructor(config: HeyGenConfig) {
    this.config = {
      baseUrl: 'https://api.heygen.com/v1',
      ...config
    }
  }

  // Initialize streaming session
  async createSession(): Promise<StreamingSession> {
    try {
      const response = await fetch(`${this.config.baseUrl}/streaming/create_session`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-API-KEY': this.config.apiKey
        },
        body: JSON.stringify({
          avatar_id: this.config.avatarId,
          voice_id: this.config.voiceId,
          // Real estate specific settings
          avatar_settings: {
            background: 'office', // Professional office background
            lighting: 'natural',
            quality: 'high'
          },
          conversation_settings: {
            domain: 'real_estate',
            personality: 'professional_friendly',
            expertise_areas: ['twin_cities_market', 'golden_valley', 'bryn_mawr']
          }
        })
      })

      if (!response.ok) {
        throw new Error(`Failed to create session: ${response.statusText}`)
      }

      const sessionData = await response.json()
      
      // Initialize WebRTC connection
      const peerConnection = await this.setupWebRTC(sessionData.session_id)
      
      this.session = {
        sessionId: sessionData.session_id,
        peerConnection,
        status: 'connecting'
      }

      return this.session
    } catch (error) {
      console.error('Failed to create HeyGen session:', error)
      throw error
    }
  }

  // Setup WebRTC for real-time streaming
  private async setupWebRTC(sessionId: string): Promise<RTCPeerConnection> {
    const peerConnection = new RTCPeerConnection({
      iceServers: [
        { urls: 'stun:stun.l.google.com:19302' },
        { urls: 'stun:stun1.l.google.com:19302' }
      ]
    })

    // Handle ICE candidates
    peerConnection.onicecandidate = async (event) => {
      if (event.candidate) {
        await this.sendIceCandidate(sessionId, event.candidate)
      }
    }

    // Handle incoming video stream
    peerConnection.ontrack = (event) => {
      if (this.session) {
        this.session.remoteStream = event.streams[0]
        this.session.status = 'connected'
      }
    }

    // Handle connection state changes
    peerConnection.onconnectionstatechange = () => {
      if (this.session) {
        switch (peerConnection.connectionState) {
          case 'connected':
            this.session.status = 'connected'
            break
          case 'disconnected':
          case 'failed':
          case 'closed':
            this.session.status = 'disconnected'
            break
        }
      }
    }

    // Get user media (microphone)
    try {
      const localStream = await navigator.mediaDevices.getUserMedia({ 
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true
        } 
      })
      
      if (this.session) {
        this.session.localStream = localStream
      }

      localStream.getTracks().forEach(track => {
        peerConnection.addTrack(track, localStream)
      })
    } catch (error) {
      console.warn('Could not access microphone:', error)
    }

    // Create offer and set local description
    const offer = await peerConnection.createOffer()
    await peerConnection.setLocalDescription(offer)

    // Send offer to HeyGen
    await this.sendOffer(sessionId, offer)

    return peerConnection
  }

  // Send WebRTC offer to HeyGen
  private async sendOffer(sessionId: string, offer: RTCSessionDescriptionInit): Promise<void> {
    const response = await fetch(`${this.config.baseUrl}/streaming/webrtc/offer`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-API-KEY': this.config.apiKey
      },
      body: JSON.stringify({
        session_id: sessionId,
        offer: offer
      })
    })

    if (!response.ok) {
      throw new Error(`Failed to send offer: ${response.statusText}`)
    }

    const { answer } = await response.json()
    
    if (this.session) {
      await this.session.peerConnection.setRemoteDescription(answer)
    }
  }

  // Send ICE candidate to HeyGen
  private async sendIceCandidate(sessionId: string, candidate: RTCIceCandidate): Promise<void> {
    await fetch(`${this.config.baseUrl}/streaming/webrtc/ice`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-API-KEY': this.config.apiKey
      },
      body: JSON.stringify({
        session_id: sessionId,
        candidate: candidate
      })
    })
  }

  // Send message to avatar with real estate context
  async sendMessage(message: string, context?: Partial<ConversationContext>): Promise<void> {
    if (!this.session) {
      throw new Error('No active session')
    }

    // Update conversation context
    this.conversationContext = { ...this.conversationContext, ...context }

    // Process message with real estate intelligence
    const enhancedMessage = await this.enhanceMessageWithContext(message)

    const response = await fetch(`${this.config.baseUrl}/streaming/send_message`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-API-KEY': this.config.apiKey
      },
      body: JSON.stringify({
        session_id: this.session.sessionId,
        text: enhancedMessage,
        context: {
          speaker_role: 'client',
          conversation_context: this.conversationContext,
          real_estate_data: await this.getRealEstateContext(message)
        }
      })
    })

    if (!response.ok) {
      throw new Error(`Failed to send message: ${response.statusText}`)
    }

    if (this.session) {
      this.session.status = 'speaking'
    }
  }

  // Enhance message with real estate context
  private async enhanceMessageWithContext(message: string): Promise<string> {
    const lowerMessage = message.toLowerCase()
    
    // Add context for neighborhood-specific questions
    if (lowerMessage.includes('golden valley') || lowerMessage.includes('bryn mawr')) {
      return `${message}\n\nContext: User is asking about Chris's specialty neighborhoods where he has 25 years of expertise.`
    }
    
    // Add market context
    if (lowerMessage.includes('market') || lowerMessage.includes('price')) {
      return `${message}\n\nContext: Current Twin Cities market data - median $425K, 18 days average, 98.2% sale-to-list ratio.`
    }
    
    return message
  }

  // Get relevant real estate context
  private async getRealEstateContext(message: string) {
    const context: any = {
      agent_expertise: {
        years_experience: 25,
        specialty_areas: ['Golden Valley', 'Bryn Mawr', 'Twin Cities'],
        approach: 'stress-free',
        credentials: ['REALTOR®', 'NAR', 'MNAR', 'Northstar MLS']
      },
      current_market: {
        median_price: 425000,
        days_on_market: 18,
        sale_to_list_ratio: 98.2,
        year_over_year_growth: 12.3
      }
    }

    // Add property-specific context if user is asking about properties
    if (this.conversationContext.propertySearchData) {
      context.relevant_properties = this.conversationContext.propertySearchData
    }

    return context
  }

  // Generate property-specific introduction
  async generatePropertyIntroduction(propertyData: any): Promise<void> {
    if (!this.session) {
      throw new Error('No active session')
    }

    const propertyScript = this.createPropertyScript(propertyData)
    
    await this.sendMessage(propertyScript, {
      propertySearchData: propertyData
    })
  }

  // Create property-specific script
  private createPropertyScript(property: any): string {
    const scripts = {
      golden_valley: `Let me tell you about this exceptional Golden Valley property. With my 25 years of expertise in this neighborhood, I can tell you this ${property.bedrooms}-bedroom, ${property.bathrooms}-bathroom home at ${property.address} represents outstanding value at $${property.price.toLocaleString()}. Golden Valley's tree-lined streets, top-rated schools, and convenient access to Minneapolis make it perfect for families. This ${property.sqft}-square-foot home offers ${property.highlights?.join(', ')}. Would you like to schedule a private showing?`,
      
      bryn_mawr: `I'm excited to share this wonderful Bryn Mawr property with you. This charming neighborhood is one of my specialties, and this ${property.bedrooms}-bedroom, ${property.bathrooms}-bathroom home perfectly captures that unique Bryn Mawr character. At $${property.price.toLocaleString()}, this ${property.sqft}-square-foot home features ${property.highlights?.join(', ')}. The community's walkability and proximity to downtown while maintaining that peaceful residential feel makes it truly special. Shall we arrange a tour?`,
      
      default: `Here's an exceptional property I'd love to show you. This ${property.bedrooms}-bedroom, ${property.bathrooms}-bathroom home is listed at $${property.price.toLocaleString()} and offers ${property.sqft} square feet of beautifully designed living space. Located in ${property.neighborhood}, it features ${property.highlights?.join(', ')}. With my 25 years of Twin Cities experience, I can guide you through every detail of this opportunity. When would be a good time for a showing?`
    }

    const neighborhood = property.neighborhood?.toLowerCase().replace(/\s+/g, '_')
    return scripts[neighborhood as keyof typeof scripts] || scripts.default
  }

  // Connect to lead capture
  async captureLeadFromConversation(leadData: any): Promise<void> {
    this.conversationContext.leadInfo = leadData
    
    // Send lead data to CRM
    await fetch('/api/leads', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        ...leadData,
        source: 'heygen_avatar',
        conversation_context: this.conversationContext,
        timestamp: new Date().toISOString()
      })
    })
  }

  // Get session status
  getSessionStatus(): string {
    return this.session?.status || 'disconnected'
  }

  // End session
  async endSession(): Promise<void> {
    if (!this.session) return

    try {
      // Close WebRTC connection
      if (this.session.localStream) {
        this.session.localStream.getTracks().forEach(track => track.stop())
      }
      
      this.session.peerConnection.close()

      // End HeyGen session
      await fetch(`${this.config.baseUrl}/streaming/end_session`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-API-KEY': this.config.apiKey
        },
        body: JSON.stringify({
          session_id: this.session.sessionId
        })
      })
    } catch (error) {
      console.error('Error ending session:', error)
    } finally {
      this.session = null
      this.conversationContext = {}
    }
  }
}

// Real Estate Conversation Templates
export const REAL_ESTATE_PROMPTS = {
  welcome: "Hi! I'm Chris Deutsch, your Twin Cities real estate expert with 25 years of experience. I specialize in Golden Valley and Bryn Mawr, and I'm committed to making your real estate journey completely stress-free. How can I help you find your dream home today?",
  
  golden_valley_expert: "Golden Valley is one of my specialty areas! I've been helping families find their perfect homes here for over two decades. The community offers exceptional suburban living with top-rated schools, beautiful tree-lined streets, and convenient access to Minneapolis. What type of home are you looking for in Golden Valley?",
  
  bryn_mawr_specialist: "Bryn Mawr is such a unique neighborhood! It's a hidden gem with incredible character and charm. I love helping clients discover this tight-knit community with its beautiful craftsman homes and the scenic Bryn Mawr Meadows. The location gives you that peaceful residential feel while being so close to downtown. Are you interested in learning more about available properties?",
  
  market_insights: "The Twin Cities market is performing very well right now! We're seeing strong buyer demand with a median home price around $425,000. Homes are selling in about 18 days on average, and we have a healthy 98.2% sale-to-list ratio. With my 25 years of market experience, I can help you navigate these conditions successfully. Are you looking to buy or sell?",
  
  stress_free_process: "That's exactly why I've built my business around providing a completely stress-free experience. Over 25 years, I've refined my process to handle all the details - coordinating with inspectors, lenders, attorneys, and keeping you informed every step of the way. My goal is to make your real estate transaction as smooth as possible. What specific concerns do you have about the process?"
}

export default HeyGenService