/**
 * HEYGEN AVATAR VIDEO GENERATION SERVICE
 * Cost-efficient pre-recorded video generation with budget monitoring
 * For Chris Deutsch Real Estate
 */

interface HeyGenConfig {
  apiKey: string;
  monthlyBudget: number;
  videoLimit: number;
  avatarId?: string;
}

interface VideoGenerationRequest {
  script: string;
  title: string;
  background?: 'office' | 'modern' | 'luxury' | 'neutral' | 'real_estate_office';
  priority?: 'high' | 'medium' | 'low';
  voice_settings?: {
    speed?: number;
    emotion?: 'neutral' | 'friendly' | 'excited' | 'professional';
  };
  video_settings?: {
    resolution?: '720p' | '1080p';
    aspect_ratio?: '16:9' | '9:16' | '1:1';
  };
}

interface VideoGenerationResponse {
  videoId: string;
  status: 'pending' | 'processing' | 'completed' | 'failed' | 'error';
  downloadUrl?: string;
  duration?: number;
  estimatedCost?: number;
  createdAt: string;
  error?: string;
}

interface UsageStats {
  videosGenerated: number;
  totalCost: number;
  remainingBudget: number;
  monthlyReset: string;
  lastGenerated?: string;
}

export class HeyGenVideoService {
  private config: HeyGenConfig;
  private baseUrl = 'https://api.heygen.com/v2';
  private usageFile = './heygen-usage.json';

  constructor(config: HeyGenConfig) {
    this.config = config;
  }

  /**
   * Generate avatar video with comprehensive cost monitoring
   */
  async generateVideo(request: VideoGenerationRequest): Promise<VideoGenerationResponse> {
    console.log('🎬 Starting HeyGen video generation...');
    console.log('📝 Title:', request.title);
    console.log('📏 Script length:', request.script.length, 'characters');

    // Pre-flight budget checks
    const usage = await this.getUsageStats();
    
    if (usage.videosGenerated >= this.config.videoLimit) {
      throw new Error(`❌ Monthly video limit reached (${this.config.videoLimit}/${this.config.videoLimit})`);
    }
    
    if (usage.remainingBudget <= 0) {
      throw new Error(`❌ Monthly budget exceeded ($${this.config.monthlyBudget})`);
    }

    console.log('💰 Budget remaining:', `$${usage.remainingBudget.toFixed(2)}`);
    console.log('📹 Videos remaining:', this.config.videoLimit - usage.videosGenerated);

    try {
      // Optimize video settings for cost efficiency
      const optimizedSettings = this.optimizeVideoSettings(request);
      
      // Prepare HeyGen API payload
      const payload = {
        video_inputs: [{
          character: {
            type: "avatar",
            avatar_id: this.config.avatarId || "default",
            avatar_style: "normal"
          },
          voice: {
            type: "text",
            input_text: request.script,
            voice_id: "default", // Will use your recorded voice
            speed: request.voice_settings?.speed || 1.05,
            emotion: request.voice_settings?.emotion || "professional"
          },
          background: {
            type: request.background || "real_estate_office",
            background_id: "default"
          }
        }],
        test: false, // Production videos
        caption: false,
        title: request.title,
        callback_id: `chris-deutsch-${Date.now()}`,
        aspect_ratio: optimizedSettings.aspect_ratio,
        resolution: optimizedSettings.resolution
      };

      console.log('🚀 Sending request to HeyGen API...');
      
      const response = await fetch(`${this.baseUrl}/video/generate`, {
        method: 'POST',
        headers: {
          'X-API-KEY': this.config.apiKey,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error('❌ HeyGen API Error:', errorText);
        
        return {
          videoId: '',
          status: 'error',
          error: `API Error: ${response.status} - ${errorText}`,
          createdAt: new Date().toISOString()
        };
      }

      const result = await response.json();
      
      // Estimate cost based on video length (rough calculation)
      const estimatedCost = this.estimateVideoCost(request.script.length);
      
      // Update usage tracking
      await this.updateUsage(result.video_id, estimatedCost);
      
      console.log('✅ Video generation initiated successfully!');
      console.log('🆔 Video ID:', result.video_id);
      console.log('💲 Estimated cost:', `$${estimatedCost.toFixed(2)}`);
      
      return {
        videoId: result.video_id,
        status: 'pending',
        estimatedCost: estimatedCost,
        createdAt: new Date().toISOString()
      };

    } catch (error) {
      console.error('❌ Video generation failed:', error);
      
      return {
        videoId: '',
        status: 'error',
        error: error.message,
        createdAt: new Date().toISOString()
      };
    }
  }

  /**
   * Check video generation status and download when ready
   */
  async checkVideoStatus(videoId: string): Promise<VideoGenerationResponse> {
    try {
      console.log('🔍 Checking video status for:', videoId);
      
      const response = await fetch(`${this.baseUrl}/video/${videoId}`, {
        headers: {
          'X-API-KEY': this.config.apiKey
        }
      });

      if (!response.ok) {
        throw new Error(`Status check failed: ${response.statusText}`);
      }

      const result = await response.json();
      
      const status: VideoGenerationResponse = {
        videoId: videoId,
        status: result.status,
        downloadUrl: result.video_url,
        duration: result.duration,
        createdAt: result.created_at || new Date().toISOString()
      };

      // Log status updates
      switch (result.status) {
        case 'completed':
          console.log('✅ Video completed!');
          console.log('📹 Download URL:', result.video_url);
          console.log('⏱️ Duration:', result.duration, 'seconds');
          break;
        case 'processing':
          console.log('⏳ Video still processing...');
          break;
        case 'failed':
          console.log('❌ Video generation failed');
          status.error = result.error || 'Generation failed';
          break;
      }

      return status;

    } catch (error) {
      console.error('❌ Status check error:', error);
      
      return {
        videoId: videoId,
        status: 'error',
        error: error.message,
        createdAt: new Date().toISOString()
      };
    }
  }

  /**
   * Wait for video completion with polling
   */
  async waitForVideoCompletion(videoId: string, timeoutMinutes: number = 10): Promise<VideoGenerationResponse> {
    const maxAttempts = timeoutMinutes * 6; // Check every 10 seconds
    let attempts = 0;

    console.log(`⏳ Waiting for video completion (timeout: ${timeoutMinutes} minutes)...`);

    while (attempts < maxAttempts) {
      const status = await this.checkVideoStatus(videoId);
      
      if (status.status === 'completed') {
        console.log('🎉 Video generation completed successfully!');
        return status;
      }
      
      if (status.status === 'failed' || status.status === 'error') {
        console.log('❌ Video generation failed');
        return status;
      }
      
      // Wait 10 seconds before next check
      await new Promise(resolve => setTimeout(resolve, 10000));
      attempts++;
      
      if (attempts % 6 === 0) { // Every minute
        console.log(`⏳ Still waiting... (${Math.floor(attempts / 6)}/${timeoutMinutes} minutes)`);
      }
    }

    console.log('⏰ Video generation timed out');
    return {
      videoId: videoId,
      status: 'error',
      error: 'Generation timed out',
      createdAt: new Date().toISOString()
    };
  }

  /**
   * Get current usage statistics with detailed breakdown
   */
  async getUsageStats(): Promise<UsageStats> {
    try {
      const fs = require('fs').promises;
      let usage = { 
        videosGenerated: 0, 
        totalCost: 0, 
        monthlyReset: '',
        lastGenerated: ''
      };
      
      try {
        const data = await fs.readFile(this.usageFile, 'utf8');
        usage = JSON.parse(data);
      } catch {
        // Usage file doesn't exist yet - first time use
        console.log('📊 Initializing usage tracking...');
      }

      // Check if monthly reset is needed
      const now = new Date();
      const resetDate = new Date(usage.monthlyReset || now);
      
      if (now.getMonth() !== resetDate.getMonth() || now.getFullYear() !== resetDate.getFullYear()) {
        console.log('🔄 Monthly usage reset triggered');
        
        usage = {
          videosGenerated: 0,
          totalCost: 0,
          monthlyReset: new Date(now.getFullYear(), now.getMonth(), 1).toISOString(),
          lastGenerated: ''
        };
        
        await fs.writeFile(this.usageFile, JSON.stringify(usage, null, 2));
      }

      return {
        ...usage,
        remainingBudget: this.config.monthlyBudget - usage.totalCost
      };

    } catch (error) {
      console.error('❌ Usage tracking error:', error);
      
      // Return safe defaults
      return {
        videosGenerated: 0,
        totalCost: 0,
        remainingBudget: this.config.monthlyBudget,
        monthlyReset: new Date().toISOString()
      };
    }
  }

  /**
   * Update usage tracking with detailed logging
   */
  private async updateUsage(videoId: string, cost: number): Promise<void> {
    try {
      const fs = require('fs').promises;
      const currentUsage = await this.getUsageStats();
      
      const updatedUsage = {
        ...currentUsage,
        videosGenerated: currentUsage.videosGenerated + 1,
        totalCost: currentUsage.totalCost + cost,
        lastVideoId: videoId,
        lastGenerated: new Date().toISOString(),
        remainingBudget: this.config.monthlyBudget - (currentUsage.totalCost + cost)
      };

      await fs.writeFile(this.usageFile, JSON.stringify(updatedUsage, null, 2));
      
      console.log('📊 Usage updated:');
      console.log(`   Videos: ${updatedUsage.videosGenerated}/${this.config.videoLimit}`);
      console.log(`   Cost: $${updatedUsage.totalCost.toFixed(2)}/$${this.config.monthlyBudget}`);
      console.log(`   Remaining: $${updatedUsage.remainingBudget.toFixed(2)}`);
      
    } catch (error) {
      console.error('❌ Usage update failed:', error);
    }
  }

  /**
   * Optimize video settings for cost efficiency
   */
  private optimizeVideoSettings(request: VideoGenerationRequest) {
    // Default to cost-efficient settings
    const settings = {
      resolution: '720p' as const, // Lower resolution = lower cost
      aspect_ratio: '16:9' as const, // Standard format
      quality: 'standard' as const
    };

    // Override for high-priority videos
    if (request.priority === 'high') {
      settings.resolution = '1080p';
      settings.quality = 'high';
    }

    // Social media optimizations
    if (request.title.toLowerCase().includes('social')) {
      settings.aspect_ratio = '1:1'; // Square for social media
    }

    return settings;
  }

  /**
   * Estimate video cost based on script length
   */
  private estimateVideoCost(scriptLength: number): number {
    // Rough estimation: $3-5 per minute of video
    // Average speaking rate: ~150 words per minute
    // Average characters per word: ~5
    
    const estimatedMinutes = scriptLength / (150 * 5);
    const baseCost = Math.max(3.5, estimatedMinutes * 4); // Minimum $3.50
    
    return Math.round(baseCost * 100) / 100; // Round to 2 decimal places
  }

  /**
   * Generate cost-efficient video batch
   */
  async generateVideoBatch(requests: VideoGenerationRequest[]): Promise<VideoGenerationResponse[]> {
    console.log('🎬 Starting batch video generation...');
    console.log('📹 Videos to generate:', requests.length);
    
    const results: VideoGenerationResponse[] = [];
    const usage = await this.getUsageStats();
    
    console.log('💰 Starting budget:', `$${usage.remainingBudget.toFixed(2)}`);
    
    // Sort by priority (high first)
    const sortedRequests = requests.sort((a, b) => {
      const priorityOrder = { high: 3, medium: 2, low: 1 };
      return priorityOrder[b.priority || 'medium'] - priorityOrder[a.priority || 'medium'];
    });

    for (let i = 0; i < sortedRequests.length; i++) {
      const request = sortedRequests[i];
      
      try {
        console.log(`\n📹 Generating video ${i + 1}/${sortedRequests.length}: ${request.title}`);
        
        // Add delay between requests to avoid rate limits
        if (i > 0) {
          console.log('⏱️ Waiting 5 seconds to avoid rate limits...');
          await new Promise(resolve => setTimeout(resolve, 5000));
        }
        
        const result = await this.generateVideo(request);
        results.push(result);
        
        if (result.status === 'error') {
          console.log(`❌ Failed: ${request.title} - ${result.error}`);
          
          // Stop if budget exceeded
          if (result.error?.includes('budget')) {
            console.log('💸 Budget limit reached, stopping batch generation');
            break;
          }
        } else {
          console.log(`✅ Initiated: ${request.title} (ID: ${result.videoId})`);
        }
        
      } catch (error) {
        console.error(`❌ Batch error for "${request.title}":`, error);
        
        results.push({
          videoId: '',
          status: 'error',
          error: error.message,
          createdAt: new Date().toISOString()
        });
      }
    }
    
    const successful = results.filter(r => r.status !== 'error').length;
    console.log(`\n🎉 Batch generation complete: ${successful}/${requests.length} videos initiated`);
    
    return results;
  }

  /**
   * List available avatars (after you record yours)
   */
  async listAvatars(): Promise<any[]> {
    try {
      console.log('👤 Fetching available avatars...');
      
      const response = await fetch(`${this.baseUrl}/avatars`, {
        headers: {
          'X-API-KEY': this.config.apiKey
        }
      });

      if (!response.ok) {
        throw new Error(`Failed to list avatars: ${response.statusText}`);
      }

      const result = await response.json();
      const avatars = result.data || [];
      
      console.log(`👤 Found ${avatars.length} available avatars`);
      avatars.forEach((avatar: any, index: number) => {
        console.log(`   ${index + 1}. ${avatar.name} (ID: ${avatar.avatar_id})`);
      });
      
      return avatars;

    } catch (error) {
      console.error('❌ Avatar listing failed:', error);
      return [];
    }
  }

  /**
   * Download completed video
   */
  async downloadVideo(videoId: string, filename?: string): Promise<string | null> {
    try {
      const status = await this.checkVideoStatus(videoId);
      
      if (status.status !== 'completed' || !status.downloadUrl) {
        console.log('❌ Video not ready for download');
        return null;
      }

      console.log('⬇️ Downloading video...');
      
      const response = await fetch(status.downloadUrl);
      if (!response.ok) {
        throw new Error(`Download failed: ${response.statusText}`);
      }

      const buffer = await response.arrayBuffer();
      const fs = require('fs').promises;
      
      const outputFilename = filename || `chris-deutsch-video-${videoId}.mp4`;
      await fs.writeFile(outputFilename, Buffer.from(buffer));
      
      console.log('✅ Video downloaded:', outputFilename);
      console.log('📏 File size:', (buffer.byteLength / 1024 / 1024).toFixed(1), 'MB');
      
      return outputFilename;

    } catch (error) {
      console.error('❌ Download failed:', error);
      return null;
    }
  }
}

/**
 * Factory function to create configured service
 */
export function createHeyGenVideoService(): HeyGenVideoService {
  const config: HeyGenConfig = {
    apiKey: process.env.HEYGEN_API_KEY!,
    monthlyBudget: parseInt(process.env.HEYGEN_MONTHLY_BUDGET || '40'),
    videoLimit: parseInt(process.env.HEYGEN_VIDEO_LIMIT || '10'),
    avatarId: process.env.HEYGEN_AVATAR_ID || undefined
  };

  if (!config.apiKey) {
    throw new Error('HEYGEN_API_KEY environment variable is required');
  }

  return new HeyGenVideoService(config);
}

/**
 * Pre-built video templates for Chris Deutsch
 */
export const CHRIS_DEUTSCH_VIDEO_TEMPLATES: VideoGenerationRequest[] = [
  {
    title: "Welcome & Introduction",
    priority: "high",
    background: "real_estate_office",
    script: "Hi, I'm Chris Deutsch, your Twin Cities real estate expert with 25 years of experience. I specialize in Golden Valley and Bryn Mawr, and I'm committed to making your real estate journey completely stress-free. Whether you're buying your first home, upgrading to your dream property, or making a strategic investment, I'm here to guide you every step of the way with the expertise that only comes from a quarter-century of local market knowledge.",
    voice_settings: { speed: 1.05, emotion: "professional" },
    video_settings: { resolution: "1080p", aspect_ratio: "16:9" }
  },
  
  {
    title: "Golden Valley Market Update",
    priority: "high", 
    background: "real_estate_office",
    script: "You know, after 25 years serving Twin Cities families, I'm honestly excited to share some remarkable developments happening right here in our Golden Valley market. If you're a homeowner in the 55416 or 55426 zip codes, you're actually sitting on some incredible equity growth. Homes in your area have appreciated significantly, and frankly, the numbers are impressive - median values are now reaching around $495,000 in prime Golden Valley neighborhoods. Here's what this really means for you: If you purchased your home 7 to 10 years ago, you likely have substantial equity that opens up some exciting possibilities.",
    voice_settings: { speed: 1.05, emotion: "friendly" },
    video_settings: { resolution: "1080p", aspect_ratio: "16:9" }
  },

  {
    title: "Why Choose Chris Deutsch",
    priority: "medium",
    background: "real_estate_office", 
    script: "After 25 years in Twin Cities real estate, I've learned that success isn't just about closing deals - it's about building relationships and delivering peace of mind. My approach is different: I believe your real estate experience should be completely stress-free. That's why I handle every detail, coordinate with all the professionals involved, and keep you informed throughout the entire process. When you work with me, you're not just getting an agent - you're getting a trusted advisor who's committed to your success.",
    voice_settings: { speed: 1.05, emotion: "professional" },
    video_settings: { resolution: "720p", aspect_ratio: "16:9" }
  },

  {
    title: "Schedule Your Consultation",
    priority: "medium",
    background: "real_estate_office",
    script: "Ready to take the next step? I'd love to provide you with a complimentary, no-pressure market analysis and consultation. Whether you're curious about your home's current value, exploring upgrade options, or looking for your first home, I'm here to help. You can reach me directly at chris@chrisdeutsch.com or visit my website to schedule a time that works for you. Remember, in real estate, experience isn't just about years - it's about results, relationships, and making your transition completely stress-free.",
    voice_settings: { speed: 1.05, emotion: "friendly" },
    video_settings: { resolution: "720p", aspect_ratio: "16:9" }
  },

  {
    title: "Social Media - Quick Intro",
    priority: "low",
    background: "modern",
    script: "Hi, I'm Chris Deutsch! 25 years helping Twin Cities families find their perfect homes. Specializing in Golden Valley & Bryn Mawr. Let's make your real estate dreams a reality - completely stress-free!",
    voice_settings: { speed: 1.1, emotion: "excited" },
    video_settings: { resolution: "720p", aspect_ratio: "1:1" }
  }
];

export default HeyGenVideoService;