'use client';

import { useState } from 'react';
import { Button } from './button';
import { Card } from './card';

interface VideoTemplate {
  title: string;
  priority: 'high' | 'medium' | 'low';
  script: string;
  estimatedCost: number;
  duration: string;
}

interface GenerationResult {
  videoId: string;
  status: string;
  estimatedCost: number;
  error?: string;
}

const VIDEO_TEMPLATES: VideoTemplate[] = [
  {
    title: "Welcome & Introduction",
    priority: "high",
    script: "Hi, I'm Chris Deutsch, your Twin Cities real estate expert with 25 years of experience...",
    estimatedCost: 4.50,
    duration: "90 seconds"
  },
  {
    title: "Golden Valley Market Update",
    priority: "high", 
    script: "You know, after 25 years serving Twin Cities families, I'm honestly excited to share...",
    estimatedCost: 5.00,
    duration: "120 seconds"
  },
  {
    title: "Why Choose Chris Deutsch",
    priority: "medium",
    script: "After 25 years in Twin Cities real estate, I've learned that success isn't just about...",
    estimatedCost: 3.75,
    duration: "75 seconds"
  },
  {
    title: "Schedule Consultation",
    priority: "medium",
    script: "Ready to take the next step? I'd love to provide you with a complimentary...",
    estimatedCost: 3.50,
    duration: "70 seconds"
  },
  {
    title: "Social Media Quick Intro",
    priority: "low",
    script: "Hi, I'm Chris Deutsch! 25 years helping Twin Cities families...",
    estimatedCost: 2.50,
    duration: "30 seconds"
  }
];

export default function HeyGenVideoGenerator() {
  const [selectedVideos, setSelectedVideos] = useState<number[]>([]);
  const [generating, setGenerating] = useState(false);
  const [results, setResults] = useState<GenerationResult[]>([]);
  const [usage, setUsage] = useState<any>(null);

  const loadUsage = async () => {
    try {
      const response = await fetch('/api/heygen?action=usage');
      const data = await response.json();
      setUsage(data);
    } catch (error) {
      console.error('Failed to load usage:', error);
    }
  };

  const toggleVideoSelection = (index: number) => {
    setSelectedVideos(prev => 
      prev.includes(index) 
        ? prev.filter(i => i !== index)
        : [...prev, index]
    );
  };

  const generateSelectedVideos = async () => {
    if (selectedVideos.length === 0) return;
    
    setGenerating(true);
    setResults([]);
    
    try {
      for (const index of selectedVideos) {
        const template = VIDEO_TEMPLATES[index];
        
        const response = await fetch('/api/heygen', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            script: template.script,
            title: template.title,
            priority: template.priority,
            background: 'real_estate_office',
            voice_settings: { speed: 1.05, emotion: 'professional' },
            video_settings: { resolution: '720p', aspect_ratio: '16:9' }
          })
        });

        const result = await response.json();
        
        if (result.success) {
          setResults(prev => [...prev, {
            videoId: result.videoId,
            status: result.status,
            estimatedCost: result.estimatedCost
          }]);
        } else {
          setResults(prev => [...prev, {
            videoId: '',
            status: 'error',
            estimatedCost: 0,
            error: result.error
          }]);
        }

        // Small delay between requests
        if (index !== selectedVideos[selectedVideos.length - 1]) {
          await new Promise(resolve => setTimeout(resolve, 2000));
        }
      }
      
      // Refresh usage after generation
      await loadUsage();
      
    } catch (error) {
      console.error('Generation failed:', error);
    } finally {
      setGenerating(false);
    }
  };

  const checkVideoStatus = async (videoId: string) => {
    try {
      const response = await fetch(`/api/heygen?videoId=${videoId}`);
      const data = await response.json();
      return data.video;
    } catch (error) {
      console.error('Status check failed:', error);
      return null;
    }
  };

  const getTotalCost = () => {
    return selectedVideos.reduce((total, index) => {
      return total + VIDEO_TEMPLATES[index].estimatedCost;
    }, 0);
  };

  const getPriorityIcon = (priority: string) => {
    switch (priority) {
      case 'high': return '🔥';
      case 'medium': return '📍';
      case 'low': return '📋';
      default: return '📹';
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-[#504f56] mb-4">
          HeyGen Avatar Video Generator
        </h2>
        <p className="text-lg text-gray-600">
          Create professional avatar videos with Chris's digital twin
        </p>
      </div>

      {/* Usage Statistics */}
      <Card className="p-6 bg-gradient-to-r from-[#a81933]/10 to-[#504f56]/10">
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-xl font-bold text-[#504f56]">Monthly Usage</h3>
          <Button onClick={loadUsage} variant="outline" size="sm">
            🔄 Refresh
          </Button>
        </div>
        
        {usage ? (
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-[#a81933]">
                ${usage.usage?.totalCost?.toFixed(2) || '0.00'}
              </div>
              <div className="text-sm text-gray-600">Spent / $40.00</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-[#504f56]">
                {usage.usage?.videosGenerated || 0}
              </div>
              <div className="text-sm text-gray-600">Videos / 10</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-green-600">
                ${usage.usage?.remainingBudget?.toFixed(2) || '40.00'}
              </div>
              <div className="text-sm text-gray-600">Remaining</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">
                {(usage.limits?.videoLimit || 10) - (usage.usage?.videosGenerated || 0)}
              </div>
              <div className="text-sm text-gray-600">Videos Left</div>
            </div>
          </div>
        ) : (
          <div className="text-center text-gray-500">
            Click "Refresh" to load usage statistics
          </div>
        )}
      </Card>

      {/* Video Template Selection */}
      <div className="space-y-4">
        <h3 className="text-xl font-bold text-[#504f56]">Select Videos to Generate</h3>
        
        <div className="grid gap-4">
          {VIDEO_TEMPLATES.map((template, index) => (
            <Card 
              key={index} 
              className={`p-4 cursor-pointer transition-all duration-200 ${
                selectedVideos.includes(index) 
                  ? 'border-[#a81933] bg-[#a81933]/5' 
                  : 'hover:border-gray-300'
              }`}
              onClick={() => toggleVideoSelection(index)}
            >
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-xl">{getPriorityIcon(template.priority)}</span>
                    <h4 className="font-bold text-[#504f56]">{template.title}</h4>
                    <span className={`px-2 py-1 text-xs font-bold rounded ${
                      template.priority === 'high' ? 'bg-red-100 text-red-700' :
                      template.priority === 'medium' ? 'bg-yellow-100 text-yellow-700' :
                      'bg-gray-100 text-gray-700'
                    }`}>
                      {template.priority.toUpperCase()}
                    </span>
                  </div>
                  
                  <p className="text-gray-600 text-sm mb-3 line-clamp-2">
                    {template.script.substring(0, 100)}...
                  </p>
                  
                  <div className="flex items-center gap-4 text-sm text-gray-500">
                    <span>💰 ~${template.estimatedCost.toFixed(2)}</span>
                    <span>⏱️ {template.duration}</span>
                  </div>
                </div>
                
                <div className={`w-6 h-6 rounded border-2 flex items-center justify-center ${
                  selectedVideos.includes(index) 
                    ? 'bg-[#a81933] border-[#a81933]' 
                    : 'border-gray-300'
                }`}>
                  {selectedVideos.includes(index) && (
                    <span className="text-white text-sm">✓</span>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Generation Controls */}
      {selectedVideos.length > 0 && (
        <Card className="p-6 bg-gradient-to-r from-[#504f56]/10 to-[#a81933]/10">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-bold text-[#504f56]">
                Generate {selectedVideos.length} Video{selectedVideos.length > 1 ? 's' : ''}
              </h3>
              <p className="text-sm text-gray-600">
                Estimated total cost: ~${getTotalCost().toFixed(2)}
              </p>
            </div>
            
            <Button 
              onClick={generateSelectedVideos}
              disabled={generating}
              className="bg-gradient-to-r from-[#a81933] to-[#b8203a] hover:from-[#b8203a] hover:to-[#c82d41]"
            >
              {generating ? '🎬 Generating...' : '🚀 Generate Videos'}
            </Button>
          </div>

          <div className="flex flex-wrap gap-2">
            {selectedVideos.map(index => (
              <span key={index} className="px-3 py-1 bg-[#a81933]/20 text-[#a81933] text-sm font-medium rounded">
                {VIDEO_TEMPLATES[index].title}
              </span>
            ))}
          </div>
        </Card>
      )}

      {/* Generation Results */}
      {results.length > 0 && (
        <Card className="p-6">
          <h3 className="text-lg font-bold text-[#504f56] mb-4">Generation Results</h3>
          
          <div className="space-y-3">
            {results.map((result, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded">
                <div>
                  <div className="font-medium text-[#504f56]">
                    {VIDEO_TEMPLATES[selectedVideos[index]]?.title}
                  </div>
                  {result.error ? (
                    <div className="text-sm text-red-600">❌ {result.error}</div>
                  ) : (
                    <div className="text-sm text-gray-600">
                      ✅ Generated • ID: {result.videoId}
                    </div>
                  )}
                </div>
                
                {result.videoId && (
                  <Button 
                    onClick={() => checkVideoStatus(result.videoId)}
                    variant="outline" 
                    size="sm"
                  >
                    Check Status
                  </Button>
                )}
              </div>
            ))}
          </div>
        </Card>
      )}

      {/* Quick Start Section */}
      <Card className="p-6 bg-gradient-to-r from-blue-50 to-indigo-50 border-blue-200">
        <h3 className="text-lg font-bold text-blue-900 mb-3">🚀 Quick Start</h3>
        <p className="text-blue-800 mb-4">
          Recommended: Start with "Welcome & Introduction" and "Golden Valley Market Update" 
          for immediate use on your website and marketing.
        </p>
        <Button 
          onClick={() => {
            setSelectedVideos([0, 1]);
          }}
          variant="outline"
          className="border-blue-300 text-blue-700 hover:bg-blue-100"
        >
          Select Starter Set (~$9.50)
        </Button>
      </Card>
    </div>
  );
}