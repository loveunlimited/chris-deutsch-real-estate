import { NextRequest, NextResponse } from 'next/server'

// Lead capture API for HeyGen avatar interactions
export async function POST(request: NextRequest) {
  try {
    const leadData = await request.json()
    
    // Validate required fields
    if (!leadData.email && !leadData.phone) {
      return NextResponse.json(
        { error: 'Email or phone number is required' },
        { status: 400 }
      )
    }

    // Enhanced lead data with HeyGen context
    const enhancedLead = {
      ...leadData,
      id: generateLeadId(),
      timestamp: new Date().toISOString(),
      source: leadData.source || 'heygen_avatar',
      agent: 'Chris Deutsch',
      market_area: 'Twin Cities',
      specialty_areas: ['Golden Valley', 'Bryn Mawr'],
      
      // Real estate specific fields
      lead_type: determineLeadType(leadData),
      urgency_score: calculateUrgencyScore(leadData),
      follow_up_priority: calculateFollowUpPriority(leadData),
      
      // HeyGen conversation context
      avatar_interaction: {
        conversation_length: leadData.conversation_context?.conversation_length || 0,
        topics_discussed: extractTopics(leadData.conversation_context),
        properties_shown: leadData.conversation_context?.propertySearchData || [],
        neighborhoods_mentioned: extractNeighborhoods(leadData.conversation_context)
      }
    }

    // Log the lead (in production, save to database)
    console.log('New lead captured:', enhancedLead)
    
    // Send to CRM (integrate with your CRM system)
    await sendToCRM(enhancedLead)
    
    // Send email notifications
    await sendNotifications(enhancedLead)
    
    // Auto-respond based on lead type
    const autoResponse = generateAutoResponse(enhancedLead)
    
    return NextResponse.json({
      success: true,
      lead_id: enhancedLead.id,
      message: 'Lead captured successfully',
      auto_response: autoResponse
    })
    
  } catch (error) {
    console.error('Lead capture error:', error)
    return NextResponse.json(
      { error: 'Failed to capture lead' },
      { status: 500 }
    )
  }
}

function generateLeadId(): string {
  return `lead_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
}

function determineLeadType(leadData: any): string {
  const context = leadData.conversation_context
  
  if (context?.userPreferences?.timeline === 'immediate') return 'hot_buyer'
  if (leadData.message?.toLowerCase().includes('sell')) return 'seller'
  if (leadData.message?.toLowerCase().includes('buy')) return 'buyer'
  if (context?.propertySearchData?.length > 0) return 'active_buyer'
  
  return 'information_seeker'
}

function calculateUrgencyScore(leadData: any): number {
  let score = 0
  
  // Timeline urgency
  if (leadData.conversation_context?.userPreferences?.timeline === 'immediate') score += 50
  if (leadData.conversation_context?.userPreferences?.timeline === '30_days') score += 30
  if (leadData.conversation_context?.userPreferences?.timeline === '90_days') score += 20
  
  // Engagement level
  if (leadData.conversation_context?.conversation_length > 5) score += 20
  if (leadData.conversation_context?.propertySearchData?.length > 0) score += 25
  
  // Contact information provided
  if (leadData.phone) score += 15
  if (leadData.email) score += 10
  
  return Math.min(score, 100)
}

function calculateFollowUpPriority(leadData: any): 'immediate' | 'same_day' | 'next_day' | 'weekly' {
  const urgency = calculateUrgencyScore(leadData)
  
  if (urgency >= 70) return 'immediate'
  if (urgency >= 50) return 'same_day'
  if (urgency >= 30) return 'next_day'
  return 'weekly'
}

function extractTopics(context: any): string[] {
  const topics = []
  
  if (context?.propertySearchData?.length > 0) topics.push('property_search')
  if (context?.userPreferences?.neighborhoods?.includes('Golden Valley')) topics.push('golden_valley')
  if (context?.userPreferences?.neighborhoods?.includes('Bryn Mawr')) topics.push('bryn_mawr')
  if (context?.market_discussion) topics.push('market_conditions')
  
  return topics
}

function extractNeighborhoods(context: any): string[] {
  return context?.userPreferences?.neighborhoods || []
}

async function sendToCRM(leadData: any): Promise<void> {
  // Integration with CRM system
  // Example: Salesforce, HubSpot, etc.
  
  try {
    // In production, integrate with your CRM API
    console.log('Sending to CRM:', leadData.id)
    
    // Example CRM integration:
    /*
    await fetch('https://api.your-crm.com/leads', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${process.env.CRM_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(leadData)
    })
    */
    
  } catch (error) {
    console.error('CRM integration error:', error)
  }
}

async function sendNotifications(leadData: any): Promise<void> {
  try {
    // Email notification to Chris Deutsch
    const emailContent = generateEmailNotification(leadData)
    
    // In production, use your email service
    console.log('Email notification:', emailContent)
    
    // SMS notification for urgent leads
    if (leadData.follow_up_priority === 'immediate') {
      const smsContent = generateSMSNotification(leadData)
      console.log('SMS notification:', smsContent)
    }
    
  } catch (error) {
    console.error('Notification error:', error)
  }
}

function generateEmailNotification(leadData: any): string {
  return `
    New Lead from HeyGen Avatar: ${leadData.name || 'Anonymous'}
    
    Contact: ${leadData.email || ''} ${leadData.phone || ''}
    Lead Type: ${leadData.lead_type}
    Urgency Score: ${leadData.urgency_score}/100
    Follow-up Priority: ${leadData.follow_up_priority}
    
    Avatar Interaction Summary:
    - Topics Discussed: ${leadData.avatar_interaction.topics_discussed.join(', ')}
    - Neighborhoods: ${leadData.avatar_interaction.neighborhoods_mentioned.join(', ')}
    - Properties Shown: ${leadData.avatar_interaction.properties_shown.length}
    
    Timeline: ${leadData.conversation_context?.userPreferences?.timeline || 'Not specified'}
    Budget: ${leadData.conversation_context?.userPreferences?.priceRange || 'Not specified'}
    
    Source: HeyGen AI Avatar
    Time: ${new Date(leadData.timestamp).toLocaleString()}
  `
}

function generateSMSNotification(leadData: any): string {
  return `🏠 URGENT LEAD: ${leadData.name || 'New prospect'} via HeyGen Avatar. ${leadData.lead_type} - Score: ${leadData.urgency_score}. Contact: ${leadData.phone || leadData.email}. Follow up immediately!`
}

function generateAutoResponse(leadData: any): string {
  const responses = {
    hot_buyer: "Thank you for your interest! I'll personally reach out within the next hour to discuss your immediate home buying needs. As your Twin Cities expert with 25 years of experience, I'm here to make this process completely stress-free for you.",
    
    seller: "I appreciate you considering me to help sell your home! I'll contact you today to schedule a complimentary market analysis. With my proven marketing strategy and deep Twin Cities expertise, I'll ensure you get top dollar for your property.",
    
    buyer: "Exciting that you're looking to buy in the Twin Cities! I'll be in touch shortly to learn more about your dream home criteria. My specialty areas include Golden Valley and Bryn Mawr, and I'll help you find the perfect property.",
    
    active_buyer: "Thank you for exploring those properties with me! I'll follow up with additional listings that match your criteria. Let's schedule a time to view your favorites in person.",
    
    information_seeker: "I'm glad I could share my Twin Cities market insights with you! I'll send you my latest market report and reach out to see how I can best assist with your real estate goals."
  }
  
  return responses[leadData.lead_type as keyof typeof responses] || responses.information_seeker
}

// GET endpoint for lead analytics
export async function GET() {
  try {
    // In production, fetch from database
    const analytics = {
      total_leads: 0,
      heygen_leads: 0,
      conversion_rate: 0,
      avg_urgency_score: 0,
      top_neighborhoods: ['Golden Valley', 'Bryn Mawr'],
      lead_sources: {
        heygen_avatar: 0,
        website_form: 0,
        phone: 0,
        referral: 0
      }
    }
    
    return NextResponse.json(analytics)
  } catch (error) {
    console.error('Analytics error:', error)
    return NextResponse.json(
      { error: 'Failed to fetch analytics' },
      { status: 500 }
    )
  }
}